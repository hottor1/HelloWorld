﻿// NewFolderDlg.cpp: 实现文件
//

#include "pch.h"
#include "ServerPoject.h"
#include "NewFolderDlg.h"
#include "afxdialogex.h"


// CNewFolderDlg 对话框

IMPLEMENT_DYNAMIC(CNewFolderDlg, CDialogEx)

CNewFolderDlg::CNewFolderDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_NEW_FOLDER_DIALOG, pParent)
	, m_NewFolderEdit(_T(""))
{

}

CNewFolderDlg::~CNewFolderDlg()
{
}

void CNewFolderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_NEW_FOLDER_EDIT, m_NewFolderEdit);
}


BEGIN_MESSAGE_MAP(CNewFolderDlg, CDialogEx)
END_MESSAGE_MAP()


// CNewFolderDlg 消息处理程序
