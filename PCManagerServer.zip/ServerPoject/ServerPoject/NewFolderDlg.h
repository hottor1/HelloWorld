﻿#pragma once


// CNewFolderDlg 对话框

class CNewFolderDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CNewFolderDlg)

public:
	CNewFolderDlg(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CNewFolderDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_NEW_FOLDER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()

public:
	CString m_NewFolderEdit;
};
