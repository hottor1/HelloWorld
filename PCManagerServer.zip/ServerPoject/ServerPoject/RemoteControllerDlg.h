﻿#pragma once
#include "IocpServer.h"

// CRemoteControllerDlg 对话框


extern "C" VOID CopyScreenData(PVOID SourceData, PVOID DestinationData, ULONG BufferLength);
class CRemoteControllerDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CRemoteControllerDlg)

public:
	CRemoteControllerDlg(CWnd* pParent = NULL, CIocpServer* IocpServer = NULL, PCONTEXT_OBJECT ContextObject = NULL);
	virtual ~CRemoteControllerDlg();
	CIocpServer* m_IocpServer;
	PCONTEXT_OBJECT m_ContextObject;

	

	// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_REMOTE_CONTROLLER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnClose();		//关闭窗口
	void OnReceiveComplete(void);		//接收数据，判断消息
	VOID DrawFirstData(void);			//绘制第一帧数据
	VOID DrawNextData(void);			//绘制第二帧数据
	afx_msg void OnPaint();				//绘制在窗口上
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);		//系统消息
	virtual BOOL PreTranslateMessage(MSG* pMsg);			//键盘消息
	VOID OnSending(MSG* Msg);
	BOOL SaveSnapshotData(void);		//获得截图
	VOID UpdateClipboardData(char* BufferData, ULONG BufferLength);		//将客户端剪切板的消息设置到自己剪切板上
	VOID SendClipboardData(void);		//向客户端中设置剪切板
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);	//水平滚动条
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);	//竖直滚动条


private:
	HDC              m_WindowDCHandle;         //工人
	HDC              m_WindowMemoryDCHandle;   //工人的工具箱
	LPBITMAPINFO     m_BitmapInfo;             //工具
	HBITMAP	         m_BitmapHandle;           //工具
	PVOID            m_BitmapData;
	POINT            m_CursorPosition;         //存储鼠标位置
	ULONG   m_HorizontalScrollPosition;
	ULONG   m_VerticalScrollPosition;

	HICON   	     m_IconHwnd;
	BOOL    m_IsTraceCursor = FALSE;           //跟踪光标轨迹
	BOOL 	m_IsControl = FALSE;               //远程控制
public:
	
	
	
};


enum
{
	ID_CONTROL = 0x1010,
	ID_SEND_CTRL_ALT_DEL,
	ID_TRACE_CURSOR,
	ID_BLOCK_INPUT,	// 锁定远程计算机输入
	ID_SAVE_DIB,		// 保存图片
	ID_GET_CLIPBOARD,	// 获取剪贴板
	ID_SET_CLIPBOARD,	// 设置剪贴板

};