﻿#pragma once
#include "afxdialogex.h"
#include "IocpServer.h"
#include"ProcessManager.h"
// CCreateProcessDlg 对话框
typedef void (CALLBACK* LPFN_WNDCALLBACK)(PCONTEXT_OBJECT ContextObject);  //函数指针定义 
class CCreateProcessDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CCreateProcessDlg)

public:
	CCreateProcessDlg(CWnd* pParent = NULL, CIocpServer* IocpServer = NULL, PCONTEXT_OBJECT ContextObject = NULL);   // 标准构造函数
	virtual ~CCreateProcessDlg();


	CIocpServer* m_IocpServer;
	PCONTEXT_OBJECT m_ContextObject;
	CProcessManager* m_Dlg;
// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CREATE_PROCESS_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()

public:

	afx_msg void OnBnClickedEnterButton();
	afx_msg void OnBnClickedCancelButton();
	static VOID CALLBACK WndCallback(PCONTEXT_OBJECT ContextObject);   //窗口回调
	CEdit m_ProcessEdlt;
};
