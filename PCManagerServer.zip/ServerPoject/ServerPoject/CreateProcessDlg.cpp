﻿// CreateProcessDlg.cpp: 实现文件
//

#include "pch.h"
#include "ServerPoject.h"
#include "afxdialogex.h"
#include "CreateProcessDlg.h"
#include "ProcessManager.h"
#include "Common.h"

// CCreateProcessDlg 对话框

IMPLEMENT_DYNAMIC(CCreateProcessDlg, CDialogEx)

CCreateProcessDlg::CCreateProcessDlg(CWnd* pParent, CIocpServer*
	IocpServer, CONTEXT_OBJECT* ContextObject)
	: CDialogEx(IDD_CREATE_PROCESS_DIALOG, pParent)
{
	m_IocpServer = IocpServer;
	m_ContextObject = ContextObject;
	
}

CCreateProcessDlg::~CCreateProcessDlg()
{
}

void CCreateProcessDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROCESS_EDIT, m_ProcessEdlt);
}


BEGIN_MESSAGE_MAP(CCreateProcessDlg, CDialogEx)
	
	ON_BN_CLICKED(IDC_ENTER_BUTTON, &CCreateProcessDlg::OnBnClickedEnterButton)
	ON_BN_CLICKED(IDC_CANCEL_BUTTON, &CCreateProcessDlg::OnBnClickedCancelButton)
END_MESSAGE_MAP()


// CCreateProcessDlg 消息处理程序



void CCreateProcessDlg::OnBnClickedEnterButton()
{
	// TODO: 在此添加控件通知处理程序代码


	CString v1;
	m_ProcessEdlt.GetWindowText(v1);

	CStringA strA(v1); // 将 CString 转换为 ANSI 格式的 CStringA

	int nDataLength = strA.GetLength() * sizeof(BYTE);
	LPBYTE BufferData = (LPBYTE)LocalAlloc(LPTR, 1 + nDataLength);
	BufferData[0] = CLIENT_PROCESS_MANAGER_CREATE_REQUIRE;
	memcpy(BufferData + 1, strA, nDataLength);

	m_IocpServer->OnPrepareSending(m_ContextObject, BufferData, LocalSize(BufferData));

	LocalFree(BufferData);

	Sleep(100);
	PostMessage(WM_COMMAND, MAKEWPARAM(ID_REFRESH_PROCESS, BN_CLICKED));
	CCreateProcessDlg::OnOK();

}


void CCreateProcessDlg::OnBnClickedCancelButton()
{
	// TODO: 在此添加控件通知处理程序代码
	CCreateProcessDlg::OnOK();
}

VOID CCreateProcessDlg::WndCallback(PCONTEXT_OBJECT ContextObject)
{
	return VOID();
}

