﻿#pragma once
#include "ConfigFile.h"

// CServerManagerDlg 对话框

class CServerManagerDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CServerManagerDlg)

public:
	CServerManagerDlg(CWnd* pParent = NULL);
	virtual ~CServerManagerDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERVER_MANAGER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedApplyButton();
	virtual BOOL OnInitDialog();
	HICON   	m_IconHwnd;
	CConfigFile m_ConfigFile;
	int m_SetListenPort;
	int m_SetMaxConnections;
	afx_msg void OnEnChangeSetListenPortEdit();
	afx_msg void OnEnChangeSetMaxConnectionsEdit();
	CButton m_ApplyButton;
};
