﻿// TransferModeDlg.cpp: 实现文件
//

#include "pch.h"
#include "ServerPoject.h"
#include "TransferModeDlg.h"
#include "afxdialogex.h"


// CTransferModeDlg 对话框

IMPLEMENT_DYNAMIC(CTransferModeDlg, CDialogEx)

CTransferModeDlg::CTransferModeDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_TRANSFER_MODE_DIALOG, pParent)
{

}

CTransferModeDlg::~CTransferModeDlg()
{
}

void CTransferModeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CTransferModeDlg, CDialogEx)
	ON_CONTROL_RANGE(BN_CLICKED, IDC_COVER_BUTTON, IDC_CANCEL_BUTTON, OnEndDialog)
	ON_WM_CLOSE()
END_MESSAGE_MAP()


// CTransferModeDlg 消息处理程序
VOID CTransferModeDlg::OnEndDialog(UINT id)
{
	// TODO: Add your control notification handler code here
	EndDialog(id);
}

BOOL CTransferModeDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  在此添加额外的初始化
	CString	Tips;
	Tips.Format("衰了 咋办.... \" %s \" ", m_FileFullPath);


	//
	for (int i = 0; i < Tips.GetLength(); i += 120)
	{
		Tips.Insert(i, "\n");
		i += 1;
	}

	//sdk
	SetDlgItemText(IDC_TIPS_STATIC, Tips);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // 异常: OCX 属性页应返回 FALSE
}


void CTransferModeDlg::OnClose()
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	CDialogEx::OnClose();
}
