#pragma once
#include <Windows.h>
#include <iostream>
#include <tchar.h>
using namespace std;

#ifdef _UNICODE
#define _tcout ::std::wcout
#define _tstring ::std::wstring
#define _tcin ::std:wcin
#else
#define _tcout ::std::cout
#define _tstring ::std::string
#define _tcin ::std:cin
#endif // _UNICODE


class CConfigFile
{
public:
	CConfigFile();
	~CConfigFile();
	BOOL InitializeConfigFile();
	BOOL GetIntFromCongfigFile(const _tstring& Key, const _tstring& SubKey,int* BufferData);
	BOOL SetIntToConfigFile(const _tstring&  Key, const _tstring& SubKey, int BufferData);

private:
	_tstring m_FileFullPath;

};

