﻿#pragma once
#include"IocpServer.h"
#include"Common.h"
// CRegisterManagerDlg 对话框


struct PACKET_HEADER {
	int   v1;          //名字个数
	DWORD v2;          //名字大小
	DWORD v3;          //值大小

};


class CRegisterManagerDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CRegisterManagerDlg)

public:
	CRegisterManagerDlg(CWnd* pParent = NULL, CIocpServer* IocpServer = NULL, PCONTEXT_OBJECT ContextObject = NULL);   // 标准构造函数
	virtual ~CRegisterManagerDlg();
	CIocpServer* m_IocpServer;
	PCONTEXT_OBJECT m_ContextObject;

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_REGISTER_MANAGER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnClose();
	virtual BOOL OnInitDialog();
	void OnReceiveComplete(void);
	CTreeCtrl m_RegisterShowTree;		//树控件
	CListCtrl m_RegisterShowList;		//ListCtrl控件
	afx_msg void OnTvnSelchangedRegisterShowTree(NMHDR* pNMHDR, LRESULT* pResult);
	CString GetFullPath(HTREEITEM Selected);
	char GetFatherPath(CString& FullPath);
	void AddPath(char* BufferData);
	void AddKey(char* BufferData);


	CImageList	m_ImageList1;   //List控件上的图标
	CImageList	m_ImageList2;   //List控件上的图标
	HICON   m_IconHwnd;

	HTREEITEM	m_Root;
	HTREEITEM	m_CurrentUser;
	HTREEITEM	m_LocalMachine;
	HTREEITEM	m_Users;
	HTREEITEM	m_CurrentConfig;
	HTREEITEM	m_ClassRoot;
	HTREEITEM   m_Selected;
	BOOL m_IsEnable = FALSE;
};
