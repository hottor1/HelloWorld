﻿#pragma once
#include "afxdialogex.h"
#include"IocpServer.h"

// CProcessManager 对话框

class CProcessManager : public CDialogEx
{
	DECLARE_DYNAMIC(CProcessManager)

public:
	CProcessManager(CWnd* pParent = NULL, CIocpServer* IocpServer = NULL, PCONTEXT_OBJECT ContextObject = NULL);   // 标准构造函数
	virtual ~CProcessManager();


	CIocpServer* m_IocpServer;
// 对话框数据
	PCONTEXT_OBJECT m_ContextObject;
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PROCESS_MANAGER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
		HICON   	m_IconHwnd;   //用户对象  内核对象   HWND  HANDLE  都是对象 

private:public:
	virtual BOOL OnInitDialog();
	void InitializeSolidMenu();     //初始化固体菜单
	afx_msg void OnClose();
	afx_msg void OnNMCustomdrawProcessInofoList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnNMRClickProcessInofoList(NMHDR* pNMHDR, LRESULT* pResult);
	CListCtrl m_ProcessInfoList;
	void GetProcessInfoList();
	void ShowProcessInfoList(void);
	void OnReceiveComplete(void);
	afx_msg void OnRefreshProcess();
	afx_msg void OnKillProcess();
	afx_msg void OnSuspendProcess();
	afx_msg void OnResumeProcess();
	afx_msg void OnProcessModules();
	afx_msg void OnProcessThreads();
	afx_msg void OnProcessMemory();
	afx_msg void OnProcessHandles();
	afx_msg void OnCreateProcessMenu();
};
