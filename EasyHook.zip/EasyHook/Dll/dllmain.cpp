﻿#include "pch.h"
#include <iostream>
#include <tchar.h>
using namespace std;


BOOL APIENTRY DllMain(HMODULE hModule,
	DWORD  ul_reason_for_call,
	LPVOID lpReserved
)
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	{
		MessageBox(NULL, _T("DllMain"), _T("DllMain"), 0);
		break;
	}
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
	{
		MessageBox(NULL, _T("DLL_PROCESS_DETACH"), _T("DLL_PROCESS_DETACH"), 0);
		break;
	}
	}
	return TRUE;
}

BOOL _stdcall MyFunction(unsigned char* BufferData, unsigned int BufferLength)
{
	if (!BufferData)
		return FALSE;

	const TCHAR* v1 = _T("{f56fee02-16d1-44a3-b191-4d7535f92ca5}");
	memcpy_s(BufferData, BufferLength, v1, (_tcslen(v1) + 1) * sizeof(TCHAR));
	return TRUE;
}
