#include"MemoryHelper.h"
#include"pch.h"

#include"Common.h"


BOOL RtlIsValidPointer(PVOID VirtualAddress, ULONG ViewSize)
{
    if ((VirtualAddress == NULL) || (VirtualAddress == (PVOID)~0))
        return FALSE;

    BOOL IsOk = IsBadReadPtr(VirtualAddress, ViewSize);   //IsOk == TRUE �浰

    return !IsOk;
}

void* RtlAllocateMemory(BOOL Flags, ULONG ViewSize)
{
    void* VirtualAddress =
#ifdef _DEBUG
        malloc(ViewSize);
#else
        HeapAlloc(__ProcessHeap, 0, ViewSize);
#endif

    if (Flags && (VirtualAddress != NULL))
        RtlZeroMemory(VirtualAddress, ViewSize);   //�ڴ��ʼ��Ϊ��

    return VirtualAddress;
}

void* RtlAllocateMemoryEx(void* VirtualAddress, ULONG* ViewSize)
{
     UCHAR* v5 = NULL;

#if defined(_M_X64) && !defined(DRIVER)
    LONGLONG            BaseAddress;
    LONGLONG		    StartAddress;
    LONGLONG		    EndAddress;
    LONGLONG            Index;

#endif

#if !defined(DRIVER)
    SYSTEM_INFO		    SysInfo;   //���ϵͳ��Ϣ
    ULONG               PageSize;

    GetSystemInfo(&SysInfo);

    PageSize = SysInfo.dwPageSize;//ҳ��λ 4096Bytes
    *ViewSize = PageSize;
#endif


    // reserve page with execution privileges
#if defined(_M_X64) && !defined(DRIVER)

    /*
        Reserve memory around entry point...
    */
    StartAddress = ((LONGLONG)VirtualAddress) - ((LONGLONG)0x7FFFFF00);
    EndAddress = ((LONGLONG)VirtualAddress) + ((LONGLONG)0x7FFFFF00);

    if (StartAddress < (LONGLONG)SysInfo.lpMinimumApplicationAddress)
        StartAddress = (LONGLONG)SysInfo.lpMinimumApplicationAddress; // shall not be null, because then VirtualAlloc() will not work as expected

    if (EndAddress > (LONGLONG)SysInfo.lpMaximumApplicationAddress)
        EndAddress = (LONGLONG)SysInfo.lpMaximumApplicationAddress;

    // we are trying to get memory as near as possible to relocate most RIP-relative instructions
    for (BaseAddress = (LONGLONG)VirtualAddress, Index = 0; ; Index += PageSize)
    {
        BOOLEAN IsOk = TRUE;
        if (BaseAddress + Index < EndAddress)
        {
            if ((v5 = (UCHAR*)VirtualAlloc((void*)(BaseAddress + Index), PageSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE)) != NULL)
                break;
            IsOk = FALSE;
        }

        if (BaseAddress - Index > StartAddress)
        {
            if ((v5 = (BYTE*)VirtualAlloc((void*)(BaseAddress - Index), PageSize, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE)) != NULL)
                break;
            IsOk = FALSE;
        }

        if (IsOk)
            break;
    }

    if (v5 == NULL)
        return NULL;
#else

    *ViewSize = PageSize;
    if ((v5 = (UCHAR*)RtlAllocateMemory(TRUE, PageSize)) == NULL)
        return NULL;

#endif

    return v5;
}


void RtlFreeMemory(void* VirtualAddress)
{

#ifdef _DEBUG
    free(VirtualAddress);
#else
    HeapFree(__ProcessHeap, 0, VirtualAddress);
#endif
}
LONG RtlProtectMemory(void* VirtualAddress, ULONG ViewSize, ULONG NewProtect, ULONG* OldProtect)
{
    NTSTATUS            Status;

    if (!VirtualProtect(VirtualAddress, ViewSize, NewProtect, OldProtect))
        THROW(STATUS_INVALID_PARAMETER)
    else
        RETURN;

THROW_OUT:
FINALLY_OUT:
    return Status;
}