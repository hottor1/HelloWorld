#pragma once
#include <windows.h>
#include <iostream>
#include <tchar.h>
#include "ntstatus.h"


extern HMODULE   __Ntdll;
extern HMODULE   __Kernel32;
extern HMODULE   __ModuleBase;
extern HANDLE    __ProcessHeap;

#define VALUE64(Value)\
union\
{\
	ULONG64 UNUSED;\
	Value;\
}\


#define RTL_SUCCESS(Status)       SUCCEEDED(Status)
#define FORCE(ReturnValue)          { if(!RTL_SUCCESS(Status = (ReturnValue))) goto THROW_OUT; }   //���ʧ��
#define RETURN                      { Status = STATUS_SUCCESS; goto FINALLY_OUT;}
#define THROW(ReturnValue)        { Status = (ReturnValue);  goto THROW_OUT; }
#define UNMANAGED_ERROR(ReturnValue) {Status = ((ReturnValue) & 0xFF) | 0xF0000000; goto ABORT_ERROR;}



#define _NT_INTERNAL_            EXTERN_C NTSTATUS __stdcall
#define _EXPORTS_
#ifdef  _EXPORTS_
#define _API_						__declspec(dllexport) __stdcall
#else
#define _API_					    __declspec(dllimport) __stdcall
#endif
