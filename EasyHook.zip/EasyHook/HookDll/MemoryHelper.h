#pragma once
#include<Windows.h>
#include<iostream>
#include<tchar.h>
#include"Common.h"


BOOL RtlIsValidPointer(PVOID VirtualAddress, ULONG ViewSize);
void* RtlAllocateMemory(BOOL Flags, ULONG ViewSize);
void* RtlAllocateMemoryEx(void* VirtualAddress, ULONG* ViewSize);
void RtlFreeMemory(void* VirtualAddress);
LONG RtlProtectMemory(void* VirtualAddress, ULONG ViewSize, ULONG NewProtect, ULONG* OldProtect);