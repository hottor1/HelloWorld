#pragma once
#include"Common.h"
#include"..\Disassembler\udis86.h"

using namespace std;

_NT_INTERNAL_ RtlRoundToNextInstruction(
	void* OriginalEntryPoint,
	ULONG OriginalEntrySize);

_NT_INTERNAL_ RtlGetInstructionLength(void* VirtualAddress);