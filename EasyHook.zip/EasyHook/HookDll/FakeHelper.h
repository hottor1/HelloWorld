#pragma once
#include <windows.h>
#include <iostream>
#include <tchar.h>
using namespace std;


BOOL WINAPI FakeBeep(IN DWORD dwFreq, IN DWORD dwDuration);
