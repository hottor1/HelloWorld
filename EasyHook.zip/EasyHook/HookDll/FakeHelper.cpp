#include"pch.h"
#include"FakeHelper.h"


BOOL WINAPI FakeBeep(IN DWORD dwFreq, IN DWORD dwDuration)
{
	MessageBox(NULL, _T("FakeBeep"), _T("EasyHook"), 0);

	return FALSE;
}