#pragma once
#include <windows.h>
#include <iostream>
#include <tchar.h>
#include "Hook.h"
using namespace std;
ULONGLONG __stdcall RtlBarrierIntro(LOCAL_HOOK_INFO* LocalHookInfo, void* ParameterData2, void** ParameterData3);
void* __stdcall RtlBarrierOutro(LOCAL_HOOK_INFO* LocalHookInfo, void** ParameterData2);