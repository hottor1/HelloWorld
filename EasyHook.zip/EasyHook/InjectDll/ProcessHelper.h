#pragma once
#include <windows.h>
#include <iostream>
#include <tchar.h>
#include "Common.h"


//ntdll���������жϽ���λ��
typedef BOOL(WINAPI* LPFN_ISWOW64PROCESS)(IN HANDLE ProcessHandle, OUT PBOOL IsWow64Process);

//ntdll�����������ϵͳλ��
typedef VOID(WINAPI* LPFN_GETNATIVESYSTEMINFO)(IN LPSYSTEM_INFO SystemInfo);

//ntdll�������������߳�
typedef LONG(WINAPI* LPNF_NTCREATETHREADEX)(
	PHANDLE ThreadHandle,
	ACCESS_MASK DesiredAccess,
	LPVOID ObjectAttributes,
	HANDLE ProcessHandle,
	LPTHREAD_START_ROUTINE ThreadProcedure,
	LPVOID ParameterData,
	BOOL  IsCreateSuspended,
	DWORD StackSize,
	LPVOID Unknown1,
	LPVOID Unknown2,
	LPVOID Unknown3);


NTSTATUS RtlIsX64Process(
	ULONG ProcessIdentify,
	BOOL* Is64Bit);
HANDLE RtlGetProcessIdentity(TCHAR* ImageName);
NTSTATUS WINAPI RtlLdrInitializeThunk(HANDLE ProcessHandle);


NTSTATUS WINAPI RtlNtCreateThreadEx(
	HANDLE ProcessHandle,
	LPTHREAD_START_ROUTINE ThreadProcedure,
	void* ParameterData,
	BOOLEAN IsCreateSuspended,   //�������߳�����ִ�л��ǹ���
	HANDLE* ThreadHandle);


void* RtlGetProcessProcAddress(unsigned long ProcessIdentify,
	HANDLE ProcessHandle, char* ModuleName, char* ProcedureName);

HMODULE RtlGetProcessModuleHandle(unsigned long ProcessIdentify, char* ModuleName);

BOOL RtlGetExportDirectory(HANDLE ProcessHandle,
	HMODULE ModuleBase, PIMAGE_EXPORT_DIRECTORY ImageExportDirectory,
	IMAGE_DOS_HEADER ImageDosHeader, IMAGE_NT_HEADERS ImageNtHeaders);