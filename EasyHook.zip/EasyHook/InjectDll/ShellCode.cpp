#include "pch.h"
#include "ShellCode.h"

static ULONG _CodeSize = 0;
ULONG RtlGetCodeSize()
{
	UCHAR* End = NULL;
	UCHAR* Start = NULL;
	ULONG           Index;
	ULONG           Signature;

	if (_CodeSize != 0)
		return _CodeSize;

	// search for signature
	End = Start = RtlGetShellCode();

	for (Index = 0; Index < 2000 /* some always large enough value*/; Index++)
	{
		Signature = *((ULONG*)End);

		if (Signature == 0x12345678)   //ShellCodeָ���ĩβ��־
		{
			_CodeSize = (ULONG)(End - Start);

			return _CodeSize;
		}

		End++;
	}

	return 0;
}

BYTE* RtlGetShellCode()
{
#ifdef _M_X64
	BYTE* v1 = (BYTE*)Injection_ASM_x64;    //����ļ��ĺ���
#else
	BYTE* v1 = (BYTE*)Injection_ASM_x86;
#endif

	//�ж�һ�º�����ַ�е�����
	if (*v1 == 0xE9)
		v1 += *((int*)(v1 + 1)) + 5;   //�������������ַ

	return v1;
}


//jmp   e9 [][][][]   address
//call  E8 [][][][]   address
