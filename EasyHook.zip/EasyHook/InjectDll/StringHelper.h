#pragma once
#include"Common.h"

ULONG RtlAnsiLength(CHAR* VirtualAddress);
ULONG RtlUnicodeLength(WCHAR* VirtualAddress);
