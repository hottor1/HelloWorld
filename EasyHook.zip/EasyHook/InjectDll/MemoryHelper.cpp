#include"MemoryHelper.h"
#include"pch.h"

#include"Common.h"


BOOL RtlIsValidPointer(PVOID VirtualAddress, ULONG ViewSize)
{
    if ((VirtualAddress == NULL) || (VirtualAddress == (PVOID)~0))
        return FALSE;

    BOOL IsOk = IsBadReadPtr(VirtualAddress, ViewSize);   //IsOk == TRUE �浰

    return !IsOk;
}

void* RtlAllocateMemory(BOOL Flags, ULONG ViewSize)
{
    void* VirtualAddress =
#ifdef _DEBUG
        malloc(ViewSize);
#else
        HeapAlloc(__ProcessHeap, 0, ViewSize);
#endif

    if (Flags && (VirtualAddress != NULL))
        RtlZeroMemory(VirtualAddress, ViewSize);   //�ڴ��ʼ��Ϊ��

    return VirtualAddress;
}


void RtlFreeMemory(void* VirtualAddress)
{

#ifdef _DEBUG
    free(VirtualAddress);
#else
    HeapFree(__ProcessHeap, 0, VirtualAddress);
#endif
}
LONG RtlProtectMemory(void* VirtualAddress, ULONG ViewSize, ULONG NewProtect, ULONG* OldProtect)
{
    NTSTATUS            Status;

    if (!VirtualProtect(VirtualAddress, ViewSize, NewProtect, OldProtect))
        THROW(STATUS_INVALID_PARAMETER)
    else
        RETURN;

THROW_OUT:
FINALLY_OUT:
    return Status;
}