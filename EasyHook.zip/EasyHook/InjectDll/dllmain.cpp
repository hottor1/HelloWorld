﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "pch.h"


HMODULE   __Ntdll = NULL;
HMODULE   __Kernel32 = NULL;
HMODULE   __ModuleBase = NULL;
HANDLE    __ProcessHeap = NULL;



BOOL APIENTRY DllMain( HMODULE hModule,     //当进程加载该dll的时候，hModule就是InjectDll.dll的模块基地址
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    {
        __ModuleBase = hModule;
        if (((__Ntdll = LoadLibraryA("ntdll.dll")) == NULL) ||
            ((__Kernel32 = LoadLibraryA("kernel32.dll")) == NULL))   //我们进程中的两个模块地址
            return FALSE;

        //创建一个默认堆
        __ProcessHeap = HeapCreate(0, 0, 0);  //默认进程堆
        break;
    }
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
    {
        if (__Ntdll != NULL)
        {
            FreeLibrary(__Ntdll);
        }
        if (__Kernel32 != NULL)
        {
            FreeLibrary(__Kernel32);
        }
        HeapDestroy(__ProcessHeap);
        break;
    }
        
    }
    return TRUE;
}

