#include "pch.h"
#include "ProcessHelper.h"
#include "MemoryHelper.h"
#include <TlHelp32.h>

NTSTATUS RtlIsX64Process(
	ULONG ProcessIdentify,
	BOOL* Is64Bit)
{

	BOOL			            v1 = FALSE;
	HANDLE			            ProcessHandle = NULL;
	LPFN_ISWOW64PROCESS			IsWow64Process = NULL;
	NTSTATUS           Status;

#ifndef _M_X64
	//����Լ�����64λ
	LPFN_GETNATIVESYSTEMINFO    GetNativeSystemInfo = NULL;
	SYSTEM_INFO		            SysInfo;
#endif

	if (!RtlIsValidPointer(Is64Bit, sizeof(BOOL)))
	{
		return STATUS_INVALID_PARAMETER_2;
	}



	if ((ProcessHandle = OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, ProcessIdentify)) == NULL)
	{
		if (GetLastError() == ERROR_ACCESS_DENIED)
		{
			return STATUS_ACCESS_DENIED;
		}

		else
		{
			return STATUS_NOT_FOUND;
		}

	}
	IsWow64Process = (LPFN_ISWOW64PROCESS)GetProcAddress(__Kernel32, "IsWow64Process");   //��Kernel32 ģ���е������л�ȡ������ַ

#ifdef _M_X64
	//�������64λ
	if (!IsWow64Process(ProcessHandle, &v1))   //v1 == TRUE  ��32λ  
	{
		return STATUS_INTERNAL_ERROR;
	}
	v1 = !v1;

#else

	//���������32λ
	v1 = FALSE;

	if (IsWow64Process != NULL)
	{
		// check if we are running on a 32-bit OS
		GetNativeSystemInfo = (LPFN_GETNATIVESYSTEMINFO)GetProcAddress(__Kernel32, "GetNativeSystemInfo");

		if (GetNativeSystemInfo != NULL)
		{
			GetNativeSystemInfo(&SysInfo);

			if (SysInfo.wProcessorArchitecture != PROCESSOR_ARCHITECTURE_INTEL)
			{
				// if not, then and only then a 32-bit process will be marked as WOW64 process!
				if (!IsWow64Process(ProcessHandle, &v1))
				{
					return STATUS_INTERNAL_ERROR;
				}

				v1 = !v1;
			}
		}
	}
#endif

	* Is64Bit = v1;

	RETURN(STATUS_SUCCESS);   //NtStatus = STATUS_SUCCESS

THROW_OUT:
FINALLY_OUT:
	{
		if (ProcessHandle != NULL)
			CloseHandle(ProcessHandle);

		return Status;
	}
}



NTSTATUS WINAPI RtlLdrInitializeThunk(HANDLE ProcessHandle)
{

	HANDLE                 ThreadHandle = NULL;
	UCHAR* VirtualAddress = NULL;    //����Ⱦ�Ľ��������ַ�ռ�
	BYTE                    ShellCode[3];
	ULONG                   CodeSize;
	SIZE_T                  NumberOfBytesWritten;
	NTSTATUS                Status;

#ifdef _M_X64
	ShellCode[0] = 0xC3; // ret   fastcall����Լ�� 
	CodeSize = 1;
#else
	ShellCode[0] = 0xC2; //ret 0x4
	ShellCode[1] = 0x04;
	ShellCode[2] = 0x00;
	CodeSize = 3;        //C2 04 00 
#endif


	//����Ⱦ�Ľ����������ڴ�
	if ((VirtualAddress = (BYTE*)VirtualAllocEx(ProcessHandle, NULL,
		CodeSize, MEM_COMMIT, PAGE_EXECUTE_READWRITE)) == NULL)
	{
		THROW(STATUS_NO_MEMORY);
	}

	//����Ⱦ�Ľ��̿ռ���д��ִ��ָ��
	if (!WriteProcessMemory(ProcessHandle, VirtualAddress,
		ShellCode, CodeSize, &NumberOfBytesWritten) || (NumberOfBytesWritten != CodeSize))
	{
		THROW(STATUS_INTERNAL_ERROR);
	}

	//�ڱ���Ⱦ�Ľ��̴����߳�
	if (!RTL_SUCCESS(RtlNtCreateThreadEx(ProcessHandle, (LPTHREAD_START_ROUTINE)VirtualAddress,
		NULL, FALSE, &ThreadHandle)))
	{
		if ((ThreadHandle = CreateRemoteThread(ProcessHandle, NULL, 0, (LPTHREAD_START_ROUTINE)VirtualAddress, NULL, 0, NULL)) == NULL)
			THROW(STATUS_ACCESS_DENIED);
	}

	WaitForSingleObject(ThreadHandle, INFINITE);  //���ǵȴ�Ŀ������е��߳�ִ�����

	RETURN;

THROW_OUT:
FINALLY_OUT:
	return Status;
}
NTSTATUS WINAPI RtlNtCreateThreadEx(
	HANDLE ProcessHandle,
	LPTHREAD_START_ROUTINE ThreadProcedure,
	void* ParameterData,
	BOOLEAN IsCreateSuspended,   //�������߳�����ִ�л��ǹ���
	HANDLE* ThreadHandle)
{
	HANDLE			    v1;
	NTSTATUS            Status;
	LPNF_NTCREATETHREADEX NtCreateThreadEx = NULL;

	//�жϲ����ڴ��Ƿ���Ч
	if (!RtlIsValidPointer(ThreadHandle, sizeof(HANDLE)))
	{
		THROW(STATUS_INVALID_PARAMETER_4);
	}


	// this will only work for vista and later...
	if ((NtCreateThreadEx = (LPNF_NTCREATETHREADEX)GetProcAddress(__Ntdll, "NtCreateThreadEx")) == NULL)
		THROW(STATUS_NOT_SUPPORTED);

	FORCE(NtCreateThreadEx(
		&v1,
		0x1FFFFF, // all access
		NULL,
		ProcessHandle,
		(LPTHREAD_START_ROUTINE)ThreadProcedure,    //���뵽Ŀ������е�ShellCode
		ParameterData,
		IsCreateSuspended,
		0,
		NULL,
		NULL,
		NULL
	));

	*ThreadHandle = v1;

	RETURN;

THROW_OUT:
FINALLY_OUT:
	return Status;
}







void* RtlGetProcessProcAddress(unsigned long ProcessIdentify,
	HANDLE ProcessHandle, char* ModuleName, char* ProcedureName)   //GetProcAddress
{

	//��������Ŀ����̿ռ�ģ���ģ���ַ
	HMODULE ModuleBase = RtlGetProcessModuleHandle(ProcessIdentify, ModuleName);   //GetModuleHandle
	IMAGE_DOS_HEADER ImageDosHeader;
	IMAGE_NT_HEADERS ImageNtHeaders;
	IMAGE_EXPORT_DIRECTORY ImageExportDirectory;

	DWORD* AddressOfFunctions;
	DWORD* AddressOfNames;
	WORD* AddressOfOrdinals;

	unsigned int i;

	DWORD_PTR VirtualAddress;   //������Ŀ¼�Ļ���ַ
	DWORD_PTR ViewSize;         //������Ŀ¼��ĩβ
	DWORD_PTR v5;   //������ַ
	DWORD_PTR v4;   //��������

	char v6[256] = { 0 };
	char v10[256] = { 0 };   //ת������Ϣ
	char v11[256] = { 0 };   //ת��ģ������
	char v12[256] = { 0 };   //ת����������

	int a = 0;
	int b = 0;

	WORD Ordinal;

	DWORD_PTR v15;
	DWORD_PTR v14;

	char v13[256] = { 0 };

	if (!ModuleBase)
		return NULL;

	//��ȡĿ�������ModuleBase�е���������
	if (!ReadProcessMemory(ProcessHandle, (void*)ModuleBase, &ImageDosHeader, sizeof(IMAGE_DOS_HEADER), NULL) || ImageDosHeader.e_magic != IMAGE_DOS_SIGNATURE)
		return NULL;

	//��ȡĿ�������ImageNtHeaders�е���������
	if (!ReadProcessMemory(ProcessHandle, (void*)((DWORD_PTR)ModuleBase + ImageDosHeader.e_lfanew), &ImageNtHeaders, sizeof(IMAGE_NT_HEADERS), NULL) || ImageNtHeaders.Signature != IMAGE_NT_SIGNATURE)
		return NULL;

	//��ȡĿ������иú�������ģ��ĵ������ṹ
	if (!RtlGetExportDirectory(ProcessHandle, ModuleBase, &ImageExportDirectory, ImageDosHeader, ImageNtHeaders))
		return NULL;

	// Allocate room for all the function information
	AddressOfFunctions = (DWORD*)malloc(ImageExportDirectory.NumberOfFunctions * sizeof(DWORD));
	AddressOfNames = (DWORD*)malloc(ImageExportDirectory.NumberOfNames * sizeof(DWORD));
	AddressOfOrdinals = (WORD*)malloc(ImageExportDirectory.NumberOfNames * sizeof(WORD));

	//AddressOfFunctions[Index]   Index =  AddressOfNames[AddressOfOrdinals[i]]

	//Ŀ������еĵ������ṹ
	if (!ReadProcessMemory(ProcessHandle, (void*)((DWORD_PTR)ModuleBase + (DWORD_PTR)ImageExportDirectory.AddressOfFunctions),
		AddressOfFunctions, ImageExportDirectory.NumberOfFunctions * sizeof(DWORD), NULL)) {
		free(AddressOfFunctions);
		free(AddressOfNames);
		free(AddressOfOrdinals);
		return NULL;
	}

	// Read function name locations
	if (!ReadProcessMemory(ProcessHandle, (void*)((DWORD_PTR)ModuleBase + (DWORD_PTR)ImageExportDirectory.AddressOfNames),
		AddressOfNames, ImageExportDirectory.NumberOfNames * sizeof(DWORD), NULL)) {
		free(AddressOfFunctions);
		free(AddressOfNames);
		free(AddressOfOrdinals);
		return NULL;
	}

	// Read function name ordinal locations
	if (!ReadProcessMemory(ProcessHandle, (void*)((DWORD_PTR)ModuleBase + (DWORD_PTR)ImageExportDirectory.AddressOfNameOrdinals),
		AddressOfOrdinals, ImageExportDirectory.NumberOfNames * sizeof(WORD), NULL)) {
		free(AddressOfFunctions);
		free(AddressOfNames);
		free(AddressOfOrdinals);
		return NULL;
	}

	//���ݴ��εĺ������ƻ�ȡ�ú�����Ŀ����̿ռ�ĸú�����ַ(ģ�鵼������)

	VirtualAddress = ((DWORD_PTR)ModuleBase + ImageNtHeaders.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].VirtualAddress);  //������Ŀ¼�ľ���ֵ
	ViewSize = (VirtualAddress + ImageNtHeaders.OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT].Size);

	// Check each name for a match
	for (i = 0; i < ImageExportDirectory.NumberOfNames; ++i)
	{
		v5 = (DWORD_PTR)ModuleBase + AddressOfFunctions[i];   //����������ַ
		v4 = (DWORD_PTR)ModuleBase + AddressOfNames[i];       //��������������

		memset(v6, 0, 256);

		if (!ReadProcessMemory(ProcessHandle, (void*)v4, v6, 256, NULL))
			continue;

		//�����Ǵ���ĺ������ƽ��бȽ�
		if (_stricmp(v6, ProcedureName) != 0)
			continue;

		//ת����
		if (v5 >= VirtualAddress && v5 <= ViewSize)
		{

			//��ȡת������Ϣ    
			memset(v10, 0, 256);

			if (!ReadProcessMemory(ProcessHandle, (void*)v5, v10, 256, NULL))
				continue;

			//��v10�е�ת������Ϣ���в��
			memset(v11, 0, 256);
			memset(v12, 0, 256);

			a = 0;
			for (; v10[a] != '.'; a++)    //xxx.Sub_5\0
			{
				v11[a] = v10[a];  //������ת��ģ�������
			}

			a++;
			v11[a] = '\0';   //xxx\0

			b = 0;
			for (; v10[a] != '\0'; a++, b++)
				v12[b] = v10[a];
			b++;
			v12[b] = '\0';   //Sub_5\0

			strcat_s(v11, 256, ".dll");  //xxx.dll

			free(AddressOfFunctions);
			free(AddressOfNames);
			free(AddressOfOrdinals);

			return RtlGetProcessProcAddress(ProcessIdentify, ProcessHandle, v11, v12);     //�ݹ����
		}
		//
		Ordinal = AddressOfOrdinals[i];

		if (Ordinal >= ImageExportDirectory.NumberOfNames)   //��������
		{
			return NULL;
		}

		// If ordinal doesn't match index retrieve correct address
		if (Ordinal != i)
		{
			v15 = ((DWORD_PTR)ModuleBase + (DWORD_PTR)AddressOfFunctions[Ordinal]);
			v14 = ((DWORD_PTR)ModuleBase + (DWORD_PTR)AddressOfNames[Ordinal]);

			memset(v13, 0, 256);

			free(AddressOfFunctions);
			free(AddressOfNames);
			free(AddressOfOrdinals);

			if (!ReadProcessMemory(ProcessHandle, (void*)v14, v13, 256, NULL))
				return NULL;
			else
				return (void*)v15;
		}
		// Otherwise return the address
		else
		{
			//�����ĺ������Ƶ���
			free(AddressOfFunctions);
			free(AddressOfNames);
			free(AddressOfOrdinals);

			return (void*)v5;
		}
	}

	free(AddressOfFunctions);
	free(AddressOfNames);
	free(AddressOfOrdinals);

	return NULL;
}

HMODULE RtlGetProcessModuleHandle(unsigned long ProcessIdentify, char* ModuleName)
{
	MODULEENTRY32W ModuleEntry32 = { 0 };
	HANDLE SnapshotHandle = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, ProcessIdentify);
	char v1[256] = { 0 };

	ModuleEntry32.dwSize = sizeof(MODULEENTRY32);
	Module32First(SnapshotHandle, &ModuleEntry32);
	do
	{
		size_t i;
		wcstombs_s(&i, v1, 256, ModuleEntry32.szModule, 256);  //˫��ת���ɵ���
		if (!_stricmp(v1, ModuleName))
		{
			//ƥ�䵽��Ϣ
			CloseHandle(SnapshotHandle);
			return ModuleEntry32.hModule;   //��ģ���ַ����
		}
		ModuleEntry32.dwSize = sizeof(MODULEENTRY32);  //��ʼ���ṹ����ɨ��
	} while (Module32Next(SnapshotHandle, &ModuleEntry32));

	CloseHandle(SnapshotHandle);
	return NULL;
}

BOOL RtlGetExportDirectory(HANDLE ProcessHandle,
	HMODULE ModuleBase, PIMAGE_EXPORT_DIRECTORY ImageExportDirectory,
	IMAGE_DOS_HEADER ImageDosHeader, IMAGE_NT_HEADERS ImageNtHeaders)
{

	PUCHAR v1;
	PIMAGE_SECTION_HEADER ImageSectionHeader;
	int i;
	DWORD VirtualAddress;   //RVA

	if (!ImageExportDirectory)  //�������ڴ����
		return FALSE;

	v1 = (PUCHAR)malloc(1000 * sizeof(UCHAR));

	memset(ImageExportDirectory, 0, sizeof(IMAGE_EXPORT_DIRECTORY));


	if (!ReadProcessMemory(ProcessHandle, (void*)ModuleBase, v1, (SIZE_T)1000, NULL))
		return FALSE;

	ImageSectionHeader = (PIMAGE_SECTION_HEADER)(v1 + ImageDosHeader.e_lfanew + sizeof(IMAGE_NT_HEADERS));


	//��ȡ��������һ�ַ���
	for (i = 0; i < ImageNtHeaders.FileHeader.NumberOfSections; i++, ImageSectionHeader++)
	{
		if (!ImageSectionHeader)
			continue;

		if (_stricmp((char*)ImageSectionHeader->Name, ".edata") == 0)
		{
			if (!ReadProcessMemory(ProcessHandle, (void*)ImageSectionHeader->VirtualAddress, ImageExportDirectory, sizeof(IMAGE_EXPORT_DIRECTORY), NULL))
				continue;


			free(v1);
			return TRUE;
		}

	}
	//��ȡ����������һ�ַ���
	VirtualAddress = ImageNtHeaders.OptionalHeader.DataDirectory[0].VirtualAddress;
	if (!VirtualAddress)
		return FALSE;

	if (!ReadProcessMemory(ProcessHandle, (void*)((DWORD_PTR)ModuleBase + VirtualAddress), ImageExportDirectory, sizeof(IMAGE_EXPORT_DIRECTORY), NULL))
		return FALSE;

	free(v1);
	return TRUE;
}

