#pragma once
#include <windows.h>
#include <iostream>
#include <tchar.h>



//�ж��ļ��Ƿ����
BOOL RtlFileExists(WCHAR* FilePath);
LONG RtlGetWorkingDirectory(WCHAR* VirtualAddress, ULONG ViewSize);
LONG RtlGetCurrentModulePath(WCHAR* VirtualAddress, ULONG ViewSize);