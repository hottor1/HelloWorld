#pragma once
#include<Windows.h>
#include<iostream>
#include<tchar.h>


BOOL RtlIsValidPointer(PVOID VirtualAddress, ULONG ViewSize);
void* RtlAllocateMemory(BOOL Flags, ULONG ViewSize);

void RtlFreeMemory(void* VirtualAddress);