#pragma once
#include <windows.h>
#include <iostream>
#include <tchar.h>
#include "Common.h"
using namespace std;



#ifdef _M_X64
EXTERN_C void Step1_Asm_x64();
#else
EXTERN_C void __stdcall Step1_Asm_x86();
#endif


typedef struct _CONTEXT_DATA_
{
    union
    {
        struct
        {
            /*00*/ VALUE64(PVOID      CreateThread);    //����ָ��
            /*08*/ VALUE64(PVOID      ThreadProcedure);
            /*16*/ VALUE64(PVOID      ParameterData);
            /*24*/ VALUE64(PVOID      WaitForSingleObject);
            /*32*/ VALUE64(HANDLE     EventHandle1);
            /*40*/ VALUE64(PVOID      CloseHandle);
            /*48*/
            union
            {
                VALUE64(HANDLE     ThreadHandle);
                VALUE64(HANDLE     EventHandle2);
            };
            /*56*/ VALUE64(PVOID      SetEvent);
        };

        ULONGLONG       __Unused__[8];
    };

    // Used to save the current thread's state before calling StealthStub_ASM_x86/x64
    // Integer Registers
    ULONGLONG           Rax;		// 0
    ULONGLONG           Rcx;		// 1
    ULONGLONG           Rdx;		// 2
    ULONGLONG           Rbp;		// 3
    ULONGLONG           Rsp;		// 4
    ULONGLONG           Rsi;		// 5
    ULONGLONG           Rdi;		// 6
    ULONGLONG           Rbx;		// 7
    ULONGLONG           Rip;		// 8
    ULONGLONG           RFlags;		// 9     //��־�Ĵ���
    ULONGLONG           R8;			// 10
    ULONGLONG           R9;			// 11
    ULONGLONG           R10;		// 12
    ULONGLONG           R11;		// 13
    ULONGLONG           R12;		// 14
    ULONGLONG           R13;		// 15
    ULONGLONG           R14;		// 16
    ULONGLONG           R15;		// 17
    // Stack values (as a couple of values will be overwritten within StealthStub_ASM_x64)
    ULONGLONG			StackA;		// 18
    ULONGLONG			StackB;		// 19
}CONTEXT_DATA, * PCONTEXT_DATA;

BYTE* RtlGetStep1Code();
ULONG RtlGetStep1CodeSize();



EXTERN_C NTSTATUS _API_ RtlCreateRemoteThreadEx(
    ULONG ProcessIdentify,
    LPTHREAD_START_ROUTINE ThreadProcedure,
    PVOID ParameterData,
    HANDLE* ThreadHandle);




