#include"pch.h"
#include"StringHelper.h"


ULONG RtlAnsiLength(CHAR* VirtualAddress)
{
    ULONG       Length = 0;

    while (*VirtualAddress != 0)
    {
        Length++;
        VirtualAddress++;
    }

    return Length;
}

ULONG RtlUnicodeLength(WCHAR* VirtualAddress)
{
    ULONG       Length = 0;
    while (*VirtualAddress != 0)
    {
        Length++;
        VirtualAddress++;
    }

    return Length;
}