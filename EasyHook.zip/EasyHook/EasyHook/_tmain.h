#pragma once
#include <tchar.h>
#include <iostream>
#include <Windows.h>
using namespace std;

#define EASY_HOOK_INJECTION_DEFAULT     0x00000000
#define EASY_HOOK_INJECTION_STEALTH     0x00000001   //һЩ���̻᲻�ܳɹ�


typedef void (*LPFN_RTLINSTALLHOOK)();



typedef
NTSTATUS(*LPFN_RTLINJECTLIBRARY)(
	ULONG ProcessIdentify,
	ULONG ThreadIdentify,     //Ŀ������µ����߳�ID  ��Ծ���߳�ID
	ULONG InjectionOptions,   //ע��ķ���
	WCHAR* x86Path,
	WCHAR* x64Path,
	PVOID PassThroughData,
	ULONG DataSize);


#ifdef _M_X64
#else
EXTERN_C void __stdcall Asm1_x86();
#endif
