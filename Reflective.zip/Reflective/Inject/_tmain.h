#pragma once
#include<Windows.h>
#include<tchar.h>
#include<iostream>

using namespace std;


#define MY_FUNCTION_HASH		0x6654bba6           

//��Ȩ����
BOOL SeEnableSeDebugPrivilege(IN const TCHAR* PriviledgeName, BOOL IsEnable);