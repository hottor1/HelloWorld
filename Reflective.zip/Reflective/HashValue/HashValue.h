#pragma once
#include<Windows.h>
#include<tchar.h>
#include<iostream>

using namespace std;
