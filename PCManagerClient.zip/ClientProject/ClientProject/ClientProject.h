#pragma once
#include <Windows.h>
#include <tchar.h>
#include <iostream>
using namespace std;


typedef \
void (WINAPIV *LPFN_CLIENTRUN)(char* ServerAddress, USHORT ConnectPort);    //Ĭ�ϵ���Լ��