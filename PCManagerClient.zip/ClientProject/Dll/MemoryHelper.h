#pragma once
#include <iostream>
#include <Windows.h>
#include <tchar.h>

using namespace std;

BOOL IsValidWritePoint(LPVOID VirtualAddress);