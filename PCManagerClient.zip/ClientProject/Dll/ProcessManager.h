#pragma once
#include "Manager.h"
#include "ProcessHelper.h"
#include "SystemHelper.h"
#include "MemoryHelper.h"
#include "Common.h"
class CProcessManager :
    public CManager
{
public:

    CProcessManager(CIocpClient* IocpClient);
    ~CProcessManager();
    BOOL SendClientProcessList();
    void HandleIo(PBYTE BufferData, ULONG_PTR BufferLength);
};

