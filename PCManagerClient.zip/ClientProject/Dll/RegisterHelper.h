#pragma once
#include<Windows.h>
enum MYKEY {
	MHKEY_CLASSES_ROOT,
	MHKEY_CURRENT_USER,
	MHKEY_LOCAL_MACHINE,
	MHKEY_USERS,
	MHKEY_CURRENT_CONFIG
};


enum KEYVALUE {
	MREG_SZ,
	MREG_DWORD,
	MREG_BINARY,
	MREG_EXPAND_SZ
};

//��ͷ
struct PACKET_HEADER {
	int   v1;          //���ָ���
	DWORD v2;          //���ִ�С
	DWORD v3;          //ֵ��С

};

class CRegister
{
public:
	CRegister(char IsToken);
	~CRegister();
	void SetPath(char* KeyPath);
	char* FindPath();
	char* FindKey();
private:
	HKEY m_KeyHandle;
	char m_KeyPath[MAX_PATH];
};