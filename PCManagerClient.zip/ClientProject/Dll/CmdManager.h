#pragma once
#include "Manager.h"
class CCmdManager :
    public CManager
{
public:
    CCmdManager(CIocpClient* IocpClient);
    ~CCmdManager();
    void HandleIo(PBYTE BufferData, ULONG_PTR BufferLength);
    static  DWORD WINAPI  ReceiveProcedure(LPVOID ParameterData);    //��Cmd��ȡ����

public:
    HANDLE  m_ReadHandle1;
    HANDLE  m_WriteHandle1;
    HANDLE  m_ReadHandle2;
    HANDLE  m_WriteHandle2;
    HANDLE  m_ThreadHandle;
    HANDLE  m_CmdProcessHandle;
    HANDLE  m_CmdThreadHandle;
    BOOL    m_IsLoop;
};

