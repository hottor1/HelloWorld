#include "pch.h"
#include "SystemHelper.h"



void YtShutdownSystem()
{
	DWORD LastError;
	//���ntdllģ��ĺ���
	HMODULE NtdllModuleBase = LoadLibrary(_T("Ntdll.DLL"));
	LastError = GetLastError();
	if (NtdllModuleBase == NULL)
	{
		return;
	}
	typedef int(_stdcall* LPFN_ZWSHUTDOWNSYSTEM)(int);
	LPFN_ZWSHUTDOWNSYSTEM  ZwShutdownSystem = NULL;
	ZwShutdownSystem = (LPFN_ZWSHUTDOWNSYSTEM)GetProcAddress(NtdllModuleBase, "ZwShutdownSystem");
	int a;
	if (ZwShutdownSystem == NULL)
	{
		goto Exit;
	}
	//�ػ�
	ZwShutdownSystem(2);
Exit:
	if (NtdllModuleBase != NULL)
	{
		FreeLibrary(NtdllModuleBase);
		NtdllModuleBase = NULL;
	}
}