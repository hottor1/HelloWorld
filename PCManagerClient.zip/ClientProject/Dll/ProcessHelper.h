#pragma once
#include <iostream>
#include <Windows.h>
#include <tchar.h>
#include <vector>
#include <TlHelp32.h>
#include <Psapi.h>
#pragma comment(lib,"Psapi.lib")
using namespace std;

#pragma pack(1)
typedef struct PROCESS_INFORMATION_ITEM
{
	HANDLE ProcessIdentity;
	TCHAR   ProcessImageName[MAX_PATH];
	TCHAR   ProcessFullPath[MAX_PATH];
	TCHAR   IsWow64Process[20];
}PROCESS_INFORMATION_ITEM, * PPROCESS_INFORMATION_ITEM;


int YtEnableSeDebugPrivilege(HANDLE ProcessHandle, BOOL IsEnable, LPCTSTR RequireLevel);
BOOL YtIsWow64Process(HANDLE ProcessHandle, BOOL* IsWow64Process);
BOOL YtEnumProcessByToolHelp32(vector<PROCESS_INFORMATION_ITEM>& ProcessInfo);
VOID YtKillProcess(LPBYTE BufferData, UINT BufferLength);
void YtCreateProcesse(LPBYTE BufferData, UINT BufferLength);