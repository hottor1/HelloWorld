#pragma once
#include"Common.h"

void* WriteProcessMemoryEx(HANDLE ProcessHandle, void* BufferData, SIZE_T BufferLength);