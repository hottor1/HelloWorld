#include"ProcessHelper.h"
#include"ModuleHelper.h"
#include"SystemHelper.h"
#include"PEHelper.h"


namespace _PROCESS_
{


	BOOL EnableDebugPrivilege = TRUE;


	BOOL YtIsValidProcessExtra(const TCHAR* ImageName)		//�жϽ������Ƿ�Ϸ�
	{
		if (!ImageName || IsBadReadPtr(ImageName, (_tcslen(ImageName) + 1) * sizeof(TCHAR)))
		{
			return FALSE;
		}
		unsigned int Length = (unsigned int)_tcslen(ImageName);		//�õ��������ĳ���
		unsigned int v1 = (unsigned int)_tcslen(_T(".exe"));		//�õ�.exe�ĳ���
		if (Length >= v1)		//ImageName����.exe�Ϸ�
			return !_tcscmp(ImageName + Length - v1, _T(".exe"));		//�ж��Ƿ���exe�ļ����������׵�ַ+���ȵõ�-.exe���ȱȽ��Ƿ���exe�ļ�
		return FALSE;
	}

	HANDLE YtGetProcessIdentity(const TCHAR* ImageName)
	{
		ULONG BufferLength = 0x1000;
		void* BufferData = NULL;
		NTSTATUS Status = STATUS_INFO_LENGTH_MISMATCH;   //���Ȳ�ƥ�� �ڴ涯̬����
		HMODULE ModuleBase = (HMODULE)_MODULE_::GetModuleHandle(_T("ntdll.dll"));
		//ͨ���Լ�ʵ��GetProcaddress��ģ���и��ݺ������Һ�����ַ
		LPFN_NTQUERYSYSTEMINFORMATION NtQuerySystemInformation =
			(LPFN_NTQUERYSYSTEMINFORMATION)_PROCESS_::GetProcAddress(ModuleBase, "NtQuerySystemInformation");

		if (NtQuerySystemInformation == NULL)
		{
			return NULL;
		}
		//��õ�ǰ����Ĭ�϶�
		void* HeapHandle = GetProcessHeap();

		HANDLE ProcessIdentity = 0;

		BOOL IsLoop = FALSE;
		BOOL IsOk = FALSE;
		while (!IsLoop)
		{
			//�ڵ�ǰ���̵�Ĭ�϶���
			BufferData = HeapAlloc(HeapHandle, HEAP_ZERO_MEMORY, BufferLength);  //��ǰ����Ĭ�϶������ڴ�
			if (BufferData == NULL)
			{
				return NULL;
			}

			Status = NtQuerySystemInformation(SystemProcessInformation, BufferData, BufferLength, &BufferLength);
			if (Status == STATUS_INFO_LENGTH_MISMATCH)		//�ڴ治��
			{
				IsOk = TRUE;
				HeapFree(HeapHandle, NULL, BufferData);
				BufferLength *= 2;
			}
			else if (!NT_SUCCESS(Status))   //�����ڴ治���ı���
			{
				HeapFree(HeapHandle, NULL, BufferData);
				return 0;
			}
			else
			{
				IsOk = FALSE;

				PSYSTEM_PROCESS_INFORMATION SystemProcessInfo = (PSYSTEM_PROCESS_INFORMATION)BufferData;
				while (SystemProcessInfo)
				{

					if (SystemProcessInfo->UniqueProcessId == 0)
					{

					}
					else
					{
						if (_tcsicmp(SystemProcessInfo->ImageName.Buffer, ImageName) == 0)
						{
							ProcessIdentity = SystemProcessInfo->UniqueProcessId;
							IsOk = TRUE;

							break;
						}
					}

					if (!SystemProcessInfo->NextEntryOffset)
					{
						break;
					}

					SystemProcessInfo = (PSYSTEM_PROCESS_INFORMATION)((unsigned char*)SystemProcessInfo + SystemProcessInfo->NextEntryOffset);
				}
				if (BufferData)
				{
					HeapFree(HeapHandle, NULL, BufferData);
				}

			}

			if (ProcessIdentity != 0)
			{
				break;
			}
			else if (!IsOk)
			{
				// Don't continuously search...
				break;
			}
		}

		return ProcessIdentity;
	}

	HANDLE YtOpenProcess(DWORD DesiredAccess, BOOL IsInheritHandle, HANDLE ProcessIdentity)
	{
		if (EnableDebugPrivilege)
		{
			YtEnableSeDebugPrivilege(GetCurrentProcess(), TRUE);
		}
		HANDLE ProcessHandle = ::OpenProcess(DesiredAccess, IsInheritHandle, (DWORD)ProcessIdentity);
		DWORD Error = GetLastError();
		DWORD LastError = GetLastError();
		if (EnableDebugPrivilege)
		{
			YtEnableSeDebugPrivilege(GetCurrentProcess(), FALSE);
		}
		SetLastError(LastError);
		return ProcessHandle;
	}
	
	BOOL YtEnableSeDebugPrivilege(HANDLE ProcessHandle, BOOL IsEnable)
	{
		DWORD  LastError;
		HANDLE TokenHandle = 0;
		//���̾���õ����ƾ��
		if (!OpenProcessToken(ProcessHandle, TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &TokenHandle))
		{
			LastError = GetLastError();
			if (TokenHandle)
				CloseHandle(TokenHandle);
			return LastError;
		}
		TOKEN_PRIVILEGES TokenPrivileges;
		memset(&TokenPrivileges, 0, sizeof(TOKEN_PRIVILEGES));
		LUID v1;
		if (!LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &v1))
		{
			LastError = GetLastError();
			CloseHandle(TokenHandle);
			return LastError;
		}
		TokenPrivileges.PrivilegeCount = 1;
		TokenPrivileges.Privileges[0].Luid = v1;
		if (IsEnable)
			TokenPrivileges.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		else
			TokenPrivileges.Privileges[0].Attributes = 0;
		AdjustTokenPrivileges(TokenHandle, FALSE, &TokenPrivileges, sizeof(TOKEN_PRIVILEGES), NULL, NULL);
		LastError = GetLastError();
		CloseHandle(TokenHandle);
		return LastError;
	}

	//�жϵ�ǰ����������32λ����64λ��
	int  YtGetProcessPlatform(HANDLE ProcessHandle)
	{
		//��ǰ����
		if (ProcessHandle == (HANDLE)((LONG_PTR)-1))   //�ж��Լ�
		{
#if defined(_M_IX86)		//32λ
			return WIN_VERSION_X86;
#elif defined(_M_X64)		//64λ
			return WIN_VERSION_X64;
#endif
		}
		switch (GetProcessorArchitecture())
		{
		case PROCESSOR_ARCHITECTURE_INTEL:    //���������x86
		{
			return WIN_VERSION_X86;
		}
		case PROCESSOR_ARCHITECTURE_AMD64:
		{

			ULONG_PTR IsWow64;
			NTSTATUS  Status;

			HMODULE ModuleBase = (HMODULE)_MODULE_::GetModuleHandle(_T("ntdll.dll"));
			LPFN_NTQUERYINFORMATIONPROCESS NtQueryInformationProcess =
				(LPFN_NTQUERYINFORMATIONPROCESS)_PROCESS_::GetProcAddress(ModuleBase, "NtQueryInformationProcess");

			//�ж�Ŀ����̣���ѯ�Ƿ�������Wow64������
			Status = NtQueryInformationProcess(ProcessHandle, ProcessWow64Information, &IsWow64, sizeof(IsWow64), NULL);
			if (NT_SUCCESS(Status))		//
			{
#ifdef _WIN64		//��64λ�£������IsWow64����������x86�£�����������x64��
				return (IsWow64 != 0) ? WIN_VERSION_X86 : WIN_VERSION_X64;
#else
				return (IsWow64 == 0) ? WIN_VERSION_X64 : WIN_VERSION_X86;
#endif
			}
#ifdef _WIN64
			return WIN_VERSION_X64;
#else
			return WIN_VERSION_X86;
#endif
			break;

		}

		}
		return STATUS_NOT_SUPPORTED;
	}

	wstring GetProcessDirectoryW(HANDLE ProcessHandle)		//ֻ��Ҫ�õ������еĵ�һģ���λ��
	{
		PPROCESS_BASIC_INFORMATION ProcessBasicInfo = NULL;
		PEB Peb;
		PEB_LDR_DATA PebLdrData;
		//��õ�ǰ���̶�
		HANDLE	HeapHandle = GetProcessHeap();
		DWORD v1 = sizeof(PROCESS_BASIC_INFORMATION);
		ProcessBasicInfo = (PPROCESS_BASIC_INFORMATION)HeapAlloc(HeapHandle, HEAP_ZERO_MEMORY, v1);

		ULONG ReturnLength = 0;

		LPFN_NTQUERYINFORMATIONPROCESS NtQueryInformationProcess =
			(LPFN_NTQUERYINFORMATIONPROCESS)_PROCESS_::GetProcAddress(_MODULE_::GetModuleHandle(_T("ntdll.dll")),
				"NtQueryInformationProcess");

		NTSTATUS Status = NtQueryInformationProcess(ProcessHandle, ProcessBasicInformation, ProcessBasicInfo, v1, &ReturnLength);
		if (Status >= 0 && v1 < ReturnLength)
		{
			if (ProcessBasicInfo)
				HeapFree(HeapHandle, 0, ProcessBasicInfo);

			ProcessBasicInfo = (PPROCESS_BASIC_INFORMATION)HeapAlloc(HeapHandle, HEAP_ZERO_MEMORY, ReturnLength);
			if (!ProcessBasicInfo)
			{
				return NULL;
			}

			Status = NtQueryInformationProcess(ProcessHandle, ProcessBasicInformation, ProcessBasicInfo, ReturnLength, &ReturnLength);
		}
		if (Status >= 0)
		{
			if (ProcessBasicInfo->PebBaseAddress)
			{
				SIZE_T ReturnLength = 0;
				if (ReadProcessMemory(ProcessHandle, ProcessBasicInfo->PebBaseAddress, &Peb, sizeof(_PEB), &ReturnLength))
				{
					ReturnLength = 0;
					if (ReadProcessMemory(ProcessHandle, Peb.Ldr, &PebLdrData, sizeof(PEB_LDR_DATA), &ReturnLength))
					{
						LIST_ENTRY* ListEntry = (LIST_ENTRY*)PebLdrData.InLoadOrderModuleList.Flink;
						LIST_ENTRY* v1 = PebLdrData.InLoadOrderModuleList.Flink;

						LDR_DATA_TABLE_ENTRY v2 = { 0 };
						ReturnLength = 0;
						if (!ReadProcessMemory(ProcessHandle, (void*)v1, &v2, sizeof(LDR_DATA_TABLE_ENTRY), &ReturnLength))
						{
							if (ProcessBasicInfo)
							{
								HeapFree(HeapHandle, 0, ProcessBasicInfo);
							}

							return NULL;
						}

						v1 = v2.InLoadOrderModuleList.Flink;   //�����еĵ�һ���ڵ��ǿսڵ�

						wchar_t v3[MAX_PATH] = { 0 };
						if (v2.BaseDllName.Length > 0)
						{
							ReturnLength = 0;
							if (ReadProcessMemory(ProcessHandle, (LPCVOID)v2.FullDllName.Buffer, &v3, v2.FullDllName.Length, &ReturnLength))
							{
								wchar_t* v4 = 0;
								v4 = wcsrchr(v3, L'\\');
								if (!v4)
									v4 = wcsrchr(v3, L'/');

								*v4++ = L'\0';

								return std::wstring(v3);
							}
						}
					}
				}
			}
		}

		if (ProcessBasicInfo)
		{
			HeapFree(HeapHandle, 0, ProcessBasicInfo);
		}

		return wstring();
	}

	

	void* GetProcAddress(HMODULE ModuleBase, const char* Keyword)		//ͨ��ģ�����õ�ģ���ַ
	{
		char* v1 = (char*)ModuleBase;

		IMAGE_DOS_HEADER* ImageDosHeader = (IMAGE_DOS_HEADER*)v1;		//Dosͷ
		IMAGE_NT_HEADERS* ImageNtHeaders = (IMAGE_NT_HEADERS*)((size_t)v1 + ImageDosHeader->e_lfanew);

		IMAGE_OPTIONAL_HEADER* ImageOptionalHeader = &ImageNtHeaders->OptionalHeader;
		IMAGE_DATA_DIRECTORY* ImageDataDirectory = (IMAGE_DATA_DIRECTORY*)(&ImageOptionalHeader->DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT]);
		IMAGE_EXPORT_DIRECTORY* ImageExportDirectory = (IMAGE_EXPORT_DIRECTORY*)((size_t)v1 + ImageDataDirectory->VirtualAddress);


		if (ImageExportDirectory->NumberOfNames == 0 || ImageExportDirectory->NumberOfFunctions == 0)
		{
			return NULL;
		}

		DWORD* AddressOfFunctions = (DWORD*)((size_t)v1 + ImageExportDirectory->AddressOfFunctions);
		DWORD* AddressOfNames = (DWORD*)((size_t)v1 + ImageExportDirectory->AddressOfNames);
		WORD* AddressOfNameOrdinals = (WORD*)((size_t)v1 + ImageExportDirectory->AddressOfNameOrdinals);

		void* FunctionAddress = NULL;
		DWORD i;

		//��������
		if (((ULONG_PTR)Keyword >> 16) == 0)
		{
			WORD Ordinal = LOWORD(Keyword);
			ULONG_PTR Base = ImageExportDirectory->Base;

			if (Ordinal < Base || Base > Base + ImageExportDirectory->NumberOfFunctions)
			{
				return NULL;
			}
			FunctionAddress = (void*)((size_t)v1 + AddressOfFunctions[Ordinal - Base]);
		}
		else  //�������Ƶ���
		{
			for (i = 0; i < ImageExportDirectory->NumberOfNames; i++)
			{

				//��ú�������
				char* FunctionName = (char*)((size_t)v1 + AddressOfNames[i]);
				if (_stricmp(Keyword, FunctionName) == 0)
				{
					FunctionAddress = (void*)((size_t)v1 + AddressOfFunctions[AddressOfNameOrdinals[i]]);
					break;
				}
			}
		}

		//����ת����
		if ((char*)FunctionAddress >= (char*)ImageExportDirectory &&
			(char*)FunctionAddress < (char*)ImageExportDirectory + ImageDataDirectory->Size)
		{
			HMODULE v2 = 0;

			//���ת��ģ������ƣ�����ת���������Ըú�����ַӦ����һ��ģ���ַ
			//FunctionAddress =  //Dll.Sub_1........  Dll.#2
			char* v3 = _strdup((char*)FunctionAddress);		//��������ַ������v3����
			if (!v3)		//������ַΪ��
			{
				return NULL;
			}
			char* FunctionName = strchr(v3, '.');		//����v3�е�һ�γ���.��λ�á�
			*FunctionName++ = 0;			//

			FunctionAddress = NULL;

			//����ת��ģ���·��
			char FullPath[MAX_PATH] = { 0 };
			strcpy_s(FullPath, v3);		//��v3������FullPath
			strcat_s(FullPath, strlen(v3) + 4 + 1, ".dll");		//�����ַ�����

			//�ж��ǲ��ǵ�ǰ�����Ѿ����������ת��ģ��
			v2 = (HMODULE)_MODULE_::GetModuleHandleA(FullPath);
			if (!v2)
			{
				v2 = LoadLibraryA(FullPath);
			}
			if (!v2)
			{
				return NULL;
			}

			BOOL v4 = strchr(v3, '#') == 0 ? FALSE : TRUE;
			if (v4)
			{
				//��������ת��
				WORD FunctionOrdinal = atoi(v3 + 1);
				//�ݹ��Լ�
				FunctionAddress = _PROCESS_::GetProcAddress(v2, (const char*)FunctionOrdinal);
			}
			else
			{
				//��������ת��
				FunctionAddress = _PROCESS_::GetProcAddress(v2, FunctionName);
			}

			free(v2);
		}
		return FunctionAddress;
	}

	BOOL ExecuteProcessMemoryData(HANDLE ProcessHandle, SHELL_CODE ShellCode, BOOL IsSynchronization)
	{
		void* v5 = NULL;

		//��̬�����ڴ�
		unsigned char* v1 = new unsigned char[ShellCode.size()];		//��̬�����ڴ�
		//Vector�е�ShellCode���ڵ�v5��
		for (int i = 0; i < (int)ShellCode.size(); i++)
		{
			v1[i] = ShellCode[i];
		}

		//��Ŀ����̿ռ��������ڴ沢д��ShellCode
		v5 = WriteProcessMemoryEx(ProcessHandle, v1, ShellCode.size());

		delete[] v1;

		if (v5 == NULL)  //�ж�Ŀ��������Ƿ����ڴ�
		{
			return FALSE;
		}
		//��Ŀ����̿ռ���ִ��Զ���߳�
		HANDLE ThreadHandle = NtCreateThreadEx(ProcessHandle, (LPTHREAD_START_ROUTINE)v5, NULL, NULL);
		if (ThreadHandle == INVALID_HANDLE_VALUE)
		{
			VirtualFreeEx(ProcessHandle, v5, ShellCode.size(), MEM_RELEASE);
			return FALSE;
		}

		if (IsSynchronization)
		{
			WaitForSingleObject(ThreadHandle, INFINITE);
		}

		VirtualFreeEx(ProcessHandle, v5, ShellCode.size(), MEM_RELEASE);

		return TRUE;
	}

	HANDLE NtCreateThreadEx(HANDLE ProcessHandle, LPVOID ThreadProcedure, LPVOID ParameterData, DWORD* ThreadIdentity)
	{
		LPFN_NTCREATETHREADEX NtCreateThreadEx =
			(LPFN_NTCREATETHREADEX)_PROCESS_::GetProcAddress(_MODULE_::GetModuleHandle(_T("ntdll.dll")), "NtCreateThreadEx");
		if (NtCreateThreadEx == NULL)
		{
			return NULL;
		}
		PS_ATTRIBUTE_LIST PsAttributeList;
		ZeroMemory(&PsAttributeList, sizeof(PS_ATTRIBUTE_LIST));
		CLIENT_ID ClientIdentity;
		ZeroMemory(&ClientIdentity, sizeof(CLIENT_ID));

		PsAttributeList.Attributes[0].Attribute = ProcThreadAttributeValue(PS_ATTRIBUTE_CLIENTID, TRUE, FALSE, FALSE);
		PsAttributeList.Attributes[0].Size = sizeof(CLIENT_ID);
		PsAttributeList.Attributes[0].ValuePtr = (ULONG_PTR*)&ClientIdentity;

		PsAttributeList.TotalLength = sizeof(PS_ATTRIBUTE_LIST);

		HANDLE ThreadHandle = NULL;
		HRESULT hRes = 0;

		if (!NT_SUCCESS(NtCreateThreadEx(&ThreadHandle, THREAD_ALL_ACCESS, NULL, ProcessHandle, ThreadProcedure, \
			ParameterData, 0, 0, 0x1000, 0x100000, &PsAttributeList)))
			return NULL;

		if (ThreadIdentity)
		{
			*ThreadIdentity = (DWORD)ClientIdentity.UniqueThread;
		}
		return ThreadHandle;
	}
};