#pragma once
#include"Common.h"

namespace _PE_
{

	IMAGE_DOS_HEADER* GetImageDosHeader(PVOID VirtualAddress);
	IMAGE_NT_HEADERS* GetImageNtHeaders(PVOID VirtualAddress);
	void* RvaToPointer(ULONG Rva, PVOID VirtualAddress);
};