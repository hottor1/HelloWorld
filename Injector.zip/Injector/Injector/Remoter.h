#pragma once
#include"Common.h"
#include<algorithm>
#include<map>
#include<vector>
#include"ProcessHelper.h"
#include"Template.h"
#include"SystemHelper.h"
#include"FileHelper.h"
#include"PEHelper.h"
#include"ModuleHelper.h"
#include"AsmKernel.h"
typedef map<wstring, vector<wstring>> SCHEMA;     //��������



class CRemoter
{
public:
	CRemoter();
	virtual ~CRemoter()
	{

	}

	BOOL InitializeApiSchema();
	void OnInitMember(HANDLE ProcessIdentity, HANDLE ProcessHandle);

#ifdef UNICODE
#define LoadLibraryByPathIntoMemory  LoadLibraryByPathIntoMemoryW
#else
#define LoadLibraryByPathIntoMemory  LoadLibraryByPathIntoMemoryA
#endif // !UNICODE

	HMODULE LoadLibraryByPathIntoMemoryW(const WCHAR* ModulePath, BOOL IsPeHeader);
	HMODULE LoadLibraryByPathIntoMemoryA(const char* ModulePath, BOOL IsPeHeader);
	HMODULE LoadLibraryFromMemory(PVOID FileData, DWORD FileLength, BOOL IsPeHeader);  //���ģ��������ض�̬��
	BOOL FixImportTable(PVOID VirtualAddress, PVOID ModuleBase);		//������޸�
	DWORD ResolvePath(wstring& ModulePath, RESOLVE_FLAG ResolveFlag, const wstring& BaseName = L"");		//
	DWORD ProbeSxSRedirect(wstring& FilePath);  //һ��Dll�������·���ķ���

	HMODULE LoadLibraryByPathA(const char* ModulePath, ULONG Flags = NULL);
	HMODULE LoadLibraryByPathW(const WCHAR* ModulePath, ULONG Flags = NULL);

	//Ŀ����̵������л�ȡ����
	FARPROC GetProcessProcAddressW(HANDLE ProcessHandle, HMODULE ModuleBase, const WCHAR* Keyword);
	FARPROC GetProcessProcAddressA(HANDLE ProcessHandle, HMODULE ModuleBase, const char* Keyword);


	template<typename T1, typename T2, typename T3, typename T4>
	BOOL Initialize_T()
	{
		if (!m_ApiSchemaMap.empty())
		{
			//���ݲ�Ϊ��
			return TRUE;
		}
		//�ӵ�ǰ���̵�Teb��ȡPebֵ
		PEB_T* Peb = reinterpret_cast<PEB_T*>(reinterpret_cast<TEB_T*>(NtCurrentTeb())->ProcessEnvironmentBlock);
		T1 ApiSetMap = reinterpret_cast<T1>(Peb->ApiSetMap);

		for (DWORD i = 0; i < ApiSetMap->Count; i++)
		{
			T2 Descriptor = ApiSetMap->Entry(i);

			std::vector<std::wstring> v6;
			wchar_t DllName[MAX_PATH] = { 0 };

			ApiSetMap->GetApiName(Descriptor, DllName);
			std::transform(DllName, DllName + MAX_PATH, DllName, ::tolower);

			T3 HostData = ApiSetMap->GetValueArray(Descriptor);

			for (DWORD j = 0; j < HostData->Count; j++)
			{
				T4 v4 = HostData->Entry(ApiSetMap, j);
				std::wstring v5((wchar_t*)((BYTE*)ApiSetMap + v4->ValueOffset), v4->ValueLength / sizeof(wchar_t));

				if (!v5.empty())
					v6.push_back(v5);
			}
			m_ApiSchemaMap.insert(std::make_pair(DllName, v6));
		}
		return TRUE;
	}

private:
	SCHEMA m_ApiSchemaMap;				//
	HANDLE m_ProcessIdentity = 0;		//����ID
	HANDLE m_ProcessHandle = NULL;		//���̾��
	BOOL   m_Is64Bit;					//�ж�λ��
	CAsmKernel m_AsmKernel;
};

