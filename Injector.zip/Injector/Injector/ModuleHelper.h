#pragma once
#include"Common.h"
#include"ProcessHelper.h"

namespace _MODULE_
{
#ifdef UNICODE
#define GetModuleHandle  GetModuleHandleW
#define GetProcessModuleHandle  GetProcessModuleHandleW

#else
#define GetModuleHandle  GetModuleHandleA
#define GetProcessModuleHandle  GetProcessModuleHandleA
#endif // !UNICODE

	HMODULE GetModuleHandleA(const char* ModuleName);		//����ģ�����õ�ģ����
	HMODULE GetModuleHandleW(const WCHAR* ModuleName);

	HMODULE GetProcessModuleHandleW(HANDLE ProcessHandle, const WCHAR* ModuleName);
	HMODULE	GetProcessModuleHandleA(HANDLE ProcessHandle, const char* ModuleName);
};