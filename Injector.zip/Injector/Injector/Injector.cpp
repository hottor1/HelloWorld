#include "Injector.h"
#include "ProcessHelper.h"
CInjector::CInjector()
{
}

CInjector::~CInjector()
{
}

NTSTATUS CInjector::Inject(_tstring ImageName, _tstring ModulePath)
{
	NTSTATUS Status = STATUS_SUCCESS;
	//�жϴ����ProcessImageName�Ƿ�Ϸ�
	if (!_PROCESS_::YtIsValidProcessExtra(ImageName.c_str()))		
	{
		return STATUS_INVALID_PARAMETER_1;
	}

	if (_tcslen(ModulePath.c_str()) < 5)  //.dll\0
	{
		return STATUS_INVALID_PARAMETER_2;
	}

	HANDLE ProcessIdentity = _PROCESS_::YtGetProcessIdentity(ImageName.c_str());


	HANDLE ProcessHandle = _PROCESS_::YtOpenProcess(
		PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_WRITE | PROCESS_VM_READ, FALSE, ProcessIdentity);

	if (ProcessHandle == NULL)
	{
		return STATUS_UNSUCCESSFUL;
	}


	//���ݽ���ID����̾����CRemoter����
	m_Remoter.OnInitMember(ProcessIdentity, ProcessHandle);
	HMODULE ModuleBase = NULL;
	ModuleBase = m_Remoter.LoadLibraryByPathIntoMemory(ModulePath.c_str(), TRUE);	//��ȡ��ǰ�ļ���DLL�ļ�
	return Status;
}
