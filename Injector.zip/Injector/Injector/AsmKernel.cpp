#include "AsmKernel.h"



void CAsmKernel::AddByteToBuffer(unsigned char DataValue)
{
	m_ShellCode.push_back(DataValue);
}
void CAsmKernel::AddLongToBuffer(unsigned long DataValue)
{
	WORD LowWord = LOWORD(DataValue);
	WORD HighWord = HIWORD(DataValue);

	AddByteToBuffer(LOBYTE(LowWord));
	AddByteToBuffer(HIBYTE(LowWord));
	AddByteToBuffer(LOBYTE(HighWord));
	AddByteToBuffer(HIBYTE(HighWord));
}
void CAsmKernel::AddLong64ToBuffer(unsigned __int64 DataValue)
{
	unsigned long LowInt32 = (unsigned long)DataValue;
	unsigned long HighInt32 = (unsigned long)(DataValue >> 32);

	AddLongToBuffer(LowInt32);
	AddLongToBuffer(HighInt32);
}
void CAsmKernel::BeginCall64()
{
	////mov    QWORD PTR [rsp+0x8],rcx
	////mov    QWORD PTR [rsp+0x10],rdx
	////mov    QWORD PTR [rsp+0x18],r8
	////mov    QWORD PTR [rsp+0x20],r9
	//��������Ҫ��4���Ĵ�����ֵ���浽�ڴ���
	//mov    QWORD PTR [rsp+0x8],rcx
	AddByteToBuffer(0x48);
	AddByteToBuffer(0x89);
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x24);
	AddByteToBuffer(1 * sizeof(size_t));
	//mov    QWORD PTR [rsp+0x10],rdx
	AddByteToBuffer(0x48);
	AddByteToBuffer(0x89);
	AddByteToBuffer(0x54);
	AddByteToBuffer(0x24);
	AddByteToBuffer(2 * sizeof(size_t));
	// mov    QWORD PTR [rsp+0x18],r8
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x89);
	AddByteToBuffer(0x44);
	AddByteToBuffer(0x24);	//rsp
	AddByteToBuffer(3 * sizeof(size_t));
	//mov    QWORD PTR [rsp+0x20],r9
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x89);
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x24);
	AddByteToBuffer(4 * sizeof(size_t));
}
void CAsmKernel::EndCall64()
{
	//Restore registers and return

	// mov    rcx,QWORD PTR [rsp+0x8]
	AddByteToBuffer(0x48);
	AddByteToBuffer(0x8B);
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x24);
	AddByteToBuffer(1 * sizeof(size_t));
	// mov    rdx,QWORD PTR [rsp+0x10]
	AddByteToBuffer(0x48);
	AddByteToBuffer(0x8B);
	AddByteToBuffer(0x54);
	AddByteToBuffer(0x24);
	AddByteToBuffer(2 * sizeof(size_t));
	// mov    r8,QWORD PTR [rsp+0x18]
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x8B);
	AddByteToBuffer(0x44);
	AddByteToBuffer(0x24);
	AddByteToBuffer(3 * sizeof(size_t));
	// mov    r9,QWORD PTR [rsp+0x20]
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x8B);
	AddByteToBuffer(0x4C);
	AddByteToBuffer(0x24);
	AddByteToBuffer(4 * sizeof(size_t));
	// ret
	AddByteToBuffer(0xC3);
}
void CAsmKernel::PushUnicodeString(const wchar_t* DataValue)
{
	PushParameter(PARAMETER_TYPE_WSTRING, (void*)DataValue);
}
void CAsmKernel::PushInt(int DataValue)
{
	int* v1 = new int;
	*v1 = DataValue;
	PushParameter(PARAMETER_TYPE_INT, v1);
}
void CAsmKernel::PushParameter(PARAMETER_TYPE ParameterType, void* ParameterData)
{
	PARAMETER_INFORMATION ParameterInfo;

	ParameterInfo.ParameterType = ParameterType;
	ParameterInfo.ParameterData = ParameterData;

	m_CurrentInvokeInfo.ParameterInfoVector.push_back(ParameterInfo);
}



void CAsmKernel::PushCall(HANDLE ProcessHandle, CALLING_CONVENTION CallingConvention, FARPROC CallingAddress, BOOL Is64Bit)
{
	int v1 = (int)m_CurrentInvokeInfo.ParameterInfoVector.size();   //��ȡ��ǰҪ���ݵĲ�������
	//���ú����ĵ�ַ
	m_CurrentInvokeInfo.CallingAddress = Is64Bit ? (unsigned __int64)CallingAddress : (unsigned long)CallingAddress;
	m_CurrentInvokeInfo.CallingConvention = CallingConvention;		//��ȡ����Լ��
	//64λ32λ��FastCall�ĵ���
	if ((Is64Bit || CallingConvention == CALLING_CONVENTION_WIN64) || CallingConvention == CALLING_CONVENTION_FASTCALL)
	{
		if (Is64Bit)		//�����64λ����
		{
			////////////////////////////////////////////////////////////////////////////////////////////////
			//  First things first. 64 bit mandatory "shadow" space of at least 40 bytes for EVERY call   //
			//  Stack is 16 byte aligned. Every other param after rcx, rdx, r8, and r9 */				  //
			//  should be pushed onto the stack 														  //
			////////////////////////////////////////////////////////////////////////////////////////////////
			//
			//Reserve stack size (0x28 - minimal size for 4 registers and return address)
			//after call, stack must be aligned on 16 bytes boundary
			//
			//Ϊ��ջ��׼���������ǰ�����ĸ���>4,��ʹ�ò�������*sizeof(size_t)��Ϊջ�ռ䣬���������0x28���ֽڴ�С��ջ�ռ�
			size_t Rsp = (m_CurrentInvokeInfo.ParameterInfoVector.size() > 4) ?
				m_CurrentInvokeInfo.ParameterInfoVector.size() * sizeof(size_t) : 0x28;
			Rsp = BoundaryAlign(Rsp, 0x10);   //�߽����
			//sub  rsp, (Rsp + 8)
			AddByteToBuffer(0x48);
			AddByteToBuffer(0x83);
			AddByteToBuffer(0xEC);
			AddByteToBuffer((unsigned char)(Rsp + 8));

			//����в���
			if (v1 > 0)
			{
				//ǰ4������
				for (int i = 0; i < PARAMETER_INDEX_MAX; i++)
				{
					if (m_CurrentInvokeInfo.ParameterInfoVector.size() == 0)		//��������Ϊ0
					{
						break;
					}
					//�жϲ�������
					if (_PARAMETER_TYPE_STRING_(m_CurrentInvokeInfo.ParameterInfoVector[0].ParameterType))
					{
						LoadStringParameter64(ProcessHandle, m_CurrentInvokeInfo.ParameterInfoVector[0], (PARAMETER_INDEX)i, Is64Bit);
					}
					else
					{
						//��ȡ��ַ�е�����
						unsigned __int64 ParameterData = *(unsigned __int64*)m_CurrentInvokeInfo.ParameterInfoVector[0].ParameterData; // rcx param
						//���Զ�����������ڴ�
						/*
						if (m_CurrentInvokeInfo.ParameterInfoVector[0].ParameterData != NULL)
						{
							delete m_CurrentInvokeInfo.ParameterInfoVector[0].ParameterData;
						}*/

						LoadParameter64(ParameterData, (PARAMETER_INDEX)i);
					}

					m_CurrentInvokeInfo.ParameterInfoVector.erase(m_CurrentInvokeInfo.ParameterInfoVector.begin());
				}
				//���ڸ�����
				PushAllParameters(ProcessHandle, true, Is64Bit);
				//
				//Call function address, and clean stack
				//mov  r13, CallingAddress
				//call r13
				AddByteToBuffer(0x49);
				AddByteToBuffer(0xBD);		//mov r13,
				AddLong64ToBuffer(m_CurrentInvokeInfo.CallingAddress); // CallingAddress
				AddByteToBuffer(0x41);
				AddByteToBuffer(0xFF);		//call
				AddByteToBuffer(0xD5);		//r13
				//Clean stack
				//add rsp, (Rsp + 8)
				AddByteToBuffer(0x48);
				AddByteToBuffer(0x83);
				AddByteToBuffer(0xC4);
				AddByteToBuffer((unsigned char)(Rsp + 8));
			}

		}
		else //32 bit
		{

		}
	}

	vector<PARAMETER_INFORMATION>::iterator v100;
	for (v100 = m_CurrentInvokeInfo.ParameterInfoVector.begin(); v100 != m_CurrentInvokeInfo.ParameterInfoVector.end(); v100++)
	{
		if (v100->ParameterData != NULL)
		{
			delete v100->ParameterData;
		}
	}
	m_CurrentInvokeInfo.ParameterInfoVector.clear();
	m_CurrentInvokeInfo.CallingAddress = NULL;
}


void CAsmKernel::LoadStringParameter64(HANDLE ProcessHandle,
	PARAMETER_INFORMATION ParameterInfo, PARAMETER_INDEX ParameterIndex, BOOL Is64Bit)
{
	if (ParameterInfo.ParameterType == PARAMETER_TYPE_STRING)		
	{

	}
	else if (ParameterInfo.ParameterType == PARAMETER_TYPE_WSTRING)		//������ݹ�����������˫������
	{
		wchar_t* ParameterData = (wchar_t*)ParameterInfo.ParameterData;  //D:\User32.dll

		STRING_INFORMATION StringInfo;		//����һ���ṹ
		StringInfo.BufferLength = (ULONG)((wcslen(ParameterData) + 1) * 2); //�����ַ�������
		StringInfo.BufferData = WriteProcessMemoryEx(ProcessHandle, ParameterData, StringInfo.BufferLength);
		if (StringInfo.BufferData == NULL)
		{
			return;
		}

		m_CurrentInvokeInfo.StringInfoVector.push_back(StringInfo);   //��Ŀ����̵�ַ���뵽���ǵĽṹ�з��㹹��ShellCode

		if (Is64Bit)
		{
			LoadParameter64((unsigned __int64)StringInfo.BufferData, ParameterIndex);		//ѹ�ι���
		}
		else
		{
			//���ô���
		}
	}
	else if (ParameterInfo.ParameterType == PARAMETER_TYPE_UNICODE_STRING)
	{

	}
}
BOOL CAsmKernel::LoadParameter64(unsigned __int64 ParameterData, PARAMETER_INDEX ParameterIndex)
{
	switch (ParameterIndex)
	{
	case PARAMETER_INDEX_RCX:
	{
		//mov  rcx, pparam
		AddByteToBuffer(0x48);
		AddByteToBuffer(0xB9);
		AddLong64ToBuffer(ParameterData);
		break;
	}
	case PARAMETER_INDEX_RDX:
	{
		//mov  rdx, ulRdxParam
		AddByteToBuffer(0x48);
		AddByteToBuffer(0xBA);
		AddLong64ToBuffer(ParameterData);

		break;
	}
	case PARAMETER_INDEX_R8:
	{
		//mov  r8, ulR8Param
		AddByteToBuffer(0x49);
		AddByteToBuffer(0xB8);
		AddLong64ToBuffer(ParameterData);

		break;
	}
	case PARAMETER_INDEX_R9:
	{
		//mov  r9, ulR9Param
		AddByteToBuffer(0x49);
		AddByteToBuffer(0xB9);
		AddLong64ToBuffer(ParameterData);

		break;
	}
	default:
		return FALSE;
	}
	return TRUE;
}


void CAsmKernel::PushAllParameters(HANDLE ProcessHandle, BOOL IsRightToLeft, BOOL Is64Bit)
{
	//�ж����޲���
	if (m_CurrentInvokeInfo.ParameterInfoVector.size() == 0)
	{
		return;
	}

	vector<PARAMETER_INFORMATION> v2;

	if (IsRightToLeft == FALSE)
	{

	}
	else
	{
		//��������
		if (m_CurrentInvokeInfo.ParameterInfoVector.size() == 1)
		{
			v2.push_back(m_CurrentInvokeInfo.ParameterInfoVector.at(0));
		}
		else
		{
			int Start = (int)m_CurrentInvokeInfo.ParameterInfoVector.size() - 1;   //��λ�����
			while (Start != -1)
			{
				//��ȡ����
				v2.push_back(m_CurrentInvokeInfo.ParameterInfoVector.at(Start));   //ѹ�뵽�µ����ݽṹ��

				Start--;
			}
		}
	}

	for (int i = 0; i < (int)v2.size(); i++)
	{
		PARAMETER_INFORMATION* ParameterInfo = &v2[i];
		if (ParameterInfo == NULL)
		{
			continue;
		}
		if (ParameterInfo->ParameterData == NULL)
		{
			// push 0
			AddByteToBuffer(0x68);	// push
			AddLongToBuffer(0x00);	// 0
			continue;
		}

		switch (ParameterInfo->ParameterType)
		{
		case PARAMETER_TYPE_DOUBLE:		//8Bitsѹ��
		case PARAMETER_TYPE_INT64:
		{


			break;
		}
		case PARAMETER_TYPE_POINTER:
		{

			//�����һ��ָ�����͵�����
			if (ParameterInfo->ParameterData)		//ָ�����ݷǿ�
			{
				unsigned __int64 ParameterData = *(unsigned __int64*)ParameterInfo->ParameterData;

				if (Is64Bit)		//64λ��
				{
					// mov rax, ulParam
					AddByteToBuffer(0x48);		//�������е�ָ����ص�rax�Ĵ���
					AddByteToBuffer(0xB8);
					AddLong64ToBuffer(ParameterData);
					// push rax
					AddByteToBuffer(0x50);		//��rax�е�ֵѹ��ջ��
				}
				else
				{
					unsigned long ParameterData = *(unsigned long*)ParameterInfo->ParameterData;
					// push ulParam
					AddByteToBuffer(0x68);
					AddLongToBuffer(ParameterData);
				}
			}
			else
			{
				// if it is PARAM_TYPE_POINTER with a NULL pointer
				// we don't want to crash
				// push 0
				AddByteToBuffer(0x68);
				AddLongToBuffer(0x00);
			}
			break;
		}
		case PARAMETER_TYPE_SHORT:		//4Bitsѹ��
		case PARAMETER_TYPE_INT:
		case PARAMETER_TYPE_FLOAT:		//����������
		{
			if (ParameterInfo->ParameterData)
			{
				unsigned long ParameterData = *(unsigned long*)ParameterInfo->ParameterData;
				//push ParameterData
				AddByteToBuffer(0x68);
				AddLongToBuffer(ParameterData);
			}
			else
			{
				//push 0
				AddByteToBuffer(0x68);
				AddLongToBuffer(NULL);
			}

			break;
		}
		case PARAMETER_TYPE_BYTE:
		{
			unsigned char ParameterData = *(unsigned char*)ParameterInfo->ParameterData;
			//push ParameterData
			AddByteToBuffer(0x6A);
			AddByteToBuffer(ParameterData);

			break;
		}
		case PARAMETER_TYPE_BOOL:
		{
			bool IsParameterData = *(bool*)ParameterInfo->ParameterData;

			unsigned char ParameterData = (IsParameterData) ? 1 : 0;

			//push ParameterData
			AddByteToBuffer(0x6A);
			AddByteToBuffer(ParameterData);

			break;
		}
		case PARAMETER_TYPE_STRING:
		{
			//�����ܳ��ֵ���
			break;
		}
		case PARAMETER_TYPE_WSTRING:
		{
			wchar_t* ParameterData = (wchar_t*)ParameterInfo->ParameterData;

			STRING_INFORMATION StringInfo;

			StringInfo.BufferLength = (wcslen(ParameterData) * 2) + 1;
			StringInfo.BufferData = WriteProcessMemoryEx(ProcessHandle, ParameterData, StringInfo.BufferLength);

			if (StringInfo.BufferData == NULL)
			{

				continue;
			}

			m_CurrentInvokeInfo.StringInfoVector.push_back(StringInfo);
			AddByteToBuffer(0x68);
			AddLongToBuffer((unsigned long)StringInfo.BufferData);
			break;
		}
		case PARAMETER_TYPE_UNICODE_STRING:
		{
			UNICODE_STRING ParameterData = *(UNICODE_STRING*)ParameterInfo->ParameterData;

			STRING_INFORMATION StringInfo;
			StringInfo.BufferLength = (ULONG)(ParameterData.MaximumLength * 2) + 1;
			StringInfo.BufferData = WriteProcessMemoryEx(ProcessHandle, ParameterData.Buffer, StringInfo.BufferLength);
			//��Ŀ�����������һ���ַ����ڴ沢��ParameterData.Buffer�е�����д��Ŀ������в����ص�ַ��StringInfo.BufferData
			if (StringInfo.BufferData == NULL)
			{
				return;
			}
			m_CurrentInvokeInfo.StringInfoVector.push_back(StringInfo);

			UNICODE_STRING v1;
			v1.Buffer = (wchar_t*)StringInfo.BufferData;   //��Ŀ������б�ʶ�Ǹ��ַ������ڴ���뵽һ��UnicodeString��
			v1.Length = ParameterData.Length;
			v1.MaximumLength = ParameterData.MaximumLength;

			//�ṹ������
			STRUCT_INFORMATION v2;
			v2.BufferLength = (ULONG)sizeof(UNICODE_STRING);
			v2.BufferData = WriteProcessMemoryEx(ProcessHandle, &v1, v2.BufferLength);
			//��Ŀ�����������һ��UnicodeString�ڴ沢��v1�е�����д��Ŀ������в����ص�ַ��v2.BufferData
			m_CurrentInvokeInfo.StructInfoVector.push_back(v2);

			//push v2.BufferData
			AddByteToBuffer(0x68);
			AddLongToBuffer((unsigned long)v2.BufferData);
		}
		default:
		{

			break;
		}

		}
	}
}
void CAsmKernel::OnFreeMember(HANDLE ProcessHandle)
{

	for (size_t i = 0; i < m_CurrentInvokeInfo.StringInfoVector.size(); i++)
	{
		VirtualFreeEx(ProcessHandle, m_CurrentInvokeInfo.StringInfoVector[i].BufferData,
			m_CurrentInvokeInfo.StringInfoVector[i].BufferLength, MEM_RELEASE);
	}


	for (size_t i = 0; i < m_CurrentInvokeInfo.StructInfoVector.size(); i++)
	{
		VirtualFreeEx(ProcessHandle, m_CurrentInvokeInfo.StructInfoVector[i].BufferData,
			m_CurrentInvokeInfo.StructInfoVector[i].BufferLength, MEM_RELEASE);
	}

	m_CurrentInvokeInfo.CallingAddress = 0;
	m_CurrentInvokeInfo.ParameterInfoVector.clear();
	m_ShellCode.clear();
}