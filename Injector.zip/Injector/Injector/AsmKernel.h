#pragma once
#include <vector>
#include "Common.h"
#include "StringHelper.h"
#include"MemoryHelper.h"
typedef vector<unsigned char>	SHELL_CODE;   //��������

//����ֵ  ����Լ��  �����б�


typedef enum {
	CALLING_CONVENTION_CDECL = 0,
	CALLING_CONVENTION_STDCALL,
	CALLING_CONVENTION_THISCALL,
	CALLING_CONVENTION_FASTCALL,
	CALLING_CONVENTION_WIN64
}CALLING_CONVENTION;

//��������
typedef enum {
	PARAMETER_INDEX_RCX,
	PARAMETER_INDEX_RDX,
	PARAMETER_INDEX_R8,
	PARAMETER_INDEX_R9,
	PARAMETER_INDEX_MAX
}PARAMETER_INDEX;

//��������
typedef enum {
	PARAMETER_TYPE_INT = 0,
	PARAMETER_TYPE_INT64,
	PARAMETER_TYPE_BOOL,
	PARAMETER_TYPE_SHORT,
	PARAMETER_TYPE_FLOAT,
	PARAMETER_TYPE_DOUBLE,
	PARAMETER_TYPE_BYTE,
	PARAMETER_TYPE_POINTER,
	PARAMETER_TYPE_STRING,
	PARAMETER_TYPE_WSTRING,
	PARAMETER_TYPE_UNICODE_STRING
}PARAMETER_TYPE;


typedef struct {
	PARAMETER_TYPE			ParameterType;
	void* ParameterData;
} PARAMETER_INFORMATION;

typedef struct {
	ULONG	BufferLength;
	void* BufferData;
}STRING_INFORMATION;

typedef struct {
	ULONG	BufferLength;
	void* BufferData;
}STRUCT_INFORMATION;

#ifdef _WIN64
#define _PARAMETER_TYPE_DWORD_(ParameterType)  ParameterType  == PARAMETER_TYPE_INT    || ParameterType == PARAMETER_TYPE_FLOAT   || ParameterType == PARAMETER_TYPE_SHORT
#define _PARAMETER_TYPE_QWORD_(ParameterType)  ParameterType  == PARAMETER_TYPE_INT64  || ParameterType == PARAMETER_TYPE_DOUBLE  || ParameterType == PARAMETER_TYPE_POINTER || ParameterType == PARAMETER_TYPE_STRING || ParameterType == PARAMETER_TYPE_WSTRING
#define _PARAMETER_TYPE_STRING_(ParameterType) ParameterType  == PARAMETER_TYPE_STRING || ParameterType == PARAMETER_TYPE_WSTRING || ParameterType == PARAMETER_TYPE_UNICODE_STRING
#else
#define _PARAMETER_TYPE_DWORD_(ParameterType)  ParameterType  == PARAMETER_TYPE_INT    || ParameterType == PARAMETER_TYPE_FLOAT   || ParameterType == PARAMETER_TYPE_SHORT   || ParameterType == PARAMETER_TYPE_POINTER || ParameterType == PARAMETER_TYPE_STRING || ParameterType == PARAMETER_TYPE_WSTRING
#define _PARAMETER_TYPE_QWORD_(ParameterType)  ParameterType  == PARAMETER_TYPE_INT64  || ParameterType == PARAMETER_TYPE_DOUBLE
#define _PARAMETER_TYPE_STRING_(ParameterType) ParameterType  == PARAMETER_TYPE_STRING || ParameterType == PARAMETER_TYPE_WSTRING || ParameterType == PARAMETER_TYPE_UNICODE_STRING
#endif

//LoadLibaryW(L"D:\Hello")

typedef struct {
	CALLING_CONVENTION		            CallingConvention;			   //�����ĵ���Լ��
	vector<PARAMETER_INFORMATION>	    ParameterInfoVector;           //�����Ĳ�����Ϣ
	vector<STRING_INFORMATION>		    StringInfoVector;                //Ŀ����̿ռ��������String�ṹ
	vector<STRUCT_INFORMATION>		    StructInfoVector;                //Ŀ����̿ռ��������UnicodeString�ṹ
#ifdef _WIN64
	unsigned __int64			CallingAddress;      //���еĺ�����ַ
#else
	unsigned long				CallingAddress;
#endif

}INVOKE_INFORMATION;

class CAsmKernel
{
public:
	SHELL_CODE  m_ShellCode;
	INVOKE_INFORMATION	  m_CurrentInvokeInfo;
public:
	void AddByteToBuffer(unsigned char DataValue);
	void AddLongToBuffer(unsigned long DataValue);
	void AddLong64ToBuffer(unsigned __int64 DataValue);
public:
	void BeginCall64();
	void EndCall64();

	void PushUnicodeString(const wchar_t* DataValue);
	void PushInt(int DataValue);
	void PushParameter(PARAMETER_TYPE ParameterType, void* ParameterData);

	void PushAllParameters(HANDLE ProcessHandle, BOOL IsRightToLeft, BOOL Is64Bit);  //������Ĳ���

	void PushCall(HANDLE ProcessHandle, CALLING_CONVENTION CallingConvention, FARPROC CallingAddress, BOOL Is64Bit);

	void LoadStringParameter64(HANDLE ProcessHandle,
		PARAMETER_INFORMATION ParameterInfo, PARAMETER_INDEX ParameterIndex, BOOL Is64Bit);

	BOOL LoadParameter64(unsigned __int64 ParameterData, PARAMETER_INDEX ParameterIndex);

	void OnFreeMember(HANDLE ProcessHandle);
	inline size_t BoundaryAlign(size_t DataValue, size_t AlignmentValue)
	{
		//���DataValue	�Ƿ��Ѿ���AlignmentValue�ı����������Ѿ�����
		//������ǣ��Ͱ���AlignmentValue�����ڴ����ȶ���
		return (DataValue % AlignmentValue == 0) ? DataValue : (DataValue / AlignmentValue + 1) * AlignmentValue;
	}

};

