#pragma once
#include"Common.h"


typedef struct _UNICODE_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  Buffer;
} UNICODE_STRING;
typedef UNICODE_STRING* PUNICODE_STRING;

typedef struct _ANSI_STRING {
    USHORT Length;
    USHORT MaximumLength;
    PSTR   Buffer;
} ANSI_STRING;
typedef ANSI_STRING* PANSI_STRING;


typedef void (NTAPI* LPFN_RTLINITUNICODESTRING)(PUNICODE_STRING DestinationString, PCWSTR SourceString);
typedef void (NTAPI* LPFN_RTLINITUNICODESTRING)(PUNICODE_STRING DestinationString, PCWSTR SourceString);
typedef void (NTAPI* LPFN_RTLFREEUNICODESTRING)(PUNICODE_STRING UnicodeString);
typedef ULONG(NTAPI* LPFN_RTLNTSTATUSTODOSERROR)(NTSTATUS Status);
typedef NTSTATUS(NTAPI* LPFN_RTLDOSAPPLYFILEISOLATIONREDIRECTION_USTR)(
	IN ULONG Flags,
	IN PUNICODE_STRING OriginalName,
	IN PUNICODE_STRING Extension,
	IN OUT PUNICODE_STRING StaticString,
	IN OUT PUNICODE_STRING DynamicString,
	IN OUT PUNICODE_STRING* NewName,
	IN PULONG  NewFlags,
	IN PSIZE_T FileNameSize,
	IN PSIZE_T RequiredLength);



BOOL Char2Wchar(WCHAR** DestinationString, const char* SourceString, SIZE_T StringLength);		//����ת��Ϊ˫��
wstring StripPathW(const std::wstring& FilePath);


