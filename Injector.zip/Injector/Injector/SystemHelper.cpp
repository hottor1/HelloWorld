#include"SystemHelper.h"
#include"PEHelper.h"
#include"ModuleHelper.h"
BOOL IsWindowsVersionOrLater(OS_TYPE Version)
{
	if (Version == OS_TYPE_WINDOWS_10)		//�жϰ汾�Ƿ���win10
	{
		//��ntdll�в��Һ���RtlGetVersion
		LPFN_RTLGETVERSION RtlGetVersion =
			(LPFN_RTLGETVERSION)_PROCESS_::GetProcAddress((HMODULE)_MODULE_::GetModuleHandle(_T("ntdll.dll")), "RtlGetVersion");

		RTL_OSVERSIONINFOEXW VersionInfo = { 0 };
		VersionInfo.dwOSVersionInfoSize = sizeof(VersionInfo);		//��ʼ��

		if (RtlGetVersion != 0 && RtlGetVersion((PRTL_OSVERSIONINFOW)&VersionInfo) == 0)
		{
			return (VersionInfo.dwMajorVersion == 10);
		}
		return FALSE;
	}


	//����win10ϵͳ
	OSVERSIONINFOEX VersionInfo;		//�汾��Ϣ
	memset(&VersionInfo, 0, sizeof(OSVERSIONINFOEX));
	VersionInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if (Version >= OS_TYPE_WINDOWS_VISTA)		//�汾��>vista�汾
	{
		VersionInfo.dwMajorVersion = 6;			//�汾����6

		switch (Version)
		{
		case OS_TYPE_WINDOWS_VISTA:   VersionInfo.dwMinorVersion = 0; break;
		case OS_TYPE_WINDOWS_7:   VersionInfo.dwMinorVersion = 1; break;
		case OS_TYPE_WINDOWS_8:	  VersionInfo.dwMinorVersion = 2; break;
		default: break;
		}
	}
	else
	{
		VersionInfo.dwMajorVersion = 5;
		VersionInfo.dwMinorVersion = Version >= OS_TYPE_WINDOWS_XP ? 1 : 0;
	}

	DWORDLONG v1 = 0;

	VER_SET_CONDITION(v1, VER_MAJORVERSION, VER_GREATER_EQUAL);
	VER_SET_CONDITION(v1, VER_MINORVERSION, VER_GREATER_EQUAL);
	VER_SET_CONDITION(v1, VER_SERVICEPACKMAJOR, VER_GREATER_EQUAL);
	VER_SET_CONDITION(v1, VER_SERVICEPACKMINOR, VER_GREATER_EQUAL);

	return VerifyVersionInfo(&VersionInfo,
		VER_MAJORVERSION | VER_MINORVERSION | VER_SERVICEPACKMAJOR | VER_SERVICEPACKMINOR, v1) != FALSE;
}

LONG GetProcessorArchitecture()
{
	static LONG volatile ProcessorArchitecture = -1;
	if (ProcessorArchitecture == -1)
	{
		SYSTEM_PROCESSOR_INFORMATION SystemeProcessorInfo;
		NTSTATUS Status;

		LPFN_RTLGETNATIVESYSTEMINFORMATION RtlGetNativeSystemInformation =
			(LPFN_RTLGETNATIVESYSTEMINFORMATION)_PROCESS_::GetProcAddress((HMODULE)_MODULE_::GetModuleHandle(_T("ntdll.dll")), "RtlGetNativeSystemInformation");

		Status = RtlGetNativeSystemInformation((SYSTEM_INFORMATION_CLASS)SystemProcessorInformation,
			&SystemeProcessorInfo, sizeof(SystemeProcessorInfo), NULL);
		if (Status == STATUS_NOT_IMPLEMENTED)
		{
			LPFN_NTQUERYSYSTEMINFORMATION NtQuerySystemInformation =
				(LPFN_NTQUERYSYSTEMINFORMATION)_PROCESS_::GetProcAddress(_MODULE_::GetModuleHandle(_T("ntdll.dll")),
					"NtQuerySystemInformation");
			Status = NtQuerySystemInformation((SYSTEM_INFORMATION_CLASS)SystemProcessorInformation,
				&SystemeProcessorInfo, sizeof(SystemeProcessorInfo), NULL);
		}
		if (NT_SUCCESS(Status))
			_InterlockedExchange(&ProcessorArchitecture, (LONG)(SystemeProcessorInfo.ProcessorArchitecture));
	}
	return ProcessorArchitecture;
}
