#include"PEHelper.h"
#include"ModuleHelper.h"
#include <Dbghelp.h>
#pragma comment(lib,"Dbghelp.lib")
namespace _PE_
{
	

	IMAGE_DOS_HEADER* GetImageDosHeader(PVOID VirtualAddress)
	{
		PIMAGE_DOS_HEADER ImageDosHeader = (PIMAGE_DOS_HEADER)(VirtualAddress);
		if (!ImageDosHeader)		//DOSͷΪ�գ�������
		{
			return NULL;
		}
		if (ImageDosHeader->e_magic != IMAGE_DOS_SIGNATURE)
		{
			return NULL;
		}
		return ImageDosHeader;
	}
	IMAGE_NT_HEADERS* GetImageNtHeaders(PVOID VirtualAddress)
	{
		PIMAGE_DOS_HEADER ImageDosHeader = GetImageDosHeader(VirtualAddress);
		if ((ImageDosHeader == NULL) || (ImageDosHeader->e_magic != IMAGE_DOS_SIGNATURE))
		{
			return NULL;
		}
		PIMAGE_NT_HEADERS ImageNtHeaders = (PIMAGE_NT_HEADERS)((DWORD_PTR)ImageDosHeader + ImageDosHeader->e_lfanew);
		if (ImageNtHeaders == NULL)
		{
			return NULL;
		}
		if (ImageNtHeaders->Signature != IMAGE_NT_SIGNATURE)
		{
			return NULL;
		}
		return ImageNtHeaders;

	}

	void* RvaToPointer(ULONG Rva, PVOID VirtualAddress)
	{
		PIMAGE_NT_HEADERS ImageNtHeaders = GetImageNtHeaders(VirtualAddress);
		if (ImageNtHeaders == NULL)
		{
			return NULL;
		}
		return ::ImageRvaToVa(ImageNtHeaders, VirtualAddress, Rva, 0);
	}
};