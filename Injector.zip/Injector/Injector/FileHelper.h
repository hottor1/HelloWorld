#pragma once
#include"Common.h"


enum RESOLVE_FLAG
{
	RESOLVE_FLAG_DEFAULT = 0,
	RESOLVE_FLAG_API_SCHEMA_ONLY = 1,
	RESOLVE_FLAG_ENSURE_FULL_PATH = 2,
};


namespace _FILE_
{
	//�����ļ���Ϣ�ṹ
	typedef struct _FILE_INFORMATION_
	{
		PVOID	FileData;
		int     FileLength;
		BOOL IsValid() { return (FileData && FileLength); }
	}FILE_INFORMATION, * PFILE_INFORMATION;

	FILE_INFORMATION ReadFileA(LPCCH FilePath);
	BOOL ReleaseFile(FILE_INFORMATION FileInfo);

	BOOL FileExistsW(const wstring& FileFullPath);
};