#pragma once
#include"Common.h"
#include"Remoter.h"
#include"FileHelper.h"
class CInjector
{
public:

	CInjector();
	virtual ~CInjector();

	NTSTATUS Inject(_tstring ImageName, _tstring ModulePath);
private:
	CRemoter m_Remoter;
};

