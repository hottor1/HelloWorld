#pragma once
#include<Windows.h>
#include<tchar.h>
#include<iostream>
#include <ntstatus.h>
using namespace std;


#ifndef NT_SUCCESS
#define NT_SUCCESS(StatCode)  ((NTSTATUS)(StatCode) >= 0)
#endif



#ifdef _UNICODE
#define _tcout wcout
#define _tstring wstring
#define _tcin wcin
#else
#define _tcout cout
#define _tstring string
#define _tcin cin
#endif

extern "C" ULONG_PTR YtNtCurrentPeb();
extern "C" ULONG_PTR YtNtCurrentTeb();
