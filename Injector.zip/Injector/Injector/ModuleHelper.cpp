#include"ModuleHelper.h"
#include"StringHelper.h"
#include"PEHelper.h"
namespace _MODULE_
{
	HMODULE GetModuleHandleA(const char* ModuleName)
	{
		HMODULE ModuleBase = NULL;
		WCHAR* v5 = NULL;
		Char2Wchar(&v5, ModuleName, strlen(ModuleName));		//��˫��ת����

		if (v5 != NULL)
		{
			ModuleBase = GetModuleHandleW(v5);				//˫�ֲ���
			delete v5;
			v5 = NULL;
		}

		return ModuleBase;
	}
	HMODULE GetModuleHandleW(const WCHAR* ModuleName)
	{
		void* ModuleBase = 0;

		/*
		//��õ�ǰ�̻߳�����
		_TEB* Teb = (_TEB*)NtCurrentTeb();
		//ͨ���߳̿��ý��̻�����
		_PEB* Peb = (_PEB*)Teb->ProcessEnvironmentBlock;
		*/

		_PEB* Peb = (_PEB*)YtNtCurrentPeb();


		PPEB_LDR_DATA PebLdrData = Peb->Ldr;		//�õ�Ldr�ṹ��������������InLoadOrderModuleList��InMemoryOrderModuleList��InInitializationOrderModuleList
		PLDR_DATA_TABLE_ENTRY v1 = (PLDR_DATA_TABLE_ENTRY)PebLdrData->InLoadOrderModuleList.Flink;

		while (v1->DllBase)		//�õ�Dllģ��Ļ���ַ
		{
			if (_wcsicmp(ModuleName, v1->BaseDllName.Buffer) == 0)
			{
				//���ģ���ڽ����еĵ�ַ
				ModuleBase = v1->DllBase;
				break;
			}
			v1 = (PLDR_DATA_TABLE_ENTRY)v1->InLoadOrderModuleList.Flink;
		}
		return (HMODULE)ModuleBase;
	}


	HMODULE GetProcessModuleHandleW(HANDLE ProcessHandle, const WCHAR* ModuleName)
	{
		char v1[MAX_PATH] = { 0 };
		size_t ReturnLength = 0;
		//wcstombs_s(&ReturnLength, v1, ModuleName, MAX_PATH);
		ReturnLength = WideCharToMultiByte(CP_ACP, 0, ModuleName, -1, v1, MAX_PATH, NULL, NULL);
		return GetProcessModuleHandleA(ProcessHandle, v1);
	}
	HMODULE	GetProcessModuleHandleA(HANDLE ProcessHandle, const char* ModuleName)
	{
		if (ProcessHandle == INVALID_HANDLE_VALUE)
		{
			return NULL;
		}

		PPROCESS_BASIC_INFORMATION ProcessBasicInfo = NULL;
		PEB Peb = { 0 };
		PEB_LDR_DATA PebLdrData = { 0 };
		HMODULE ModuleBase = (HMODULE)GetModuleHandle(_T("ntdll.dll"));
		LPFN_NTQUERYINFORMATIONPROCESS NtQueryInformationProcess =
			(LPFN_NTQUERYINFORMATIONPROCESS)_PROCESS_::GetProcAddress(ModuleBase, "NtQueryInformationProcess");

		if (NtQueryInformationProcess == NULL)
		{
			return NULL;
		}
		//��õ�ǰ����Ĭ�϶�
		HANDLE HeapHandle = GetProcessHeap();
		DWORD v1 = sizeof(PROCESS_BASIC_INFORMATION);
		ProcessBasicInfo = (PPROCESS_BASIC_INFORMATION)HeapAlloc(HeapHandle, HEAP_ZERO_MEMORY, v1);		//�ڽ���Ĭ�϶��ж�̬�����ڴ�

		ULONG ReturnLength = 0;
		NTSTATUS Status = NtQueryInformationProcess(ProcessHandle, ProcessBasicInformation, ProcessBasicInfo, v1, &ReturnLength);
		if (Status >= 0 && v1 < ReturnLength)
		{
			if (ProcessBasicInfo)		//��ѯ��ϢΪ��
			{
				HeapFree(HeapHandle,0,ProcessBasicInfo);
			}
			//��̬�����ڴ�
			ProcessBasicInfo = (PPROCESS_BASIC_INFORMATION)HeapAlloc(HeapHandle, HEAP_ZERO_MEMORY, ReturnLength);
			if (!ProcessBasicInfo)
			{
				return NULL;
			}

			Status = NtQueryInformationProcess(ProcessHandle, ProcessBasicInformation, ProcessBasicInfo, ReturnLength, &ReturnLength);
		}
		//ö�ٳɹ�
		if (Status >= 0)
		{
			//��ȡĿ�����Peb��ַ,
			if (ProcessBasicInfo->PebBaseAddress)
			{
				SIZE_T ReturnLength = 0;
				//��ȡ�Է�����PEB
				if (ReadProcessMemory(ProcessHandle, ProcessBasicInfo->PebBaseAddress, &Peb, sizeof(PEB), &ReturnLength))
				{
					ReturnLength = 0;
					//��ȡ�Է������е�PEB�ṹ�е�Ldr�����ṹ
					if (ReadProcessMemory(ProcessHandle, Peb.Ldr, &PebLdrData, sizeof(PEB_LDR_DATA), &ReturnLength))
					{
						LIST_ENTRY* ListEntry = (LIST_ENTRY*)PebLdrData.InLoadOrderModuleList.Flink;
						LIST_ENTRY* v1 = PebLdrData.InLoadOrderModuleList.Flink;
						do
						{
							LDR_DATA_TABLE_ENTRY v2 = { 0 };
							ReturnLength = 0;
							if (!ReadProcessMemory(ProcessHandle, (void*)v1, &v2, sizeof(LDR_DATA_TABLE_ENTRY), &ReturnLength))
							{
								if (ProcessBasicInfo)
								{
									HeapFree(HeapHandle, 0, ProcessBasicInfo);
								}
								return NULL;
							}

							v1 = v2.InLoadOrderModuleList.Flink;

							wchar_t v3[MAX_PATH] = { 0 };
							char v4[MAX_PATH] = { 0 };
							if (v2.BaseDllName.Length > 0)
							{
								ReturnLength = 0;
								if (ReadProcessMemory(ProcessHandle, (LPCVOID)v2.BaseDllName.Buffer,
									&v3, v2.BaseDllName.Length, &ReturnLength))
								{
									size_t ReturnLength = 0;
									//wcstombs_s(&ReturnLength, v4, v3, MAX_PATH);
									ReturnLength = WideCharToMultiByte(CP_ACP, 0, v3, -1, v4, MAX_PATH, NULL, NULL);
								}
							}

							if (v2.DllBase != nullptr && v2.SizeOfImage != 0)
							{
								if (_stricmp(v4, ModuleName) == 0)
								{
									ModuleBase = (HMODULE)v2.DllBase;
									break;
								}
							}

						} while (ListEntry != v1);

					}
				}
			}
		}

		if (ProcessBasicInfo)
		{
			HeapFree(HeapHandle, 0, ProcessBasicInfo);
		}

		return (HMODULE)ModuleBase;

		
	}

};