#pragma once
#include <fltKernel.h>

#define DEVICE_OBJECT_NAME  L"\\Device\\911Kernel"
#define SYMBOLIC_LINK    L"\\??\\911Kernel"      //Ring3ͨ�Žӿ�
