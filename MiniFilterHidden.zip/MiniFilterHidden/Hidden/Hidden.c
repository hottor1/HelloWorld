#include "Hidden.h"

volatile LONG __DriverActive = FALSE;
PEXCLUDE_CONTEXT __ExcludeFileContext;
PEXCLUDE_CONTEXT __ExcludeDirectoryContext;

CONST PWCHAR __ExcludeFiles[] = 
{
	L"\\Device\\HarddiskVolume1\\Shine.txt",
	L"\\??\\D:\\Shine.txt",    //这样写路径 是不行的
	NULL
};
CONST PWCHAR __ExcludeDirectorys[] = {
	 L"\\Device\\HarddiskVolume1\\IDA6.8",
	 NULL
};


PFLT_FILTER __FilterHandle = NULL;


CONST FLT_OPERATION_REGISTRATION __Callbacks[] = {


	{ IRP_MJ_CREATE, 0, CreatePreviousOperation,  NULL },
	{ IRP_MJ_DIRECTORY_CONTROL, 0, DirectoryCtrlPreviousOperation, DirectoryCtrlPostOperation },
	{ IRP_MJ_OPERATION_END }
};
const FLT_CONTEXT_REGISTRATION __Context[] = {
	{ FLT_CONTEXT_END }
};
CONST FLT_REGISTRATION __FilterRegistration = {

	sizeof(FLT_REGISTRATION),         //  Size
	FLT_REGISTRATION_VERSION,           //  Version
	FLTFL_REGISTRATION_DO_NOT_SUPPORT_SERVICE_STOP,                                  //  Flags

	__Context,                               //  Context
	__Callbacks,                          //  Operation callbacks

	NULL,                           //  MiniFilterUnload

	HiddenInstanceSetup,                    //  InstanceSetup
	NULL,          
	NULL,         
	NULL,         

	NULL,
	NULL,                   
	NULL

};
BOOLEAN __FsMonitorInitialized = FALSE;
NTSTATUS
DriverEntry (
    _In_ PDRIVER_OBJECT DriverObject,
    _In_ PUNICODE_STRING RegistryPath
    )

{
    NTSTATUS Status = STATUS_UNSUCCESSFUL;

    UNREFERENCED_PARAMETER( RegistryPath );


	DbgPrint("DriverEntry()\r\n");


	SeEnableDisableDriver(TRUE);


	Status = SeInitializeMiniFilter(DriverObject);
	if (!NT_SUCCESS(Status))
	{
		DbgPrint("SeInitializeMiniFilter() Error\r\n");
	}


	DriverObject->DriverUnload = DriverUnload;
    return Status;
}

VOID DriverUnload(PDRIVER_OBJECT DriverObject)
{
	UNREFERENCED_PARAMETER(DriverObject);

	
	SeDestroyMiniFilter();

}
VOID SeEnableDisableDriver(BOOLEAN IsEnabled)
{
	InterlockedExchange(&__DriverActive, (LONG)IsEnabled);
}
BOOLEAN SeIsDriverEnabled()
{
	return (__DriverActive ? TRUE : FALSE);
}
NTSTATUS SeInitializeMiniFilter(PDRIVER_OBJECT DriverObject)
{
	NTSTATUS Status;
	UNICODE_STRING v1;
	UINT32 i;



	Status = SeInitializeExcludeListContext(&__ExcludeFileContext);
	if (!NT_SUCCESS(Status))
	{
	
		DbgPrint("SeInitializeExcludeListContext() Error\r\n");
		return Status;
	}

	for (i = 0; __ExcludeFiles[i]; i++)
	{
		RtlInitUnicodeString(&v1, __ExcludeFiles[i]);
		SeAddExcludeFileList(__ExcludeFileContext, &v1);
	}


	Status = SeInitializeExcludeListContext(&__ExcludeDirectoryContext);
	if (!NT_SUCCESS(Status))
	{
		DbgPrint("SeInitializeExcludeListContext() Error\r\n");
		SeDestroyExcludeListContext(__ExcludeFileContext);
		return Status;
	}

	for (i = 0; __ExcludeDirectorys[i]; i++)
	{
		RtlInitUnicodeString(&v1, __ExcludeDirectorys[i]);
		SeAddExcludeDirectoryList(__ExcludeDirectoryContext, &v1);
	}

	//
	Status = FltRegisterFilter(DriverObject, &__FilterRegistration, &__FilterHandle);
	if (NT_SUCCESS(Status))
	{
		Status = FltStartFiltering(__FilterHandle);
		if (!NT_SUCCESS(Status))
		{
			DbgPrint("FltStartFiltering() Error\r\n");
			FltUnregisterFilter(__FilterHandle);
		}
	}
	else
	{
		DbgPrint("FltRegisterFilter() Error\r\n");
	}

	if (!NT_SUCCESS(Status))
	{
		SeDestroyExcludeListContext(__ExcludeFileContext);
		SeDestroyExcludeListContext(__ExcludeDirectoryContext);
		return Status;
	}

	__FsMonitorInitialized = TRUE;


	return Status;
}

NTSTATUS SeInitializeExcludeListContext(PPEXCLUDE_CONTEXT ExcludeContext)
{
	PEXCLUDE_FILE_CONTEXT v1;

	v1 = (PEXCLUDE_FILE_CONTEXT)ExAllocatePool(NonPagedPool,
		sizeof(EXCLUDE_FILE_CONTEXT));
	if (!v1)
	{
		return STATUS_ACCESS_DENIED;
	}

	InitializeListHead(&v1->ListEntry);
	ExInitializeFastMutex(&v1->FastMutex);

	*ExcludeContext = v1;
	return STATUS_SUCCESS;
}

NTSTATUS SeAddExcludeFileList(PEXCLUDE_CONTEXT ExcludeContext, PUNICODE_STRING FilePath)
{
	return SeAddExcludeListEntry(ExcludeContext, FilePath);
}
NTSTATUS SeAddExcludeDirectoryList(PEXCLUDE_CONTEXT ExcludeContext, PUNICODE_STRING DirectoryPath)
{
	return SeAddExcludeListEntry(ExcludeContext, DirectoryPath);
}

NTSTATUS SeAddExcludeListEntry(PEXCLUDE_CONTEXT ExcludeContext, PUNICODE_STRING FilePath)
{
	
	PEXCLUDE_FILE_CONTEXT v5 = (PEXCLUDE_FILE_CONTEXT)ExcludeContext;
	PEXCLUDE_FILE_LIST_ENTRY v1, Head;
	UNICODE_STRING v2;
	SIZE_T Size;


	if (FilePath->Length == 0 || FilePath->Length >= 1024)
	{

		return STATUS_ACCESS_DENIED;
	}


	Size = sizeof(EXCLUDE_FILE_LIST_ENTRY) + FilePath->Length + sizeof(WCHAR);
	v1 = ExAllocatePool(NonPagedPool, Size);
	if (v1 == NULL)
	{

		return STATUS_ACCESS_DENIED;
	}

	RtlZeroMemory(v1, Size);

	v2.Buffer = (PWCH)((PCHAR)v1 + sizeof(EXCLUDE_FILE_LIST_ENTRY));
	v2.Length = 0;
	v2.MaximumLength = FilePath->Length;

	RtlCopyUnicodeString(&v2, FilePath);

	if (!SeFillDirectoryFromPath(&v1->ExculdeFilePath, &v2))
	{
		ExFreePool(v1);
	
		return STATUS_ACCESS_DENIED;
	}

	Head = (PEXCLUDE_FILE_LIST_ENTRY)&v5->ListEntry;


	ExAcquireFastMutex(&v5->FastMutex);

	InsertTailList((PLIST_ENTRY)Head, (PLIST_ENTRY)v1);

	ExReleaseFastMutex(&v5->FastMutex);

	return STATUS_SUCCESS;
}
VOID SeDestroyExcludeListContext(PEXCLUDE_CONTEXT ExcludeContext)
{
	PEXCLUDE_FILE_CONTEXT v1 = (PEXCLUDE_FILE_CONTEXT)ExcludeContext;
	SeRemoveAllExcludeListEntry(ExcludeContext);
	ExFreePool(v1);
}
NTSTATUS SeRemoveAllExcludeListEntry(PEXCLUDE_CONTEXT ExcludeContext)
{
	PEXCLUDE_FILE_CONTEXT v5 = (PEXCLUDE_FILE_CONTEXT)ExcludeContext;
	PEXCLUDE_FILE_LIST_ENTRY Head;

	ExAcquireFastMutex(&v5->FastMutex);

	Head = (PEXCLUDE_FILE_LIST_ENTRY)v5->ListEntry.Flink;
	while (Head != (PEXCLUDE_FILE_LIST_ENTRY)&v5->ListEntry)
	{
		PEXCLUDE_FILE_LIST_ENTRY v1 = Head;
		Head = (PEXCLUDE_FILE_LIST_ENTRY)Head->ListEntry.Flink;
	
		RemoveEntryList((PLIST_ENTRY)v1);
		ExFreePool(v1);
	}

	ExReleaseFastMutex(&v5->FastMutex);

	return STATUS_SUCCESS;
}
BOOLEAN SeFillDirectoryFromPath(PEXCULDE_FILE_PATH ExculdeFilePath, PUNICODE_STRING FilePath)
{
	USHORT i, v7;
	LPWSTR v5 = FilePath->Buffer;

	v7 = FilePath->Length / sizeof(WCHAR);
	if (v7 < 1)
		return FALSE;

	i = v7;
	do
	{
		i--;

		if (v5[i] == L'\\')
		{
			if (i + 1 >= v7)
				return FALSE;

			ExculdeFilePath->FileName.Buffer = v5 + i + 1;
			ExculdeFilePath->FileName.Length = (v7 - i - 1) * sizeof(WCHAR);
			ExculdeFilePath->FileName.MaximumLength = ExculdeFilePath->FileName.Length;

			ExculdeFilePath->FullPath = *FilePath;

			ExculdeFilePath->DirectoryName.Buffer = FilePath->Buffer;
			ExculdeFilePath->DirectoryName.Length = i * sizeof(WCHAR);
			ExculdeFilePath->DirectoryName.MaximumLength = ExculdeFilePath->DirectoryName.Length;

			return TRUE;
		}
	} while (i > 0);

	return FALSE;
}

BOOLEAN SeIsProcessExcluded(HANDLE ProcessIdentify)
{
	return TRUE;
}

NTSTATUS SeDestroyMiniFilter()
{
	if (!__FsMonitorInitialized)
		return STATUS_NOT_FOUND;

	FltUnregisterFilter(__FilterHandle);
	__FilterHandle = NULL;

	SeDestroyExcludeListContext(__ExcludeFileContext);
	SeDestroyExcludeListContext(__ExcludeDirectoryContext);
	__FsMonitorInitialized = FALSE;

	
	return STATUS_SUCCESS;
}
NTSTATUS
HiddenInstanceSetup(
	_In_ PCFLT_RELATED_OBJECTS FltObjects,
	_In_ FLT_INSTANCE_SETUP_FLAGS Flags,
	_In_ DEVICE_TYPE VolumeDeviceType,
	_In_ FLT_FILESYSTEM_TYPE VolumeFilesystemType
)

{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(Flags);
	UNREFERENCED_PARAMETER(VolumeDeviceType);
	UNREFERENCED_PARAMETER(VolumeFilesystemType);

	PAGED_CODE();



	return STATUS_SUCCESS;
}
NTSTATUS
HiddenUnload (
    _In_ FLT_FILTER_UNLOAD_FLAGS Flags
    )

{
    UNREFERENCED_PARAMETER( Flags );

    PAGED_CODE();



    return STATUS_SUCCESS;
}

FLT_PREOP_CALLBACK_STATUS CreatePreviousOperation(PFLT_CALLBACK_DATA Data,
	PCFLT_RELATED_OBJECTS FltObjects, PVOID *CompletionContext)
{
	UINT32 Disposition, Options;
	PFLT_FILE_NAME_INFORMATION FltFileNameInfo = NULL;
	NTSTATUS Status;
	BOOLEAN NeededPrevent = FALSE;

	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(CompletionContext);

	if (!SeIsDriverEnabled())
		return FLT_PREOP_SUCCESS_NO_CALLBACK;

	DbgPrint("%wZ (options:%x)", &Data->Iopb->TargetFileObject->FileName,
		Data->Iopb->Parameters.Create.Options);

	if (!SeIsProcessExcluded(PsGetCurrentProcessId()))
	{
		return FLT_PREOP_SUCCESS_NO_CALLBACK;
	}
	

	Options = Data->Iopb->Parameters.Create.Options & 0x00FFFFFF;
	Disposition = (Data->Iopb->Parameters.Create.Options & 0xFF000000) >> 24;

	Status = FltGetFileNameInformation(Data, FLT_FILE_NAME_NORMALIZED, &FltFileNameInfo); 
	if (!NT_SUCCESS(Status))
	{
		if (Status != STATUS_OBJECT_PATH_NOT_FOUND)
		{

		}
		return FLT_PREOP_SUCCESS_NO_CALLBACK;
	}

	if (!(Options & FILE_DIRECTORY_FILE))
	{
		// If it is create file event
		if (SeCheckExcludeFileList(__ExcludeFileContext, &FltFileNameInfo->Name))
			NeededPrevent = TRUE;
	}

	// If it is create directory/file event
	if (!NeededPrevent && SeCheckExcludeFileList(__ExcludeDirectoryContext, &FltFileNameInfo->Name))
		NeededPrevent = TRUE;

	FltReleaseFileNameInformation(FltFileNameInfo);  

	if (NeededPrevent)
	{
		
		Data->IoStatus.Status = STATUS_NO_SUCH_FILE;
		return FLT_PREOP_COMPLETE;
	}

	return FLT_PREOP_SUCCESS_NO_CALLBACK;
}
BOOLEAN SeCheckExcludeFileList(PEXCLUDE_CONTEXT ExcludeContext, PCUNICODE_STRING FilePath)
{
	PEXCLUDE_FILE_CONTEXT v5 = (PEXCLUDE_FILE_CONTEXT)ExcludeContext;
	PEXCLUDE_FILE_LIST_ENTRY Head;
	UNICODE_STRING v1, v2;
	BOOLEAN IsOk = FALSE;

	v1 = *FilePath;
	if (v1.Length > 0 && v1.Buffer[v1.Length / sizeof(WCHAR) - 1] == L'\\')
		v1.Length -= sizeof(WCHAR);

	ExAcquireFastMutex(&v5->FastMutex);

	Head = (PEXCLUDE_FILE_LIST_ENTRY)v5->ListEntry.Flink;
	while (Head != (PEXCLUDE_FILE_LIST_ENTRY)&v5->ListEntry)
	{
		v2 = v1;

		if (v2.Length >= Head->ExculdeFilePath.FullPath.Length)
		{
			BOOLEAN IsCompare = TRUE;

			if (v2.Length > Head->ExculdeFilePath.FullPath.Length)
			{
				if (v2.Buffer[Head->ExculdeFilePath.FullPath.Length / sizeof(WCHAR)] != L'\\')
					IsCompare = FALSE;
				else
					v2.Length = Head->ExculdeFilePath.FullPath.Length;
			}

			if (IsCompare && RtlCompareUnicodeString(&Head->ExculdeFilePath.FullPath, &v2, TRUE) == 0)
			{
				IsOk = TRUE;
				break;
			}
		}

		Head = (PEXCLUDE_FILE_LIST_ENTRY)Head->ListEntry.Flink;
	}

	ExReleaseFastMutex(&v5->FastMutex);

	return IsOk;
}





FLT_PREOP_CALLBACK_STATUS DirectoryCtrlPreviousOperation(PFLT_CALLBACK_DATA Data,
	PCFLT_RELATED_OBJECTS FltObjects, PVOID *CompletionContext)
{
	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(CompletionContext);

	if (!SeIsDriverEnabled())
		return FLT_POSTOP_FINISHED_PROCESSING;

	
	if (Data->Iopb->MinorFunction != IRP_MN_QUERY_DIRECTORY)
		return FLT_PREOP_SUCCESS_NO_CALLBACK;  //请求下发 不调用Post过滤函数


	switch (Data->Iopb->Parameters.DirectoryControl.QueryDirectory.FileInformationClass)
	{
	case FileIdFullDirectoryInformation:
	case FileIdBothDirectoryInformation:
	case FileBothDirectoryInformation:
	case FileDirectoryInformation:
	case FileFullDirectoryInformation:
	case FileNamesInformation:
		break;
	default:
		return FLT_PREOP_SUCCESS_NO_CALLBACK;
	}


	return FLT_PREOP_SUCCESS_WITH_CALLBACK;   //请求下发 调用Post过滤函数
}
FLT_POSTOP_CALLBACK_STATUS DirectoryCtrlPostOperation(PFLT_CALLBACK_DATA Data, PCFLT_RELATED_OBJECTS FltObjects, PVOID CompletionContext, FLT_POST_OPERATION_FLAGS Flags)
{
	PFLT_PARAMETERS FltParameters = &Data->Iopb->Parameters;
	PFLT_FILE_NAME_INFORMATION FltFileNameInfo;
	NTSTATUS Status;

	UNREFERENCED_PARAMETER(FltObjects);
	UNREFERENCED_PARAMETER(CompletionContext);
	UNREFERENCED_PARAMETER(Flags);

	if (!SeIsDriverEnabled())
		return FLT_POSTOP_FINISHED_PROCESSING;

	if (!NT_SUCCESS(Data->IoStatus.Status))
		return FLT_POSTOP_FINISHED_PROCESSING;



	if (!SeIsProcessExcluded(PsGetCurrentProcessId()))
	{
		
		return FLT_POSTOP_FINISHED_PROCESSING;
	}

	Status = FltGetFileNameInformation(Data, FLT_FILE_NAME_NORMALIZED, &FltFileNameInfo);
	if (!NT_SUCCESS(Status))
	{
		DbgPrint("FltGetFileNameInformation() Failed with Code:%08x", Status);
		return FLT_POSTOP_FINISHED_PROCESSING;
	}

	__try
	{
		//
		Status = STATUS_SUCCESS;

		switch (FltParameters->DirectoryControl.QueryDirectory.FileInformationClass)
		{
		case FileFullDirectoryInformation:
		{
			Status = SeCleanFileFullDirectoryInformation((PFILE_FULL_DIR_INFORMATION)FltParameters->DirectoryControl.QueryDirectory.DirectoryBuffer,
				FltFileNameInfo);
			break;

		}
			
		case FileBothDirectoryInformation:
		{
			Status = SeCleanFileBothDirectoryInformation((PFILE_BOTH_DIR_INFORMATION)FltParameters->DirectoryControl.QueryDirectory.DirectoryBuffer,
				FltFileNameInfo);
			break;
		}
			
		case FileDirectoryInformation:
		{
			Status = SeCleanFileDirectoryInformation((PFILE_DIRECTORY_INFORMATION)FltParameters->DirectoryControl.QueryDirectory.DirectoryBuffer,
				FltFileNameInfo);
			break;
		}
			
		case FileIdFullDirectoryInformation:
		{
			Status = SeCleanFileIdFullDirectoryInformation((PFILE_ID_FULL_DIR_INFORMATION)FltParameters->DirectoryControl.QueryDirectory.DirectoryBuffer,
				FltFileNameInfo);
			break;
		}
		case FileIdBothDirectoryInformation:
		{

			Status = SeCleanFileIdBothDirectoryInformation((PFILE_ID_BOTH_DIR_INFORMATION)FltParameters->DirectoryControl.QueryDirectory.DirectoryBuffer, FltFileNameInfo);
			break;
		}
			
		case FileNamesInformation:
		{
			Status = SeCleanFileNamesInformation((PFILE_NAMES_INFORMATION)FltParameters->DirectoryControl.QueryDirectory.DirectoryBuffer, FltFileNameInfo);
			break;
		}
			
		}

		Data->IoStatus.Status = Status;
	}
	__finally
	{
		FltReleaseFileNameInformation(FltFileNameInfo);
	}

	return FLT_POSTOP_FINISHED_PROCESSING;
}

NTSTATUS SeCleanFileFullDirectoryInformation(PFILE_FULL_DIR_INFORMATION FileFullDirInfo, 
	PFLT_FILE_NAME_INFORMATION FltFileNameInfo)
{
	PFILE_FULL_DIR_INFORMATION Next, Previous = NULL;
	UNICODE_STRING v1;
	UINT32 NextEntryOffset, MoveLength;
	BOOLEAN IsMatched, IsLoop;
	NTSTATUS Status = STATUS_SUCCESS;

	NextEntryOffset = 0;
	IsLoop = TRUE;

	do
	{
		v1.Buffer = FileFullDirInfo->FileName;
		v1.Length = (USHORT)FileFullDirInfo->FileNameLength;
		v1.MaximumLength = (USHORT)FileFullDirInfo->FileNameLength;

		if (FileFullDirInfo->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeDirectoryContext, &FltFileNameInfo->Name, &v1);
		else
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeFileContext, &FltFileNameInfo->Name, &v1);

		if (IsMatched)
		{
			BOOLEAN IsOk = FALSE;

			if (Previous != NULL)
			{
				if (FileFullDirInfo->NextEntryOffset != 0)
				{
					Previous->NextEntryOffset += FileFullDirInfo->NextEntryOffset;
					NextEntryOffset = FileFullDirInfo->NextEntryOffset;
				}
				else
				{
					Previous->NextEntryOffset = 0;
					Status = STATUS_SUCCESS;
					IsOk = TRUE;
				}

				RtlFillMemory(FileFullDirInfo, sizeof(FILE_FULL_DIR_INFORMATION), 0);
			}
			else
			{
				if (FileFullDirInfo->NextEntryOffset != 0)
				{
					Next = (PFILE_FULL_DIR_INFORMATION)((PUCHAR)FileFullDirInfo + FileFullDirInfo->NextEntryOffset);
					MoveLength = 0;
					while (Next->NextEntryOffset != 0)
					{
						MoveLength += Next->NextEntryOffset;
						Next = (PFILE_FULL_DIR_INFORMATION)((PUCHAR)Next + Next->NextEntryOffset);
					}
					MoveLength += FIELD_OFFSET(FILE_FULL_DIR_INFORMATION, FileName) + Next->FileNameLength;
					RtlMoveMemory(FileFullDirInfo, (PUCHAR)FileFullDirInfo + FileFullDirInfo->NextEntryOffset, MoveLength);//continue
				}
				else
				{
					Status = STATUS_NO_MORE_ENTRIES;
					IsOk = TRUE;
				}
			}



			if (IsOk)
				return Status;

			FileFullDirInfo = (PFILE_FULL_DIR_INFORMATION)((PCHAR)FileFullDirInfo + NextEntryOffset);
			continue;
		}

		NextEntryOffset = FileFullDirInfo->NextEntryOffset;
		Previous = FileFullDirInfo;
		FileFullDirInfo = (PFILE_FULL_DIR_INFORMATION)((PCHAR)FileFullDirInfo + NextEntryOffset);

		if (NextEntryOffset == 0)
		{
			IsLoop = FALSE;
		}
			
	} while (IsLoop);

	return STATUS_SUCCESS;
}

NTSTATUS SeCleanFileBothDirectoryInformation(PFILE_BOTH_DIR_INFORMATION FileBothInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo)
{
	PFILE_BOTH_DIR_INFORMATION Next, Previous = NULL;
	UNICODE_STRING v1;
	UINT32 NextEntryOffset, MoveLength;
	BOOLEAN IsMatched, IsLoop;
	NTSTATUS Status = STATUS_SUCCESS;

	NextEntryOffset = 0;
	IsLoop = TRUE;

	do
	{
		v1.Buffer = FileBothInfo->FileName;
		v1.Length = (USHORT)FileBothInfo->FileNameLength;
		v1.MaximumLength = (USHORT)FileBothInfo->FileNameLength;

		if (FileBothInfo->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeDirectoryContext, &FltFileNameInfo->Name, &v1);
		else
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeFileContext, &FltFileNameInfo->Name, &v1);

		if (IsMatched)
		{
			BOOLEAN IsOk = FALSE;

			if (Previous != NULL)
			{
				if (FileBothInfo->NextEntryOffset != 0)
				{
					Previous->NextEntryOffset += FileBothInfo->NextEntryOffset;
					NextEntryOffset = FileBothInfo->NextEntryOffset;
				}
				else
				{
					Previous->NextEntryOffset = 0;
					Status = STATUS_SUCCESS;
					IsOk = TRUE;
				}

				RtlFillMemory(FileBothInfo, sizeof(FILE_BOTH_DIR_INFORMATION), 0);
			}
			else
			{
				if (FileBothInfo->NextEntryOffset != 0)
				{
					Next = (PFILE_BOTH_DIR_INFORMATION)((PUCHAR)FileBothInfo + FileBothInfo->NextEntryOffset);
					MoveLength = 0;
					while (Next->NextEntryOffset != 0)
					{
						MoveLength += Next->NextEntryOffset;
						Next = (PFILE_BOTH_DIR_INFORMATION)((PUCHAR)Next + Next->NextEntryOffset);
					}

					MoveLength += FIELD_OFFSET(FILE_BOTH_DIR_INFORMATION, FileName) + Next->FileNameLength;
					RtlMoveMemory(FileBothInfo, (PUCHAR)FileBothInfo + FileBothInfo->NextEntryOffset, MoveLength);//continue
				}
				else
				{
					Status = STATUS_NO_MORE_ENTRIES;
					IsOk = TRUE;
				}
			}

			if (IsOk)
				return Status;

			FileBothInfo = (PFILE_BOTH_DIR_INFORMATION)((PCHAR)FileBothInfo + NextEntryOffset);
			continue;
		}

		NextEntryOffset = FileBothInfo->NextEntryOffset;
		Previous = FileBothInfo;
		FileBothInfo = (PFILE_BOTH_DIR_INFORMATION)((PCHAR)FileBothInfo + NextEntryOffset);

		if (NextEntryOffset == 0)
			IsLoop = FALSE;
	} while (IsLoop);

	return STATUS_SUCCESS;
}

NTSTATUS SeCleanFileDirectoryInformation(PFILE_DIRECTORY_INFORMATION FileDirectoryInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo)
{
	PFILE_DIRECTORY_INFORMATION Next, Previous = NULL;
	UNICODE_STRING v1;
	UINT32 NextEntryOffset, MoveLength;
	BOOLEAN IsMatched, IsLoop;
	NTSTATUS Status = STATUS_SUCCESS;

	NextEntryOffset = 0;
	IsLoop = TRUE;

	do
	{
		v1.Buffer = FileDirectoryInfo->FileName;
		v1.Length = (USHORT)FileDirectoryInfo->FileNameLength;
		v1.MaximumLength = (USHORT)FileDirectoryInfo->FileNameLength;

		if (FileDirectoryInfo->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeDirectoryContext, &FltFileNameInfo->Name, &v1);
		else
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeFileContext, &FltFileNameInfo->Name, &v1);

		if (IsMatched)
		{
			BOOLEAN IsOk = FALSE;

			if (Previous != NULL)
			{
				if (FileDirectoryInfo->NextEntryOffset != 0)
				{
					FileDirectoryInfo->NextEntryOffset += FileDirectoryInfo->NextEntryOffset;
					NextEntryOffset = FileDirectoryInfo->NextEntryOffset;
				}
				else
				{
					Previous->NextEntryOffset = 0;
					Status = STATUS_SUCCESS;
					IsOk = TRUE;
				}

				RtlFillMemory(FileDirectoryInfo, sizeof(FILE_DIRECTORY_INFORMATION), 0);
			}
			else
			{
				if (FileDirectoryInfo->NextEntryOffset != 0)
				{
					Next = (PFILE_DIRECTORY_INFORMATION)((PUCHAR)FileDirectoryInfo + FileDirectoryInfo->NextEntryOffset);
					MoveLength = 0;
					while (Next->NextEntryOffset != 0)
					{
						MoveLength += Next->NextEntryOffset;
						Next = (PFILE_DIRECTORY_INFORMATION)((PUCHAR)Next + Next->NextEntryOffset);
					}

					MoveLength += FIELD_OFFSET(FILE_DIRECTORY_INFORMATION, FileName) + Next->FileNameLength;
					RtlMoveMemory(FileDirectoryInfo, (PUCHAR)FileDirectoryInfo + FileDirectoryInfo->NextEntryOffset, MoveLength);//continue
				}
				else
				{
					Status = STATUS_NO_MORE_ENTRIES;
					IsOk = TRUE;
				}
			}

			if (IsOk)
				return Status;

			FileDirectoryInfo = (PFILE_DIRECTORY_INFORMATION)((PCHAR)FileDirectoryInfo + NextEntryOffset);
			continue;
		}

		NextEntryOffset = FileDirectoryInfo->NextEntryOffset;
		Previous = FileDirectoryInfo;
		FileDirectoryInfo = (PFILE_DIRECTORY_INFORMATION)((PCHAR)FileDirectoryInfo + NextEntryOffset);

		if (NextEntryOffset == 0)
			IsLoop = FALSE;
	} while (IsLoop);

	return STATUS_SUCCESS;
}

NTSTATUS SeCleanFileIdFullDirectoryInformation(PFILE_ID_FULL_DIR_INFORMATION FileIdFullDirInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo)
{

	PFILE_ID_FULL_DIR_INFORMATION Next, Previous = NULL;
	UNICODE_STRING v1;
	UINT32 NextEntryOffset, MoveLength;
	BOOLEAN IsMatched, IsLoop;
	NTSTATUS Status = STATUS_SUCCESS;

	NextEntryOffset = 0;
	IsLoop = TRUE;



	do
	{
		v1.Buffer = FileIdFullDirInfo->FileName;
		v1.Length = (USHORT)FileIdFullDirInfo->FileNameLength;
		v1.MaximumLength = (USHORT)FileIdFullDirInfo->FileNameLength;

		if (FileIdFullDirInfo->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeDirectoryContext, &FltFileNameInfo->Name, &v1);
		else
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeFileContext, &FltFileNameInfo->Name, &v1);

		if (IsMatched)
		{
			BOOLEAN IsOk = FALSE;

			if (Previous != NULL)
			{
				if (FileIdFullDirInfo->NextEntryOffset != 0)
				{
					Previous->NextEntryOffset += FileIdFullDirInfo->NextEntryOffset;
					NextEntryOffset = FileIdFullDirInfo->NextEntryOffset;
				}
				else
				{
					Previous->NextEntryOffset = 0;
					Status = STATUS_SUCCESS;
					IsOk = TRUE;
				}

				RtlFillMemory(FileIdFullDirInfo, sizeof(FILE_ID_FULL_DIR_INFORMATION), 0);
			}
			else
			{
				if (FileIdFullDirInfo->NextEntryOffset != 0)
				{
					Next = (PFILE_ID_FULL_DIR_INFORMATION)((PUCHAR)FileIdFullDirInfo + FileIdFullDirInfo->NextEntryOffset);
					MoveLength = 0;
					while (Next->NextEntryOffset != 0)
					{
						MoveLength += Next->NextEntryOffset;
						Next = (PFILE_ID_FULL_DIR_INFORMATION)((PUCHAR)Next + Next->NextEntryOffset);
					}

					MoveLength += FIELD_OFFSET(FILE_ID_FULL_DIR_INFORMATION, FileName) + Next->FileNameLength;
					RtlMoveMemory(FileIdFullDirInfo, (PUCHAR)FileIdFullDirInfo + FileIdFullDirInfo->NextEntryOffset, MoveLength);//continue
				}
				else
				{
					Status = STATUS_NO_MORE_ENTRIES;
					IsOk = TRUE;
				}
			}

		
			if (IsOk)
				return Status;

			FileIdFullDirInfo = (PFILE_ID_FULL_DIR_INFORMATION)((PCHAR)FileIdFullDirInfo + NextEntryOffset);
			continue;
		}

		NextEntryOffset = FileIdFullDirInfo->NextEntryOffset;
		Previous = FileIdFullDirInfo;
		FileIdFullDirInfo = (PFILE_ID_FULL_DIR_INFORMATION)((PCHAR)FileIdFullDirInfo + NextEntryOffset);

		if (NextEntryOffset == 0)
			IsLoop = FALSE;
	} while (IsLoop);

	return STATUS_SUCCESS;
}

NTSTATUS SeCleanFileIdBothDirectoryInformation(PFILE_ID_BOTH_DIR_INFORMATION FileIdBothDirInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo)
{
	PFILE_ID_BOTH_DIR_INFORMATION Next, Previous = NULL;
	UNICODE_STRING v1;
	UINT32 NextEntryOffset, MoveLength;
	BOOLEAN IsMatched, IsLoop;
	NTSTATUS Status = STATUS_SUCCESS;

	NextEntryOffset = 0;
	IsLoop = TRUE;

	do
	{
		v1.Buffer = FileIdBothDirInfo->FileName;
		v1.Length = (USHORT)FileIdBothDirInfo->FileNameLength;
		v1.MaximumLength = (USHORT)FileIdBothDirInfo->FileNameLength;

		if (FileIdBothDirInfo->FileAttributes & FILE_ATTRIBUTE_DIRECTORY)
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeDirectoryContext, &FltFileNameInfo->Name, &v1);
		else
			IsMatched = SeCheckExcludeDirecoryFileList(__ExcludeFileContext, &FltFileNameInfo->Name, &v1);

		if (IsMatched)
		{
			BOOLEAN IsOk = FALSE;

			if (Previous != NULL)
			{
				if (FileIdBothDirInfo->NextEntryOffset != 0)
				{
					Previous->NextEntryOffset += FileIdBothDirInfo->NextEntryOffset;
					NextEntryOffset = FileIdBothDirInfo->NextEntryOffset;
				}
				else
				{
					Previous->NextEntryOffset = 0;
					Status = STATUS_SUCCESS;
					IsOk = TRUE;
				}

				RtlFillMemory(FileIdBothDirInfo, sizeof(FILE_ID_BOTH_DIR_INFORMATION), 0);
			}
			else
			{
				if (FileIdBothDirInfo->NextEntryOffset != 0)
				{
					Next = (PFILE_ID_BOTH_DIR_INFORMATION)((PUCHAR)FileIdBothDirInfo + FileIdBothDirInfo->NextEntryOffset);
					MoveLength = 0;
					while (Next->NextEntryOffset != 0)
					{
						MoveLength += Next->NextEntryOffset;
						Next = (PFILE_ID_BOTH_DIR_INFORMATION)((PUCHAR)Next + Next->NextEntryOffset);
					}

					MoveLength += FIELD_OFFSET(FILE_ID_BOTH_DIR_INFORMATION, FileName) + Next->FileNameLength;
					RtlMoveMemory(FileIdBothDirInfo, (PUCHAR)FileIdBothDirInfo + FileIdBothDirInfo->NextEntryOffset, MoveLength);//continue
				}
				else
				{
					Status = STATUS_NO_MORE_ENTRIES;
					IsOk = TRUE;
				}
			}

		
			if (IsOk)
				return Status;

			FileIdBothDirInfo = (PFILE_ID_BOTH_DIR_INFORMATION)((PCHAR)FileIdBothDirInfo + NextEntryOffset);
			continue;
		}

		NextEntryOffset = FileIdBothDirInfo->NextEntryOffset;
		Previous = FileIdBothDirInfo;
		FileIdBothDirInfo = (PFILE_ID_BOTH_DIR_INFORMATION)((PCHAR)FileIdBothDirInfo + NextEntryOffset);

		if (NextEntryOffset == 0)
			IsLoop = FALSE;
	} while (IsLoop);

	return Status;
}

NTSTATUS SeCleanFileNamesInformation(PFILE_NAMES_INFORMATION FileNamesInfo, PFLT_FILE_NAME_INFORMATION FltNameInfo)
{

	PFILE_NAMES_INFORMATION Next, Previous = NULL;
	UNICODE_STRING v1;
	UINT32 NextEntryOffset, MoveLength;
	BOOLEAN IsMatched, IsLoop;
	NTSTATUS Status = STATUS_SUCCESS;

	NextEntryOffset = 0;
	IsLoop = TRUE;

	do
	{
	
		v1.Buffer = FileNamesInfo->FileName;
		v1.Length = (USHORT)FileNamesInfo->FileNameLength;
		v1.MaximumLength = (USHORT)FileNamesInfo->FileNameLength;


		if (SeCheckExcludeDirecoryFileList(__ExcludeFileContext, &FltNameInfo->Name, &v1))
		{
			BOOLEAN IsOk = FALSE;

			if (Previous != NULL)
			{
				if (FileNamesInfo->NextEntryOffset != 0)
				{
					Previous->NextEntryOffset += FileNamesInfo->NextEntryOffset;
					NextEntryOffset = FileNamesInfo->NextEntryOffset;
				}
				else
				{
					Previous->NextEntryOffset = 0;
					Status = STATUS_SUCCESS;
					IsOk = TRUE;
				}

				RtlFillMemory(FileNamesInfo, sizeof(FILE_NAMES_INFORMATION), 0);
			}
			else
			{
				if (FileNamesInfo->NextEntryOffset != 0)
				{
					Next = (PFILE_NAMES_INFORMATION)((PUCHAR)FileNamesInfo + FileNamesInfo->NextEntryOffset);
					MoveLength = 0;
					while (Next->NextEntryOffset != 0)
					{
						MoveLength += Next->NextEntryOffset;
						Next = (PFILE_NAMES_INFORMATION)((PUCHAR)Next + Next->NextEntryOffset);
					}

					MoveLength += FIELD_OFFSET(FILE_NAMES_INFORMATION, FileName) + Next->FileNameLength;
					RtlMoveMemory(FileNamesInfo, (PUCHAR)FileNamesInfo + FileNamesInfo->NextEntryOffset, MoveLength);//continue
				}
				else
				{
					Status = STATUS_NO_MORE_ENTRIES;
					IsOk = TRUE;
				}
			}

		

			if (IsOk)
				return Status;

			FileNamesInfo = (PFILE_NAMES_INFORMATION)((PCHAR)FileNamesInfo + NextEntryOffset);
			continue;
		}

		NextEntryOffset = FileNamesInfo->NextEntryOffset;
		Previous = FileNamesInfo;
		FileNamesInfo = (PFILE_NAMES_INFORMATION)((PCHAR)FileNamesInfo + NextEntryOffset);

		if (NextEntryOffset == 0)
			IsLoop = FALSE;
	} while (IsLoop);

	return STATUS_SUCCESS;
}


BOOLEAN SeCheckExcludeDirecoryFileList(PEXCLUDE_CONTEXT ExcludeContext, PCUNICODE_STRING DirectoryName, PCUNICODE_STRING FileName)
{
	PEXCLUDE_FILE_CONTEXT v5 = (PEXCLUDE_FILE_CONTEXT)ExcludeContext;
	PEXCLUDE_FILE_LIST_ENTRY Head;
	UNICODE_STRING v1;
	BOOLEAN IsOk = FALSE;

	v1 = *DirectoryName;

	if (v1.Length > 0 && v1.Buffer[v1.Length / sizeof(WCHAR) - 1] == L'\\')
		v1.Length -= sizeof(WCHAR);

	ExAcquireFastMutex(&v5->FastMutex);

	Head = (PEXCLUDE_FILE_LIST_ENTRY)v5->ListEntry.Flink;
	while (Head != (PEXCLUDE_FILE_LIST_ENTRY)&v5->ListEntry)
	{
		if (RtlCompareUnicodeString(&Head->ExculdeFilePath.DirectoryName, &v1, TRUE) == 0
			&& RtlCompareUnicodeString(&Head->ExculdeFilePath.FileName, FileName, TRUE) == 0)
		{
			IsOk = TRUE;
			break;
		}

		Head = (PEXCLUDE_FILE_LIST_ENTRY)Head->ListEntry.Flink;
	}

	ExReleaseFastMutex(&v5->FastMutex);

	return IsOk;
}