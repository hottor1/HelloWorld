#pragma once
#include <fltKernel.h>




typedef PVOID PEXCLUDE_CONTEXT;
typedef PEXCLUDE_CONTEXT* PPEXCLUDE_CONTEXT;

typedef struct _EXCLUDE_FILE_CONTEXT 
{
	LIST_ENTRY       ListEntry;  //Flink Blink
	FAST_MUTEX       FastMutex;	
} EXCLUDE_FILE_CONTEXT, *PEXCLUDE_FILE_CONTEXT;


typedef struct _EXCULDE_FILE_PATH {
	UNICODE_STRING FullPath;
	UNICODE_STRING DirectoryName;
	UNICODE_STRING FileName;
} EXCULDE_FILE_PATH, *PEXCULDE_FILE_PATH;


typedef struct _EXCLUDE_FILE_LIST_ENTRY {
	LIST_ENTRY       ListEntry;
	EXCULDE_FILE_PATH ExculdeFilePath;
} EXCLUDE_FILE_LIST_ENTRY, *PEXCLUDE_FILE_LIST_ENTRY;




VOID SeEnableDisableDriver(BOOLEAN IsEnabled);
BOOLEAN SeIsDriverEnabled();
NTSTATUS SeInitializeMiniFilter(PDRIVER_OBJECT DriverObject);
NTSTATUS SeDestroyMiniFilter();

NTSTATUS SeInitializeExcludeListContext(PPEXCLUDE_CONTEXT ExcludeContext);
BOOLEAN SeFillDirectoryFromPath(PEXCULDE_FILE_PATH ExculdeFilePath, PUNICODE_STRING FilePath);


NTSTATUS SeAddExcludeFileList(PEXCLUDE_CONTEXT ExcludeContext, PUNICODE_STRING FilePath);
NTSTATUS SeAddExcludeDirectoryList(PEXCLUDE_CONTEXT ExcludeContext, PUNICODE_STRING DirectoryPath);


NTSTATUS SeAddExcludeListEntry(PEXCLUDE_CONTEXT ExcludeContext, PUNICODE_STRING FilePath);

VOID SeDestroyExcludeListContext(PEXCLUDE_CONTEXT ExcludeContext);
NTSTATUS SeRemoveAllExcludeListEntry(PEXCLUDE_CONTEXT ExcludeContext);

BOOLEAN SeCheckExcludeFileList(PEXCLUDE_CONTEXT ExcludeContext, PCUNICODE_STRING FilePath);
BOOLEAN SeCheckExcludeDirecoryFileList(PEXCLUDE_CONTEXT ExcludeContext, PCUNICODE_STRING DirectoryName, PCUNICODE_STRING FileName);
BOOLEAN SeIsProcessExcluded(HANDLE ProcessIdentify);


/************************************************************************/
/*                                                                      */
/************************************************************************/

NTSTATUS
HiddenInstanceSetup(
	_In_ PCFLT_RELATED_OBJECTS FltObjects,
	_In_ FLT_INSTANCE_SETUP_FLAGS Flags,
	_In_ DEVICE_TYPE VolumeDeviceType,
	_In_ FLT_FILESYSTEM_TYPE VolumeFilesystemType);
NTSTATUS
HiddenUnload(
	_In_ FLT_FILTER_UNLOAD_FLAGS Flags);
VOID DriverUnload(PDRIVER_OBJECT DriverObject);

FLT_PREOP_CALLBACK_STATUS CreatePreviousOperation(PFLT_CALLBACK_DATA Data, 
	PCFLT_RELATED_OBJECTS FltObjects, PVOID *CompletionContext);

FLT_PREOP_CALLBACK_STATUS DirectoryCtrlPreviousOperation(PFLT_CALLBACK_DATA Data, PCFLT_RELATED_OBJECTS FltObjects, PVOID *CompletionContext);
FLT_POSTOP_CALLBACK_STATUS DirectoryCtrlPostOperation(PFLT_CALLBACK_DATA Data, PCFLT_RELATED_OBJECTS FltObjects, PVOID CompletionContext, FLT_POST_OPERATION_FLAGS Flags);

NTSTATUS SeCleanFileFullDirectoryInformation(PFILE_FULL_DIR_INFORMATION FileFullDirInfo,
	PFLT_FILE_NAME_INFORMATION FltFileNameInfo);
NTSTATUS SeCleanFileBothDirectoryInformation(PFILE_BOTH_DIR_INFORMATION FileBothInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo);
NTSTATUS SeCleanFileDirectoryInformation(PFILE_DIRECTORY_INFORMATION FileDirectoryInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo);
NTSTATUS SeCleanFileIdFullDirectoryInformation(PFILE_ID_FULL_DIR_INFORMATION FileIdFullDirInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo);
NTSTATUS SeCleanFileIdBothDirectoryInformation(PFILE_ID_BOTH_DIR_INFORMATION FileIdBothDirInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo);
NTSTATUS SeCleanFileNamesInformation(PFILE_NAMES_INFORMATION FileNamesInfo, PFLT_FILE_NAME_INFORMATION FltFileNameInfo);